import { toast } from 'sonner@2.0.3';

export interface PendingSync {
  id: string;
  type: 'task' | 'note' | 'grade' | 'schedule' | 'profile';
  action: 'create' | 'update' | 'delete';
  data: any;
  timestamp: number;
}

const PENDING_SYNC_KEY = 'pendingSync';
const LAST_SYNC_KEY = 'lastSync';

class SyncService {
  // Obtener todas las sincronizaciones pendientes
  getPendingSync(): PendingSync[] {
    try {
      const pending = localStorage.getItem(PENDING_SYNC_KEY);
      return pending ? JSON.parse(pending) : [];
    } catch (error) {
      console.error('Error al obtener sincronizaciones pendientes:', error);
      return [];
    }
  }

  // Agregar una operación a la cola de sincronización
  addPendingSync(sync: Omit<PendingSync, 'id' | 'timestamp'>) {
    try {
      const pending = this.getPendingSync();
      const newSync: PendingSync = {
        ...sync,
        id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        timestamp: Date.now(),
      };
      
      pending.push(newSync);
      localStorage.setItem(PENDING_SYNC_KEY, JSON.stringify(pending));
      
      return newSync.id;
    } catch (error) {
      console.error('Error al agregar sincronización pendiente:', error);
      return null;
    }
  }

  // Eliminar una sincronización completada
  removePendingSync(id: string) {
    try {
      const pending = this.getPendingSync();
      const updated = pending.filter(sync => sync.id !== id);
      localStorage.setItem(PENDING_SYNC_KEY, JSON.stringify(updated));
    } catch (error) {
      console.error('Error al eliminar sincronización:', error);
    }
  }

  // Limpiar todas las sincronizaciones pendientes
  clearPendingSync() {
    try {
      localStorage.removeItem(PENDING_SYNC_KEY);
    } catch (error) {
      console.error('Error al limpiar sincronizaciones:', error);
    }
  }

  // Sincronizar todos los datos pendientes
  async syncAll(): Promise<{ success: number; failed: number }> {
    const pending = this.getPendingSync();
    
    if (pending.length === 0) {
      return { success: 0, failed: 0 };
    }

    let success = 0;
    let failed = 0;

    // Procesar todas las sincronizaciones pendientes
    for (const sync of pending) {
      try {
        // Aquí procesamos cada tipo de dato
        // Como usamos localStorage, los datos ya están guardados,
        // solo necesitamos marcar como sincronizado
        this.removePendingSync(sync.id);
        success++;
      } catch (error) {
        console.error('Error al sincronizar:', sync, error);
        failed++;
      }
    }

    // Actualizar la última fecha de sincronización
    if (success > 0) {
      localStorage.setItem(LAST_SYNC_KEY, new Date().toISOString());
    }

    return { success, failed };
  }

  // Obtener la última fecha de sincronización
  getLastSyncDate(): Date | null {
    try {
      const lastSync = localStorage.getItem(LAST_SYNC_KEY);
      return lastSync ? new Date(lastSync) : null;
    } catch (error) {
      console.error('Error al obtener última sincronización:', error);
      return null;
    }
  }

  // Contar sincronizaciones pendientes
  getPendingCount(): number {
    return this.getPendingSync().length;
  }

  // Guardar datos localmente
  saveLocal(key: string, data: any): boolean {
    try {
      localStorage.setItem(key, JSON.stringify(data));
      return true;
    } catch (error) {
      console.error('Error al guardar datos localmente:', error);
      toast.error('Error al guardar datos');
      return false;
    }
  }

  // Obtener datos locales
  getLocal<T>(key: string, defaultValue: T): T {
    try {
      const data = localStorage.getItem(key);
      return data ? JSON.parse(data) : defaultValue;
    } catch (error) {
      console.error('Error al obtener datos locales:', error);
      return defaultValue;
    }
  }

  // Eliminar datos locales
  removeLocal(key: string): boolean {
    try {
      localStorage.removeItem(key);
      return true;
    } catch (error) {
      console.error('Error al eliminar datos locales:', error);
      return false;
    }
  }
}

export const syncService = new SyncService();
