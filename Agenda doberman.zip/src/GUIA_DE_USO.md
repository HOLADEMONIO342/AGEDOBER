# 📚 GUÍA DE USO - AGENDA DOBERMAN

## 🎯 Índice

1. [Introducción](#introducción)
2. [Primer Uso - Registro](#primer-uso---registro)
3. [Guía para Alumnos](#-guía-para-alumnos)
4. [Guía para Docentes](#-guía-para-docentes)
5. [Modo Offline](#-modo-offline)
6. [Preguntas Frecuentes](#-preguntas-frecuentes)
7. [Solución de Problemas](#-solución-de-problemas)

---

## Introducción

**AGENDA DOBERMAN** es tu herramienta completa para organizar tu vida escolar. Ya seas alumno o docente, esta aplicación te ayudará a gestionar tareas, horarios, calificaciones y mucho más.

### 🌟 Características Principales

- ✅ Funciona sin conexión a internet
- ✅ Sincronización automática de datos
- ✅ Gestión de tareas con prioridades
- ✅ Calendario y horario personalizado
- ✅ Sistema de calificaciones
- ✅ Notas y apuntes organizados
- ✅ Recordatorios automáticos

---

## Primer Uso - Registro

### Paso 1: Pantalla de Autenticación

1. **Abre la aplicación** en tu navegador
2. **Ingresa tu correo electrónico** en el campo correspondiente
3. Haz clic en **"Registrarse"** o **"Iniciar Sesión"**

> 💡 **Nota**: No necesitas verificar el correo, es solo para identificarte

### Paso 2: Pantalla de Bienvenida

Verás un mensaje de bienvenida del equipo de desarrolladores:

```
¡Bienvenido a Agenda Doberman!
Desarrollado por: Victor Moreno y Christian Ayala
```

- Haz clic en **"Continuar"**

### Paso 3: Selección de Rol

**¿Eres Alumno o Docente?**

- **ALUMNO** → Para estudiantes
- **DOCENTE** → Para profesores

Selecciona tu rol haciendo clic en el botón correspondiente.

---

## 👨‍🎓 GUÍA PARA ALUMNOS

### Configuración Inicial

Después de seleccionar **ALUMNO**, completa tu perfil:

1. **Nombre completo**: Escribe tu nombre completo
2. **Salón**: Selecciona tu salón de la lista
   - Ejemplo: 1AVTC, 3AVL, 1BMTC, etc.
3. Haz clic en **"Guardar Configuración"**

> ✨ **Tu horario se configurará automáticamente** según tu salón

---

### 📅 Pestaña CALENDARIO

#### ¿Qué puedes hacer?

- **Ver el calendario mensual**: Navega entre meses
- **Ver eventos del día**: Los eventos se muestran al seleccionar una fecha
- **Agregar eventos**: (Próximamente)

#### Cómo usar:

1. Haz clic en cualquier día del calendario
2. Los eventos de ese día aparecerán en la columna derecha
3. Usa las flechas **←** **→** para cambiar de mes

---

### ✅ Pestaña TAREAS

#### Funcionalidades Principales

##### 📝 **Agregar una Nueva Tarea**

1. Haz clic en **"+ Nueva Tarea"**
2. Completa los campos:
   - **Título**: Nombre de la tarea (ej: "Resolver ejercicios página 45")
   - **Materia**: Asignatura (ej: "Matemáticas")
   - **Fecha de entrega**: Selecciona la fecha
   - **Prioridad**: Elige entre:
     - 🟢 **Baja**: Tareas con tiempo
     - 🟡 **Media**: Tareas normales
     - 🔴 **Alta**: ¡Urgente!
3. Haz clic en **"Agregar Tarea"**

##### ✔️ **Marcar como Completada**

1. Encuentra tu tarea en la lista
2. Haz clic en el **checkbox** ☑️ al lado izquierdo
3. La tarea aparecerá tachada ~~así~~

##### 🗑️ **Eliminar una Tarea**

1. Encuentra la tarea
2. Haz clic en el icono de **basura** 🗑️
3. La tarea se eliminará

##### 🔍 **Filtrar Tareas**

- **Por estado**:
  - Todas las tareas
  - Solo pendientes
  - Solo completadas

- **Por prioridad**:
  - Todas
  - Alta prioridad
  - Media prioridad
  - Baja prioridad

##### 🔔 **Notificaciones Automáticas**

Recibirás recordatorios automáticos:
- **3 días antes** de la fecha de entrega
- **1 día antes** de la fecha de entrega
- **El día de entrega**

---

### 📖 Pestaña HORARIO

#### Ver tu Horario Semanal

1. Accede a la pestaña **HORARIO**
2. Verás tu horario organizado por días
3. Cada clase muestra:
   - 🕐 **Hora** de inicio y fin
   - 📚 **Materia**
   - 👨‍🏫 **Profesor**
   - 🚪 **Salón** (aula)

#### Colores por Materia

Cada materia tiene un color único para identificarla fácilmente:
- Matemáticas → Azul
- Español → Verde
- Ciencias → Morado
- etc.

#### Días de la Semana

- **Lunes a Viernes**: Horario completo
- Navega usando el selector de días

---

### 📝 Pestaña NOTAS

#### ¿Para qué sirve?

Guardar apuntes importantes, fórmulas, resúmenes, etc.

##### ➕ **Crear una Nueva Nota**

1. Haz clic en **"+ Nueva Nota"**
2. Completa:
   - **Título**: Nombre de la nota (ej: "Fórmulas de Trigonometría")
   - **Materia**: Asignatura relacionada
   - **Contenido**: Escribe tus apuntes (admite múltiples líneas)
3. Haz clic en **"Agregar Nota"**

##### ✏️ **Editar una Nota**

1. Busca tu nota
2. Haz clic en el icono de **lápiz** ✏️
3. Modifica el contenido
4. Haz clic en **"Guardar Cambios"**

##### 🗑️ **Eliminar una Nota**

1. Encuentra la nota
2. Haz clic en el icono de **basura** 🗑️
3. La nota se eliminará

##### 🔍 **Organización**

- Las notas se muestran en **tarjetas**
- Cada tarjeta muestra:
  - Título
  - Materia (con etiqueta de color)
  - Fecha de creación
  - Contenido completo

---

### 🎓 Pestaña CALIFICACIONES

#### Ver tus Calificaciones

1. Accede a **CALIFICACIONES**
2. Verás una tabla con:
   - **Materia**
   - **Calificaciones** (pueden ser varias por materia)
   - **Promedio** de cada materia
   - **Promedio General**

#### Agregar Calificación

> 📌 **Nota**: Normalmente, las calificaciones las agrega tu docente

1. Haz clic en **"+ Agregar Calificación"**
2. Selecciona la **materia**
3. Ingresa la **calificación** (0-100)
4. Agrega un **concepto** (opcional): "Examen", "Tarea", etc.
5. Haz clic en **"Guardar"**

#### Interpretar Colores

- 🟢 **Verde** (90-100): ¡Excelente!
- 🔵 **Azul** (80-89): Muy bien
- 🟡 **Amarillo** (70-79): Bien
- 🟠 **Naranja** (60-69): Regular
- 🔴 **Rojo** (0-59): Necesitas mejorar

---

### 💡 Consejos para Alumnos

1. **Revisa tus tareas diariamente** en la pestaña TAREAS
2. **Usa prioridades** para organizarte mejor
3. **Toma notas** después de cada clase
4. **Consulta tu horario** para no olvidar materias
5. **Activa las notificaciones** del navegador
6. **La app funciona sin internet** - úsala en cualquier lugar

---

## 👨‍🏫 GUÍA PARA DOCENTES

### Configuración Inicial

Después de seleccionar **DOCENTE**, completa tu perfil:

1. **Nombre completo**: Tu nombre (ej: "Prof. Juan Pérez")
2. **Salones**: Selecciona TODOS los salones donde das clases
   - Puedes seleccionar múltiples salones
   - Marca con ✓ cada salón
3. Haz clic en **"Guardar Configuración"**

---

### 📅 Pestaña CALENDARIO

Similar a alumnos:
- Ver calendario mensual
- Eventos del día
- Planificación de actividades

---

### ✅ Pestaña TAREAS

#### Gestión de Tareas como Docente

##### 📝 **Crear Tarea para la Clase**

1. Haz clic en **"+ Nueva Tarea"**
2. Completa:
   - **Título**: Nombre de la tarea
   - **Materia**: Tu materia
   - **Fecha de entrega**: Cuando deben entregarla
   - **Prioridad**: Importancia de la tarea
3. Haz clic en **"Agregar Tarea"**

> 💡 **Tip**: Usa esta sección para recordar qué tareas dejaste a cada grupo

##### 📊 **Ver Estadísticas**

- Tareas pendientes de revisar
- Tareas completadas
- Filtrar por prioridad

---

### 🕐 Pestaña HORARIO

#### Ver y Gestionar tu Horario

1. Accede a **HORARIO**
2. Verás tu horario personalizado
3. Muestra todos los grupos donde das clases

#### Editar Horario

> ⚠️ **Solo docentes pueden editar su horario**

1. Haz clic en **"Editar Horario"**
2. Modifica:
   - Horas de clases
   - Salones asignados
   - Materias
3. Guarda los cambios

---

### 📝 Pestaña NOTAS

Igual que alumnos:
- Crear notas de clase
- Guardar planes de lección
- Apuntes importantes

---

### 📋 Pestaña LISTAS

#### 🎯 Gestión de Asistencia

Esta es una pestaña **exclusiva para docentes**.

##### **Seleccionar Salón y Fecha**

1. En la parte superior, selecciona:
   - **Salón**: Elige el grupo (ej: 1AVTC, 3AVL)
   - **Fecha**: Selecciona el día (por defecto: hoy)

##### **Ver Lista de Alumnos**

Verás la lista completa con:
- Número de lista
- Nombre completo del alumno
- Número de control (si está disponible)

##### **Buscar Alumnos**

1. Usa el **buscador** en la parte superior
2. Escribe:
   - Nombre del alumno, o
   - Número de control
3. La lista se filtrará automáticamente

##### **Pasar Lista de Asistencia**

Para cada alumno puedes marcar:

1. **✅ Presente** (botón verde)
   - Haz clic en el botón con ✓
   - La fila se pondrá verde

2. **⏰ Retardo** (botón amarillo)
   - Haz clic en el botón con reloj
   - La fila se pondrá amarilla

3. **❌ Ausente** (botón rojo)
   - Haz clic en el botón con X
   - La fila se pondrá roja

##### **Marcar Todos Presentes**

1. Haz clic en **"Marcar Todos como Presentes"**
2. Todos los alumnos se marcarán como presentes
3. Luego puedes cambiar individualmente los que falten

##### **Ver Estadísticas del Día**

En la parte superior verás:
- **Total**: Número total de alumnos
- **Presentes**: Alumnos presentes (verde)
- **Ausentes**: Alumnos ausentes (rojo)
- **Retardos**: Alumnos con retardo (amarillo)

##### **Historial de Asistencias**

- Cambia la **fecha** para ver asistencias anteriores
- Cada día se guarda por separado
- Puedes consultar o modificar asistencias pasadas

---

### 📊 Pestaña REVISADOS

#### 🎯 Asignar Calificaciones a Tareas

Esta pestaña es **exclusiva para docentes**.

##### **Crear una Nueva Actividad/Tarea**

1. Haz clic en **"+ Nueva Actividad"**
2. Completa:
   - **Nombre**: Título de la actividad (ej: "Examen Unidad 1")
   - **Puntos Máximos**: Calificación máxima (ej: 100)
   - **Fecha**: Día de la actividad
3. Haz clic en **"Crear Actividad"**

##### **Seleccionar Actividad para Calificar**

1. En el selector superior, elige:
   - **Salón**: Grupo a calificar
   - **Actividad**: Tarea/examen a calificar

##### **Buscar Alumno**

1. Usa el **buscador** para encontrar al alumno
2. Escribe su nombre o número de control
3. La lista se filtrará

##### **Asignar Calificación**

Para cada alumno:

1. Busca al alumno en la lista
2. En el campo **"Puntos"**, ingresa la calificación
3. Haz clic en **"✓ Guardar"**
4. La calificación se guardará automáticamente

Verás:
- ✅ **Verde**: Calificación guardada
- ⭕ **Sin color**: Aún no calificado

##### **Ver Estadísticas de la Actividad**

En la parte superior verás:
- **Total de alumnos**
- **Calificados**: Cuántos ya tienen calificación
- **Pendientes**: Cuántos faltan por calificar
- **Promedio del grupo**: Calificación promedio

##### **Editar Calificación**

1. Encuentra al alumno
2. Cambia el valor en el campo **"Puntos"**
3. Haz clic en **"✓ Guardar"** nuevamente

##### **Eliminar Calificación**

1. Busca al alumno
2. Haz clic en **"🗑️ Eliminar"**
3. La calificación se borrará

---

### 🎓 Pestaña CALIFICACIONES

#### Ver Calificaciones del Grupo

1. Selecciona el **salón**
2. Verás un resumen de calificaciones
3. Puedes ver:
   - Promedio por materia
   - Promedio general del grupo
   - Distribución de calificaciones

---

### 💡 Consejos para Docentes

1. **Pasa lista al inicio de clase** usando la pestaña LISTAS
2. **Usa el buscador** para encontrar alumnos rápidamente
3. **Marca todos presentes** y luego ajusta los ausentes/retardos
4. **Crea actividades** antes de calificar en REVISADOS
5. **Revisa las estadísticas** para identificar alumnos que necesitan apoyo
6. **La app funciona sin internet** - califica sin preocuparte por la conexión
7. **Sincroniza regularmente** cuando tengas internet para respaldar datos

---

## 📡 Modo Offline

### ¿Cómo Funciona?

La aplicación **funciona completamente sin internet**:

#### 🟢 **Con Internet**

- Indicador verde con ✓
- Mensaje: "Todo sincronizado"
- Todos los cambios se guardan y sincronizan

#### 🟡 **Sin Internet**

- Indicador amarillo con ⚠️
- Mensaje: "Sin conexión - Modo offline"
- Los cambios se guardan localmente
- Se sincronizarán cuando vuelva la conexión

### Lo que puedes hacer sin internet:

✅ Ver tu horario
✅ Agregar tareas
✅ Tomar notas
✅ Pasar lista (docentes)
✅ Asignar calificaciones (docentes)
✅ Ver todas tus actividades

### Sincronización Automática

1. Cuando recuperes internet, verás una notificación
2. La app sincronizará automáticamente todos los cambios
3. Recibirás confirmación: "X cambio(s) sincronizado(s)"

### Forzar Sincronización

1. Haz clic en **"Sincronizar ahora"** en el indicador de conexión
2. Espera la confirmación
3. Verifica que diga "Todo sincronizado"

---

## ❓ Preguntas Frecuentes

### Para Alumnos

**P: ¿Puedo cambiar mi salón después?**
R: Sí, puedes cerrar sesión y volver a configurar tu perfil.

**P: ¿Las tareas se sincronizan entre dispositivos?**
R: Actualmente los datos se guardan en el navegador local. Usa el mismo dispositivo.

**P: ¿Puedo usar la app en mi celular?**
R: Sí, la aplicación es responsive y funciona en móviles.

**P: ¿Las notificaciones funcionan sin internet?**
R: Las notificaciones se activan cuando abres la app, con o sin internet.

### Para Docentes

**P: ¿Puedo enseñar en varios salones?**
R: Sí, selecciona todos tus salones en la configuración inicial.

**P: ¿Las asistencias de qué fecha se guardan?**
R: Cada fecha se guarda por separado. Puedes consultar cualquier día.

**P: ¿Puedo exportar las listas?**
R: Esta función estará disponible próximamente.

**P: ¿Los alumnos ven las calificaciones que asigno?**
R: No automáticamente. Debes comunicarlas por otros medios.

### General

**P: ¿Es segura mi información?**
R: Sí, todos los datos se guardan localmente en tu dispositivo.

**P: ¿Necesito instalar algo?**
R: No, funciona directo en el navegador. Opcionalmente puedes instalarla como app.

**P: ¿Qué pasa si borro el caché del navegador?**
R: Perderás tus datos locales. ¡Ten cuidado!

---

## 🔧 Solución de Problemas

### Problema: No puedo ver mi horario

**Solución:**
1. Verifica que hayas seleccionado un salón
2. Cierra sesión y vuelve a configurar
3. Recarga la página (F5)

### Problema: Las tareas no se guardan

**Solución:**
1. Verifica el indicador de conexión
2. Asegúrate de llenar todos los campos obligatorios
3. Limpia el caché del navegador y vuelve a intentar

### Problema: No recibo notificaciones

**Solución:**
1. Verifica los permisos del navegador
2. En Configuración → Notificaciones → Permitir
3. Asegúrate de tener la pestaña abierta

### Problema: Indicador dice "Sin conexión" pero tengo internet

**Solución:**
1. Verifica tu conexión WiFi/datos
2. Recarga la página (F5)
3. Haz clic en "Sincronizar ahora"

### Problema: No aparece mi salón en la lista

**Solución:**
1. Contacta al administrador
2. Verifica que estés en el rol correcto (Alumno/Docente)
3. Intenta con otro salón temporalmente

### Problema: Perdí todos mis datos

**Solución:**
1. Verifica que estés usando el mismo navegador
2. Revisa si borraste las cookies/caché
3. Los datos son locales - no recuperables si se borraron

---

## 📞 Soporte

### ¿Necesitas ayuda?

**Desarrolladores:**
- Victor Moreno
- Christian Ayala

**Versión:** 2.0
**Fecha:** Noviembre 2025

---

## 🎯 Atajos y Trucos

### Para ser más eficiente:

1. **Usa el buscador** (docentes) - Ctrl+F
2. **Marca todos presentes** primero, ajusta después
3. **Filtra por prioridad** para tareas urgentes
4. **Revisa notificaciones** al abrir la app
5. **Sincroniza antes de cerrar** la aplicación

### Navegación Rápida:

- **Pestañas principales** están en la parte superior
- **Buscadores** tienen el icono 🔍
- **Botones primarios** son de color azul/morado
- **Acciones peligrosas** son rojas (eliminar)

---

## ✨ El cambio empieza por ti

Aprovecha al máximo AGENDA DOBERMAN y mantén tu vida escolar organizada. ¡Éxito en tus estudios! 🎓

---

**📄 Última actualización:** Noviembre 2025
