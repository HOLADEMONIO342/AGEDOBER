# Modo Offline - Agenda Doberman

## 📱 Funcionamiento Sin Conexión

La aplicación AGENDA DOBERMAN ahora puede funcionar completamente sin conexión a internet. Todos tus datos se guardan localmente y se sincronizan automáticamente cuando vuelve la conexión.

## ✨ Características

### 1. **Detección Automática de Conexión**
- La aplicación detecta automáticamente cuando pierdes o recuperas la conexión a internet
- Muestra indicadores visuales del estado de conexión

### 2. **Almacenamiento Local**
- **Tareas**: Todas las tareas se guardan localmente
- **Notas**: Tus apuntes están disponibles sin conexión
- **Horario**: Tu horario siempre está accesible
- **Calificaciones**: Las calificaciones se mantienen guardadas
- **Perfil**: Tu información de usuario se conserva

### 3. **Sincronización Automática**
- Cuando recuperas la conexión, todos los cambios se sincronizan automáticamente
- Recibes notificaciones cuando:
  - Se pierde la conexión
  - Se recupera la conexión
  - Los datos se sincronizan correctamente

### 4. **Cola de Sincronización**
- Los cambios realizados sin conexión se guardan en una cola
- Se procesan automáticamente cuando vuelve internet
- Puedes ver cuántos cambios están pendientes de sincronizar

## 🔄 Cómo Funciona

### Sin Conexión
1. Cuando no hay internet, verás un indicador amarillo que dice "Sin conexión - Modo offline"
2. Todos los cambios que hagas se guardarán localmente
3. Puedes seguir usando la aplicación normalmente

### Con Conexión Restaurada
1. Cuando vuelve internet, verás un indicador verde
2. La aplicación sincronizará automáticamente todos los cambios pendientes
3. Recibirás una notificación confirmando la sincronización

## 🎯 Uso Recomendado

### Para Estudiantes
- Puedes agregar tareas y notas en cualquier momento, incluso sin internet
- Revisa tu horario sin preocuparte por la conexión
- Los cambios se sincronizarán cuando estés conectado

### Para Docentes
- Registra tareas revisadas sin necesidad de estar conectado
- Agrega calificaciones que se sincronizarán después
- Gestiona tu horario offline

## 📊 Indicadores de Estado

### 🟡 Amarillo - Sin Conexión
- **Icono**: WiFi desconectado
- **Mensaje**: "Sin conexión - Modo offline"
- **Acción**: Tus datos se guardan localmente

### 🟢 Verde - Conectado y Sincronizado
- **Icono**: WiFi conectado + Check
- **Mensaje**: "Todo sincronizado"
- **Acción**: Todos los datos están al día

### 🔵 Azul - Sincronizando
- **Icono**: Icono girando
- **Mensaje**: "X cambio(s) pendiente(s) de sincronizar"
- **Acción**: Botón para forzar sincronización

## ⚙️ Tecnologías Utilizadas

- **localStorage**: Almacenamiento persistente en el navegador
- **Online/Offline Events**: Detección automática del estado de conexión
- **Service Workers**: (Futuro) Para cache de recursos estáticos

## 🛠️ Solución de Problemas

### Los datos no se sincronizan
1. Verifica que tienes conexión a internet
2. Haz clic en el botón "Sincronizar ahora" en el indicador
3. Actualiza la página si persiste el problema

### El indicador no desaparece
- El indicador desaparece automáticamente después de 5 segundos cuando todo está sincronizado
- Puedes cerrarlo manualmente haciendo clic en la "×"

## 🔐 Privacidad y Seguridad

- Todos los datos se almacenan localmente en tu dispositivo
- No se envía información a servidores externos
- Los datos persisten mientras no borres el caché del navegador

## 📝 Notas Importantes

- Los datos se guardan en el navegador que estés usando
- Si cambias de dispositivo, necesitarás configurar nuevamente tu cuenta
- Limpia regularmente el caché del navegador puede borrar tus datos locales
- Haz respaldo de información importante

---

**Desarrollado por**: Equipo AGENDA DOBERMAN
**Versión Offline**: 1.0
