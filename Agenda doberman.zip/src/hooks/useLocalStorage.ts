import { useState, useEffect } from 'react';
import { syncService } from '../utils/syncService';
import { useOnlineStatus } from './useOnlineStatus';

export function useLocalStorage<T>(
  key: string, 
  initialValue: T,
  syncType?: 'task' | 'note' | 'grade' | 'schedule' | 'profile'
): [T, (value: T | ((val: T) => T)) => void] {
  const isOnline = useOnlineStatus();
  
  // State to store our value
  const [storedValue, setStoredValue] = useState<T>(() => {
    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch (error) {
      console.error(`Error loading ${key} from localStorage:`, error);
      return initialValue;
    }
  });

  // Return a wrapped version of useState's setter function that persists to localStorage
  const setValue = (value: T | ((val: T) => T)) => {
    try {
      // Allow value to be a function so we have same API as useState
      const valueToStore = value instanceof Function ? value(storedValue) : value;
      
      // Save state
      setStoredValue(valueToStore);
      
      // Save to local storage
      window.localStorage.setItem(key, JSON.stringify(valueToStore));
      
      // Si está offline y hay un tipo de sincronización, agregar a la cola
      if (!isOnline && syncType) {
        syncService.addPendingSync({
          type: syncType,
          action: 'update',
          data: { key, value: valueToStore },
        });
      }
    } catch (error) {
      console.error(`Error setting ${key} in localStorage:`, error);
    }
  };

  return [storedValue, setValue];
}
