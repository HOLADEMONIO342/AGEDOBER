export interface ScheduleClass {
  subject: string;
  time: string;
  teacher?: string;
}

export interface DaySchedule {
  day: string;
  classes: ScheduleClass[];
}

export const schedules: Record<string, DaySchedule[]> = {
  '1CMTC': [
    {
      day: 'Lunes',
      classes: [
        { subject: 'REC. SOC. I', time: '7:00 - 7:50', teacher: 'ROSA ELIA PECINA MORENO' },
        { subject: 'INGLÉS I', time: '7:50 - 8:40', teacher: 'ALEJANDRO IBARRA ALANIS' },
        { subject: 'CULT. DIGITAL I', time: '8:40 - 9:30', teacher: 'MARCOS RENÉ GONZÁLEZ ASENCIO' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'LENG. Y COM. I', time: '9:50 - 10:40', teacher: 'MARÍA DEL CARMEN FLORES ZÁRATE' },
        { subject: 'LENG. Y COM. I', time: '10:40 - 11:25', teacher: 'MARÍA DEL CARMEN FLORES ZÁRATE' },
        { subject: 'PROG DE DISC Y SALUD EMS', time: '11:25 - 12:10', teacher: '' },
      ]
    },
    {
      day: 'Martes',
      classes: [
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '7:00 - 7:50', teacher: 'MARITZA PÉREZ GARZA' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '7:50 - 8:40', teacher: 'MARITZA PÉREZ GARZA' },
        { subject: 'PENS. MAT I', time: '8:40 - 9:30', teacher: 'MA. GUADALUPE BOLAÑOS CARMONA' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'PENS. MAT I', time: '9:50 - 10:40', teacher: 'MA. GUADALUPE BOLAÑOS CARMONA' },
        { subject: 'CIENCIAS NATURALES I', time: '10:40 - 11:25', teacher: 'KARLA PERALES TREJO' },
      ]
    },
    {
      day: 'Miércoles',
      classes: [
        { subject: 'PENS. MAT I', time: '7:00 - 7:50', teacher: 'MA. GUADALUPE BOLAÑOS CARMONA' },
        { subject: 'PENS. MAT I', time: '7:50 - 8:40', teacher: 'MA. GUADALUPE BOLAÑOS CARMONA' },
        { subject: 'CIENCIAS NATURALES I', time: '8:40 - 9:30', teacher: 'KARLA PERALES TREJO' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'CIENCIAS NATURALES I', time: '9:50 - 10:40', teacher: 'KARLA PERALES TREJO' },
        { subject: 'PROG DE DISC Y SALUD EMS', time: '10:40 - 11:25', teacher: '' },
      ]
    },
    {
      day: 'Jueves',
      classes: [
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '7:00 - 7:50', teacher: 'MARITZA PÉREZ GARZA' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '7:50 - 8:40', teacher: 'MARITZA PÉREZ GARZA' },
        { subject: 'TUTORÍAS', time: '8:40 - 9:30', teacher: 'MARITZA PÉREZ GARZA' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'CIENCIAS NATURALES I LAB', time: '9:50 - 10:40', teacher: 'KARLA PERALES TREJO' },
        { subject: 'CIENCIAS NATURALES I LAB', time: '10:40 - 11:25', teacher: 'KARLA PERALES TREJO' },
        { subject: 'CIENCIAS SOCIALES I', time: '11:25 - 12:10', teacher: 'MALINTZIN YAJAIRA GUTIÉRREZ SILVA' },
      ]
    },
    {
      day: 'Viernes',
      classes: [
        { subject: 'INGLÉS I', time: '7:00 - 7:50', teacher: 'ALEJANDRO IBARRA ALANIS' },
        { subject: 'INGLÉS I', time: '7:50 - 8:40', teacher: 'ALEJANDRO IBARRA ALANIS' },
        { subject: 'INGLÉS I', time: '8:40 - 9:30', teacher: 'ALEJANDRO IBARRA ALANIS' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'INGLÉS I', time: '9:50 - 10:40', teacher: 'ALEJANDRO IBARRA ALANIS' },
        { subject: 'LENG. Y COM. I', time: '10:40 - 11:25', teacher: 'MARÍA DEL CARMEN FLORES ZÁRATE' },
      ]
    }
  ],
  '1EMTC': [
    {
      day: 'Lunes',
      classes: [
        { subject: 'PENS. MAT. I', time: '7:00 - 7:50', teacher: 'EDGAR ISAAC AYALA MORALES' },
        { subject: 'PENS. MAT. I', time: '7:50 - 8:40', teacher: 'EDGAR ISAAC AYALA MORALES' },
        { subject: 'CIENCIAS SOCIALES I', time: '8:40 - 9:30', teacher: 'ROSA ELIA PECINA MORENO' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '9:50 - 10:40', teacher: 'MYRIAM LIZETH TRUJILLO GARCÍA' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '10:40 - 11:25', teacher: 'MYRIAM LIZETH TRUJILLO GARCÍA' },
        { subject: 'TUTORÍAS', time: '11:25 - 12:10', teacher: 'KAREN MONCERRAT ESPINOZA ROCHA' },
      ]
    },
    {
      day: 'Martes',
      classes: [
        { subject: 'CIENCIAS NATURALES I LAB', time: '7:00 - 7:50', teacher: 'NELLY STEPHANIE ROCHA SOLIS' },
        { subject: 'CIENCIAS NATURALES I LAB', time: '7:50 - 8:40', teacher: 'NELLY STEPHANIE ROCHA SOLIS' },
        { subject: 'INGLÉS I', time: '8:40 - 9:30', teacher: 'ALEJANDRO IBARRA ALANIS' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'LENG. Y COM. I', time: '9:50 - 10:40', teacher: 'KERIME SÁNCHEZ LÓPEZ' },
        { subject: 'CULT. DIGITAL I', time: '10:40 - 11:25', teacher: 'ELVIA LIZETH ORTEGA GUERRERO' },
        { subject: 'PROG DE DISC Y SALUD EMS', time: '11:25 - 12:10', teacher: '' },
      ]
    },
    {
      day: 'Miércoles',
      classes: [
        { subject: 'PENS. MAT. I', time: '7:00 - 7:50', teacher: 'EDGAR ISAAC AYALA MORALES' },
        { subject: 'PENS. MAT. I', time: '7:50 - 8:40', teacher: 'EDGAR ISAAC AYALA MORALES' },
        { subject: 'LENG. Y COM. I', time: '8:40 - 9:30', teacher: 'KERIME SÁNCHEZ LÓPEZ' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'LENG. Y COM. I', time: '9:50 - 10:40', teacher: 'KERIME SÁNCHEZ LÓPEZ' },
        { subject: 'CIENCIAS SOCIALES I', time: '10:40 - 11:25', teacher: 'ROSA ELIA PECINA MORENO' },
      ]
    },
    {
      day: 'Jueves',
      classes: [
        { subject: 'INGLÉS I', time: '7:00 - 7:50', teacher: 'ALEJANDRO IBARRA ALANIS' },
        { subject: 'INGLÉS I', time: '7:50 - 8:40', teacher: 'ALEJANDRO IBARRA ALANIS' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '8:40 - 9:30', teacher: 'MYRIAM LIZETH TRUJILLO GARCÍA' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '9:50 - 10:40', teacher: 'MYRIAM LIZETH TRUJILLO GARCÍA' },
        { subject: 'PROG DE DISC Y SALUD EMS', time: '10:40 - 11:25', teacher: '' },
      ]
    },
    {
      day: 'Viernes',
      classes: [
        { subject: 'CIENCIAS NATURALES I', time: '7:00 - 7:50', teacher: 'NELLY STEPHANIE ROCHA SOLIS' },
        { subject: 'CIENCIAS NATURALES I', time: '7:50 - 8:40', teacher: 'NELLY STEPHANIE ROCHA SOLIS' },
        { subject: 'REC. SOC. I', time: '8:40 - 9:30', teacher: 'MARITZA PÉREZ GARZA' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'CULT. DIGITAL I LAB', time: '9:50 - 10:40', teacher: 'ELVIA LIZETH ORTEGA GUERRERO' },
        { subject: 'CULT. DIGITAL I LAB', time: '10:40 - 11:25', teacher: 'ELVIA LIZETH ORTEGA GUERRERO' },
      ]
    }
  ],
  '1AMTC': [
    {
      day: 'Lunes',
      classes: [
        { subject: 'PENS. MAT I', time: '7:00 - 7:50', teacher: 'MA. GUADALUPE BOLAÑOS CARMONA' },
        { subject: 'PENS. MAT I', time: '7:50 - 8:40', teacher: 'MA. GUADALUPE BOLAÑOS CARMONA' },
        { subject: 'INGLÉS I', time: '8:40 - 9:30', teacher: 'ALEJANDRO IBARRA ALANIS' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'CIENCIAS NATURALES I', time: '9:50 - 10:40', teacher: 'KARLA PERALES TREJO' },
        { subject: 'CIENCIAS NATURALES I', time: '10:40 - 11:25', teacher: 'KARLA PERALES TREJO' },
      ]
    },
    {
      day: 'Martes',
      classes: [
        { subject: 'CULT. DIGITAL I LAB', time: '7:00 - 7:50', teacher: 'MARCOS RENÉ GONZÁLEZ ASENCIO' },
        { subject: 'CULT. DIGITAL I LAB', time: '7:50 - 8:40', teacher: 'MARCOS RENÉ GONZÁLEZ ASENCIO' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '8:40 - 9:30', teacher: 'MARITZA PÉREZ GARZA' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '9:50 - 10:40', teacher: 'MARITZA PÉREZ GARZA' },
        { subject: 'LENG. Y COM. I', time: '10:40 - 11:25', teacher: 'KERIME SANCHEZ LOPEZ' },
        { subject: 'PROG DE DISC Y SALUD EMS', time: '11:25 - 12:10', teacher: '' },
      ]
    },
    {
      day: 'Miércoles',
      classes: [
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '7:00 - 7:50', teacher: 'MARITZA PÉREZ GARZA' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '7:50 - 8:40', teacher: 'MARITZA PÉREZ GARZA' },
        { subject: 'INGLÉS I', time: '8:40 - 9:30', teacher: 'ALEJANDRO IBARRA ALANIS' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'INGLÉS I', time: '9:50 - 10:40', teacher: 'ALEJANDRO IBARRA ALANIS' },
        { subject: 'CIENCIAS SOCIALES I', time: '10:40 - 11:25', teacher: 'MALINTZIN YAJAIRA GUTIÉRREZ SILVA' },
      ]
    },
    {
      day: 'Jueves',
      classes: [
        { subject: 'PENS. MAT I', time: '7:00 - 7:50', teacher: 'MA. GUADALUPE BOLAÑOS CARMONA' },
        { subject: 'PENS. MAT I', time: '7:50 - 8:40', teacher: 'MA. GUADALUPE BOLAÑOS CARMONA' },
        { subject: 'CULT. DIGITAL I', time: '8:40 - 9:30', teacher: 'MARCOS RENÉ GONZÁLEZ ASENCIO' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'LENG. Y COM. I', time: '9:50 - 10:40', teacher: 'KERIME SANCHEZ LOPEZ' },
        { subject: 'LENG. Y COM. I', time: '10:40 - 11:25', teacher: 'KERIME SANCHEZ LOPEZ' },
        { subject: 'PROG DE DISC Y SALUD EMS', time: '11:25 - 12:10', teacher: '' },
      ]
    },
    {
      day: 'Viernes',
      classes: [
        { subject: 'CIENCIAS NATURALES I LAB', time: '7:00 - 7:50', teacher: 'KARLA PERALES TREJO' },
        { subject: 'CIENCIAS NATURALES I LAB', time: '7:50 - 8:40', teacher: 'KARLA PERALES TREJO' },
        { subject: 'REC. SOC. I', time: '8:40 - 9:30', teacher: 'JOSE ANGEL SEGURA CASTILLA' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'CIENCIAS SOCIALES I', time: '9:50 - 10:40', teacher: 'MALINTZIN YAJAIRA GUTIÉRREZ SILVA' },
        { subject: 'TUTORÍAS', time: '10:40 - 11:25', teacher: 'MALINTZIN YAJAIRA GUTIÉRREZ SILVA' },
      ]
    }
  ],
  '1BMTC': [
    {
      day: 'Lunes',
      classes: [
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '7:00 - 7:50', teacher: 'MARITZA PÉREZ GARZA' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '7:50 - 8:40', teacher: 'MARITZA PÉREZ GARZA' },
        { subject: 'REC. SOC. I', time: '8:40 - 9:30', teacher: 'GLADYS MINERVA GONZÁLEZ PAZ' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'LENG. Y COM. I', time: '9:50 - 10:40', teacher: 'KERIME SÁNCHEZ LÓPEZ' },
        { subject: 'LENG. Y COM. I', time: '10:40 - 11:25', teacher: 'KERIME SÁNCHEZ LÓPEZ' },
        { subject: 'TUTORÍAS', time: '11:25 - 12:10', teacher: 'KERIME SÁNCHEZ LÓPEZ' },
      ]
    },
    {
      day: 'Martes',
      classes: [
        { subject: 'PENS. MAT I', time: '7:00 - 7:50', teacher: 'MA. GUADALUPE BOLAÑOS CARMONA' },
        { subject: 'PENS. MAT I', time: '7:50 - 8:40', teacher: 'MA. GUADALUPE BOLAÑOS CARMONA' },
        { subject: 'CULT. DIGITAL I', time: '8:40 - 9:30', teacher: 'MARCOS RENÉ GONZÁLEZ ASENCIO' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'INGLÉS I', time: '9:50 - 10:40', teacher: 'ALEJANDRO IBARRA ALANIS' },
        { subject: 'INGLÉS I', time: '10:40 - 11:25', teacher: 'ALEJANDRO IBARRA ALANIS' },
        { subject: 'CIENCIAS SOCIALES I', time: '11:25 - 12:10', teacher: 'MALINTZIN YAJAIRA GUTIÉRREZ SILVA' },
      ]
    },
    {
      day: 'Miércoles',
      classes: [
        { subject: 'CIENCIAS NATURALES I LAB', time: '7:00 - 7:50', teacher: 'KARLA PERALES TREJO' },
        { subject: 'CIENCIAS NATURALES I LAB', time: '7:50 - 8:40', teacher: 'KARLA PERALES TREJO' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '8:40 - 9:30', teacher: 'MARITZA PÉREZ GARZA' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '9:50 - 10:40', teacher: 'MARITZA PÉREZ GARZA' },
        { subject: 'PROG DE DISC Y SALUD EMS', time: '10:40 - 11:25', teacher: '' },
      ]
    },
    {
      day: 'Jueves',
      classes: [
        { subject: 'CULT. DIGITAL I LAB', time: '7:00 - 7:50', teacher: 'MARCOS RENÉ GONZÁLEZ ASENCIO' },
        { subject: 'CULT. DIGITAL I LAB', time: '7:50 - 8:40', teacher: 'MARCOS RENÉ GONZÁLEZ ASENCIO' },
        { subject: 'LENG. Y COM. I', time: '8:40 - 9:30', teacher: 'KERIME SÁNCHEZ LÓPEZ' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'INGLÉS I', time: '9:50 - 10:40', teacher: 'ALEJANDRO IBARRA ALANIS' },
        { subject: 'CIENCIAS SOCIALES I', time: '10:40 - 11:25', teacher: 'MALINTZIN YAJAIRA GUTIÉRREZ SILVA' },
        { subject: 'PROG DE DISC Y SALUD EMS', time: '11:25 - 12:10', teacher: '' },
      ]
    },
    {
      day: 'Viernes',
      classes: [
        { subject: 'PENS. MAT I', time: '7:00 - 7:50', teacher: 'MA. GUADALUPE BOLAÑOS CARMONA' },
        { subject: 'PENS. MAT I', time: '7:50 - 8:40', teacher: 'MA. GUADALUPE BOLAÑOS CARMONA' },
        { subject: 'CIENCIAS NATURALES I', time: '8:40 - 9:30', teacher: 'KARLA PERALES TREJO' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'CIENCIAS NATURALES I', time: '9:50 - 10:40', teacher: 'KARLA PERALES TREJO' },
        { subject: 'PROG DE DISC Y SALUD EMS', time: '10:40 - 11:25', teacher: '' },
      ]
    }
  ],
  '1GMTC': [
    {
      day: 'Lunes',
      classes: [
        { subject: 'CIENCIAS NATURALES I LAB', time: '7:00 - 7:50', teacher: 'NELLY STEPHANIE ROCHA SOLIS' },
        { subject: 'CIENCIAS NATURALES I LAB', time: '7:50 - 8:40', teacher: 'NELLY STEPHANIE ROCHA SOLIS' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '8:40 - 9:30', teacher: 'MALINTZIN YAJAIRA GUTIÉRREZ SILVA' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '9:50 - 10:40', teacher: 'MALINTZIN YAJAIRA GUTIÉRREZ SILVA' },
        { subject: 'CIENCIAS SOCIALES I', time: '10:40 - 11:25', teacher: 'ROSA ELIA PECINA MORENO' },
        { subject: 'LENG. Y COM. I', time: '11:25 - 12:10', teacher: 'MARÍA DEL CARMEN FLORES ZÁRATE' },
        { subject: 'LENG. Y COM. I', time: '12:10 - 12:55', teacher: 'MARÍA DEL CARMEN FLORES ZÁRATE' },
      ]
    },
    {
      day: 'Martes',
      classes: [
        { subject: 'PROG DE DISC Y SALUD EMS', time: '7:00 - 7:50', teacher: '' },
        { subject: 'REC. SOC. I', time: '7:50 - 8:40', teacher: 'BRENDA ELENA PÉREZ LIMAS' },
        { subject: 'CIENCIAS NATURALES I', time: '8:40 - 9:30', teacher: 'NELLY STEPHANIE ROCHA SOLIS' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'CULT. DIGITAL I', time: '9:50 - 10:40', teacher: 'MARCOS RENÉ GONZÁLEZ ASENCIO' },
        { subject: 'TUTORÍAS', time: '10:40 - 11:25', teacher: 'ROSA ELIA PECINA MORENO' },
      ]
    },
    {
      day: 'Miércoles',
      classes: [
        { subject: 'CULT. DIGITAL I LAB', time: '7:00 - 7:50', teacher: 'MARCOS RENÉ GONZÁLEZ ASENCIO' },
        { subject: 'CULT. DIGITAL I LAB', time: '7:50 - 8:40', teacher: 'MARCOS RENÉ GONZÁLEZ ASENCIO' },
        { subject: 'PENS. MAT. I', time: '8:40 - 9:30', teacher: 'MA. GUADALUPE BOLAÑOS CARMONA' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'PENS. MAT. I', time: '9:50 - 10:40', teacher: 'MA. GUADALUPE BOLAÑOS CARMONA' },
        { subject: 'INGLÉS I', time: '10:40 - 11:25', teacher: 'ALEJANDRO IBARRA ALANIS' },
        { subject: 'CIENCIAS SOCIALES I', time: '11:25 - 12:10', teacher: 'ROSA ELIA PECINA MORENO' },
      ]
    },
    {
      day: 'Jueves',
      classes: [
        { subject: 'TUTORÍAS', time: '7:00 - 7:50', teacher: 'ROSA ELIA PECINA MORENO' },
        { subject: 'PROG DE DISC Y SALUD EMS', time: '7:50 - 8:40', teacher: '' },
        { subject: 'CIENCIAS NATURALES I', time: '8:40 - 9:30', teacher: 'NELLY STEPHANIE ROCHA SOLIS' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'LENG. Y COM. I', time: '9:50 - 10:40', teacher: 'MARÍA DEL CARMEN FLORES ZÁRATE' },
        { subject: 'INGLÉS I', time: '10:40 - 11:25', teacher: 'ALEJANDRO IBARRA ALANIS' },
      ]
    },
    {
      day: 'Viernes',
      classes: [
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '7:00 - 7:50', teacher: 'MALINTZIN YAJAIRA GUTIÉRREZ SILVA' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '7:50 - 8:40', teacher: 'MALINTZIN YAJAIRA GUTIÉRREZ SILVA' },
        { subject: 'PENS. MAT. I', time: '8:40 - 9:30', teacher: 'MA. GUADALUPE BOLAÑOS CARMONA' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'PENS. MAT. I', time: '9:50 - 10:40', teacher: 'MA. GUADALUPE BOLAÑOS CARMONA' },
        { subject: 'INGLÉS I', time: '10:40 - 11:25', teacher: 'ALEJANDRO IBARRA ALANIS' },
      ]
    }
  ],
  '1HMTC': [
    {
      day: 'Lunes',
      classes: [
        { subject: 'LENG. Y COM. I', time: '7:00 - 7:50', teacher: 'GLADYS MINERVA GONZÁLEZ PAZ' },
        { subject: 'LENG. Y COM. I', time: '7:50 - 8:40', teacher: 'GLADYS MINERVA GONZÁLEZ PAZ' },
        { subject: 'TUTORÍAS', time: '8:40 - 9:30', teacher: 'GLADYS MINERVA GONZÁLEZ PAZ' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'INGLÉS I', time: '9:50 - 10:40', teacher: 'ALEJANDRO IBARRA ALANIS' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '10:40 - 11:25', teacher: 'MALINTZIN YAJAIRA GUTIÉRREZ SILVA' },
        { subject: 'CIENCIAS SOCIALES I', time: '11:25 - 12:10', teacher: 'ROSA ELIA PECINA MORENO' },
      ]
    },
    {
      day: 'Martes',
      classes: [
        { subject: 'PENS. MAT. I', time: '7:00 - 7:50', teacher: 'RAYMUNDO MUÑOZ TREVIÑO' },
        { subject: 'PENS. MAT. I', time: '7:50 - 8:40', teacher: 'RAYMUNDO MUÑOZ TREVIÑO' },
        { subject: 'LENG. Y COM. I', time: '8:40 - 9:30', teacher: 'GLADYS MINERVA GONZÁLEZ PAZ' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '9:50 - 10:40', teacher: 'MALINTZIN YAJAIRA GUTIÉRREZ SILVA' },
        { subject: 'PROG DE DISC Y SALUD EMS', time: '10:40 - 11:25', teacher: '' },
      ]
    },
    {
      day: 'Miércoles',
      classes: [
        { subject: 'CIENCIAS SOCIALES I', time: '7:00 - 7:50', teacher: 'ROSA ELIA PECINA MORENO' },
        { subject: 'CIENCIAS NATURALES I', time: '7:50 - 8:40', teacher: 'NELLY STEPHANIE ROCHA SOLIS' },
        { subject: 'CIENCIAS NATURALES I', time: '8:40 - 9:30', teacher: 'NELLY STEPHANIE ROCHA SOLIS' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'CULT. DIGITAL I LAB', time: '9:50 - 10:40', teacher: 'ALBERTO OBREGÓN ZÚÑIGA' },
        { subject: 'CULT. DIGITAL I LAB', time: '10:40 - 11:25', teacher: 'ALBERTO OBREGÓN ZÚÑIGA' },
      ]
    },
    {
      day: 'Jueves',
      classes: [
        { subject: 'PENS. MAT. I', time: '7:00 - 7:50', teacher: 'RAYMUNDO MUÑOZ TREVIÑO' },
        { subject: 'PENS. MAT. I', time: '7:50 - 8:40', teacher: 'RAYMUNDO MUÑOZ TREVIÑO' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '8:40 - 9:30', teacher: 'MALINTZIN YAJAIRA GUTIÉRREZ SILVA' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '9:50 - 10:40', teacher: 'MALINTZIN YAJAIRA GUTIÉRREZ SILVA' },
        { subject: 'REC. SOC. I', time: '10:40 - 11:25', teacher: 'MARITZA PÉREZ GARZA' },
        { subject: 'PROG DE DISC Y SALUD EMS', time: '11:25 - 12:10', teacher: '' },
      ]
    },
    {
      day: 'Viernes',
      classes: [
        { subject: 'INGLÉS I', time: '7:00 - 7:50', teacher: 'ALEJANDRO IBARRA ALANIS' },
        { subject: 'INGLÉS I', time: '7:50 - 8:40', teacher: 'ALEJANDRO IBARRA ALANIS' },
        { subject: 'CIENCIAS NATURALES I LAB', time: '8:40 - 9:30', teacher: 'NELLY STEPHANIE ROCHA SOLIS' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'CIENCIAS NATURALES I LAB', time: '9:50 - 10:40', teacher: 'NELLY STEPHANIE ROCHA SOLIS' },
        { subject: 'CULT. DIGITAL I', time: '10:40 - 11:25', teacher: 'ALBERTO OBREGÓN ZÚÑIGA' },
      ]
    }
  ],
  '1DMTC': [
    {
      day: 'Lunes',
      classes: [
        { subject: 'CULT. DIGITAL I LAB', time: '7:00 - 7:50', teacher: 'MARCOS RENÉ GONZÁLEZ ASENCIO' },
        { subject: 'CULT. DIGITAL I LAB', time: '7:50 - 8:40', teacher: 'MARCOS RENÉ GONZÁLEZ ASENCIO' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '8:40 - 9:30', teacher: 'MARITZA PÉREZ GARZA' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'CIENCIAS SOCIALES I', time: '9:50 - 10:40', teacher: 'ROSA ELIA PECINA MORENO' },
        { subject: 'PROG DE DISC Y SALUD EMS', time: '10:40 - 11:25', teacher: '' },
        { subject: 'CIENCIAS NATURALES I', time: '11:25 - 12:10', teacher: 'KARLA PERALES TREJO' },
      ]
    },
    {
      day: 'Martes',
      classes: [
        { subject: 'PENS. MAT. I', time: '7:00 - 7:50', teacher: 'EDGAR ISAAC AYALA MORALES' },
        { subject: 'PENS. MAT. I', time: '7:50 - 8:40', teacher: 'EDGAR ISAAC AYALA MORALES' },
        { subject: 'REC. SOC. I', time: '8:40 - 9:30', teacher: 'MAYRA ALEJANDRA VERBER WALLE' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'LENG. Y COM. I', time: '9:50 - 10:40', teacher: 'MARÍA DEL CARMEN FLORES ZARATE' },
        { subject: 'LENG. Y COM. I', time: '10:40 - 11:25', teacher: 'MARÍA DEL CARMEN FLORES ZARATE' },
      ]
    },
    {
      day: 'Miércoles',
      classes: [
        { subject: 'INGLÉS I', time: '7:00 - 7:50', teacher: 'ALEJANDRO IBARRA ALANIS' },
        { subject: 'INGLÉS I', time: '7:50 - 8:40', teacher: 'ALEJANDRO IBARRA ALANIS' },
        { subject: 'CIENCIAS SOCIALES I', time: '8:40 - 9:30', teacher: 'ROSA ELIA PECINA MORENO' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'TUTORÍAS', time: '9:50 - 10:40', teacher: 'ROSA ELIA PECINA MORENO' },
        { subject: 'CIENCIAS NATURALES I LAB', time: '10:40 - 11:25', teacher: 'KARLA PERALES TREJO' },
        { subject: 'CIENCIAS NATURALES I LAB', time: '11:25 - 12:10', teacher: 'KARLA PERALES TREJO' },
      ]
    },
    {
      day: 'Jueves',
      classes: [
        { subject: 'PENS. MAT. I', time: '7:00 - 7:50', teacher: 'EDGAR ISAAC AYALA MORALES' },
        { subject: 'PENS. MAT. I', time: '7:50 - 8:40', teacher: 'EDGAR ISAAC AYALA MORALES' },
        { subject: 'INGLÉS I', time: '8:40 - 9:30', teacher: 'ALEJANDRO IBARRA ALANIS' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '9:50 - 10:40', teacher: 'MARITZA PÉREZ GARZA' },
        { subject: 'PROG DE DISC Y SALUD EMS', time: '10:40 - 11:25', teacher: '' },
      ]
    },
    {
      day: 'Viernes',
      classes: [
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '7:00 - 7:50', teacher: 'MARITZA PÉREZ GARZA' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '7:50 - 8:40', teacher: 'MARITZA PÉREZ GARZA' },
        { subject: 'CULT. DIGITAL I', time: '8:40 - 9:30', teacher: 'MARCOS RENÉ GONZÁLEZ ASENCIO' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'LENG. Y COM. I', time: '9:50 - 10:40', teacher: 'MARÍA DEL CARMEN FLORES ZARATE' },
        { subject: 'CIENCIAS NATURALES I', time: '10:40 - 11:25', teacher: 'KARLA PERALES TREJO' },
      ]
    }
  ],
  '1FMTC': [
    {
      day: 'Lunes',
      classes: [
        { subject: 'INGLÉS I', time: '7:00 - 7:50', teacher: 'ALEJANDRO IBARRA ALANIS' },
        { subject: 'CIENCIAS SOCIALES I', time: '7:50 - 8:40', teacher: 'ROSA ELIA PECINA MORENO' },
        { subject: 'PENS. MAT. I', time: '8:40 - 9:30', teacher: 'MA. GUADALUPE BOLAÑOS CARMONA' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'PENS. MAT. I', time: '9:50 - 10:40', teacher: 'MA. GUADALUPE BOLAÑOS CARMONA' },
        { subject: 'PROG DE DISC Y SALUD EMS', time: '10:40 - 11:25', teacher: '' },
      ]
    },
    {
      day: 'Martes',
      classes: [
        { subject: 'INGLÉS I', time: '7:00 - 7:50', teacher: 'ALEJANDRO IBARRA ALANIS' },
        { subject: 'INGLÉS I', time: '7:50 - 8:40', teacher: 'ALEJANDRO IBARRA ALANIS' },
        { subject: 'CULT. DIGITAL I LAB', time: '8:40 - 9:30', teacher: 'JOSÉ ANGEL SEGURA CASTILLA' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'CULT. DIGITAL I LAB', time: '9:50 - 10:40', teacher: 'JOSÉ ANGEL SEGURA CASTILLA' },
        { subject: 'CIENCIAS NATURALES I', time: '10:40 - 11:25', teacher: 'NELLY STEPHANIE ROCHA SOLIS' },
        { subject: 'LENG. Y COM. I', time: '11:25 - 12:10', teacher: 'MARÍA DEL CARMEN FLORES ZARATE' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '12:10 - 12:55', teacher: 'MALINTZIN YAJAIRA GUTIÉRREZ SILVA' },
      ]
    },
    {
      day: 'Miércoles',
      classes: [
        { subject: 'CIENCIAS NATURALES I', time: '7:00 - 7:50', teacher: 'NELLY STEPHANIE ROCHA SOLIS' },
        { subject: 'CIENCIAS SOCIALES I', time: '7:50 - 8:40', teacher: 'ROSA ELIA PECINA MORENO' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '8:40 - 9:30', teacher: 'MALINTZIN YAJAIRA GUTIÉRREZ SILVA' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '9:50 - 10:40', teacher: 'MALINTZIN YAJAIRA GUTIÉRREZ SILVA' },
        { subject: 'PROG DE DISC Y SALUD EMS', time: '10:40 - 11:25', teacher: '' },
      ]
    },
    {
      day: 'Jueves',
      classes: [
        { subject: 'CIENCIAS NATURALES I LAB', time: '7:00 - 7:50', teacher: 'NELLY STEPHANIE ROCHA SOLIS' },
        { subject: 'CIENCIAS NATURALES I LAB', time: '7:50 - 8:40', teacher: 'NELLY STEPHANIE ROCHA SOLIS' },
        { subject: 'PENS. MAT. I', time: '8:40 - 9:30', teacher: 'MA. GUADALUPE BOLAÑOS CARMONA' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'PENS. MAT. I', time: '9:50 - 10:40', teacher: 'MA. GUADALUPE BOLAÑOS CARMONA' },
        { subject: 'LENG. Y COM. I', time: '10:40 - 11:25', teacher: 'MARÍA DEL CARMEN FLORES ZARATE' },
        { subject: 'LENG. Y COM. I', time: '11:25 - 12:10', teacher: 'MARÍA DEL CARMEN FLORES ZARATE' },
      ]
    },
    {
      day: 'Viernes',
      classes: [
        { subject: 'CULT. DIGITAL I', time: '7:00 - 7:50', teacher: 'JOSÉ ANGEL SEGURA CASTILLA' },
        { subject: 'TUTORÍAS', time: '7:50 - 8:40', teacher: 'JOSÉ ANGEL SEGURA CASTILLA' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '8:40 - 9:30', teacher: 'MALINTZIN YAJAIRA GUTIÉRREZ SILVA' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'PENS. MAT. I', time: '9:50 - 10:40', teacher: 'MA. GUADALUPE BOLAÑOS CARMONA' },
        { subject: 'REC. SOC. I', time: '10:40 - 11:25', teacher: 'MARÍA GUADALUPE SANDOVAL LARA' },
      ]
    }
  ],
  '3AML': [
    {
      day: 'Lunes',
      classes: [
        { subject: 'IMBTP LAB', time: '7:00 - 7:50', teacher: 'MAYRA ALEJANDRA VERBER WALLE' },
        { subject: 'IMBTP LAB', time: '7:50 - 8:40', teacher: 'MAYRA ALEJANDRA VERBER WALLE' },
        { subject: 'IMBTP LAB', time: '8:40 - 9:30', teacher: 'MAYRA ALEJANDRA VERBER WALLE' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'HUMANIDADES', time: '9:50 - 10:40', teacher: 'GRASIELA ÁVILA GONZÁLEZ' },
        { subject: 'HUMANIDADES II', time: '10:40 - 11:25', teacher: 'GRASIELA ÁVILA GONZÁLEZ' },
        { subject: 'ECOSISTEMAS', time: '11:25 - 12:10', teacher: 'VIRIDIANA RUIZ GONZÁLEZ' },
        { subject: 'ECOSISTEMAS', time: '12:10 - 12:55', teacher: 'VIRIDIANA RUIZ GONZÁLEZ' },
      ]
    },
    {
      day: 'Martes',
      classes: [
        { subject: 'PENS. MAT III', time: '7:00 - 7:50', teacher: 'ALFREDO RODRÍGUEZ GAUCÍN' },
        { subject: 'PENS. MAT III', time: '7:50 - 8:40', teacher: 'ALFREDO RODRÍGUEZ GAUCÍN' },
        { subject: 'IMBTB LAB', time: '8:40 - 9:30', teacher: 'WENDY GARCÍA VÁZQUEZ' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'IMBTB LAB', time: '9:50 - 10:40', teacher: 'WENDY GARCÍA VÁZQUEZ' },
        { subject: 'IMBTB LAB', time: '10:40 - 11:25', teacher: 'WENDY GARCÍA VÁZQUEZ' },
        { subject: 'LENG. Y COM. III', time: '11:25 - 12:10', teacher: 'NORMA IRAIDA LUNA TORRES' },
        { subject: 'REC. SOC. III', time: '12:10 - 12:55', teacher: 'JOSÉ SIFUENTES CERVANTES' },
      ]
    },
    {
      day: 'Miércoles',
      classes: [
        { subject: 'INGLÉS III', time: '7:00 - 7:50', teacher: 'KARINA LEONOR IBARRA BELMARES' },
        { subject: 'INGLÉS III', time: '7:50 - 8:40', teacher: 'KARINA LEONOR IBARRA BELMARES' },
        { subject: 'IMBTB', time: '8:40 - 9:30', teacher: 'WENDY GARCÍA VÁZQUEZ' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'IMBTB', time: '9:50 - 10:40', teacher: 'WENDY GARCÍA VÁZQUEZ' },
        { subject: 'IMBTB', time: '10:40 - 11:25', teacher: 'WENDY GARCÍA VÁZQUEZ' },
        { subject: 'IMBTP', time: '11:25 - 12:10', teacher: 'MAYRA ALEJANDRA VERBER WALLE' },
        { subject: 'ECOSISTEMAS', time: '12:10 - 12:55', teacher: 'VIRIDIANA RUIZ GONZÁLEZ' },
        { subject: 'ECOSISTEMAS', time: '12:55 - 13:40', teacher: 'VIRIDIANA RUIZ GONZÁLEZ' },
      ]
    },
    {
      day: 'Jueves',
      classes: [
        { subject: 'IMBTP LAB', time: '7:00 - 7:50', teacher: 'MAYRA ALEJANDRA VERBER WALLE' },
        { subject: 'IMBTP LAB', time: '7:50 - 8:40', teacher: 'MAYRA ALEJANDRA VERBER WALLE' },
        { subject: 'IMBTP', time: '8:40 - 9:30', teacher: 'MAYRA ALEJANDRA VERBER WALLE' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'LENG. Y COM. III', time: '9:50 - 10:40', teacher: 'NORMA IRAIDA LUNA TORRES' },
        { subject: 'LENG. Y COM. III', time: '10:40 - 11:25', teacher: 'NORMA IRAIDA LUNA TORRES' },
        { subject: 'TUTORÍAS', time: '11:25 - 12:10', teacher: 'NORMA IRAIDA LUNA TORRES' },
        { subject: 'HUMANIDADES', time: '12:10 - 12:55', teacher: 'GRASIELA ÁVILA GONZÁLEZ' },
        { subject: 'HUMANIDADES II', time: '12:55 - 13:40', teacher: 'GRASIELA ÁVILA GONZÁLEZ' },
      ]
    },
    {
      day: 'Viernes',
      classes: [
        { subject: 'PENS. MAT III', time: '7:00 - 7:50', teacher: 'ALFREDO RODRÍGUEZ GAUCÍN' },
        { subject: 'PENS. MAT III', time: '7:50 - 8:40', teacher: 'ALFREDO RODRÍGUEZ GAUCÍN' },
        { subject: 'INGLÉS III', time: '8:40 - 9:30', teacher: 'KARINA LEONOR IBARRA BELMARES' },
        { subject: 'RECESO', time: '9:30 - 9:50' },
        { subject: 'IMBTB LAB', time: '9:50 - 10:40', teacher: 'WENDY GARCÍA VÁZQUEZ' },
        { subject: 'IMBTB LAB', time: '10:40 - 11:25', teacher: 'WENDY GARCÍA VÁZQUEZ' },
        { subject: 'IMBTB LAB', time: '11:25 - 12:10', teacher: 'WENDY GARCÍA VÁZQUEZ' },
        { subject: 'IMBTB LAB', time: '12:10 - 12:55', teacher: 'WENDY GARCÍA VÁZQUEZ' },
      ]
    }
  ],
  '3AVL': [
    {
      day: 'Lunes',
      classes: [
        { subject: 'LENG. Y COM. III', time: '14:25 - 15:10', teacher: 'JAZMÍN LIZETH VÁZQUEZ HERRERA' },
        { subject: 'IMBTB LAB', time: '15:10 - 15:55', teacher: 'JUAN ANDRÉS SÁNCHEZ PESQUEDA' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'IMBTB LAB', time: '16:15 - 17:00', teacher: 'JUAN ANDRÉS SÁNCHEZ PESQUEDA' },
        { subject: 'IMBTB LAB', time: '17:00 - 17:45', teacher: 'JUAN ANDRÉS SÁNCHEZ PESQUEDA' },
        { subject: 'IMBTP', time: '17:45 - 18:30', teacher: 'JOSÉ FRANCISCO SÁNCHEZ GARCÍA' },
        { subject: 'ECOSISTEMAS', time: '18:30 - 19:15', teacher: 'DAVID MARTÍNEZ RODRÍGUEZ' },
        { subject: 'ECOSISTEMAS', time: '19:15 - 20:00', teacher: 'DAVID MARTÍNEZ RODRÍGUEZ' },
      ]
    },
    {
      day: 'Martes',
      classes: [
        { subject: 'ECOSISTEMAS', time: '13:40 - 14:25', teacher: 'DAVID MARTÍNEZ RODRÍGUEZ' },
        { subject: 'ECOSISTEMAS', time: '14:25 - 15:10', teacher: 'DAVID MARTÍNEZ RODRÍGUEZ' },
        { subject: 'INGLÉS III', time: '15:10 - 15:55', teacher: 'DELFINA MADHAI ORTIZ SALINAS' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'HUMANIDADES II', time: '16:15 - 17:00', teacher: 'CYNTHIA ELENA SALINAS RODRÍGUEZ' },
        { subject: 'HUMANIDADES II', time: '17:00 - 17:45', teacher: 'CYNTHIA ELENA SALINAS RODRÍGUEZ' },
        { subject: 'IMBTP', time: '17:45 - 18:30', teacher: 'JOSÉ FRANCISCO SÁNCHEZ GARCÍA' },
        { subject: 'IMBTP LAB', time: '18:30 - 19:15', teacher: 'JOSÉ FRANCISCO SÁNCHEZ GARCÍA' },
        { subject: 'IMBTP LAB', time: '19:15 - 20:00', teacher: 'JOSÉ FRANCISCO SÁNCHEZ GARCÍA' },
      ]
    },
    {
      day: 'Miércoles',
      classes: [
        { subject: 'REC. SOC. III', time: '13:40 - 14:25', teacher: 'JOSÉ CRUZ LEIJA ÁLVAREZ' },
        { subject: 'PENS. MAT III', time: '14:25 - 15:10', teacher: 'ALFREDO RODRÍGUEZ GAUCÍN' },
        { subject: 'PENS. MAT III', time: '15:10 - 15:55', teacher: 'ALFREDO RODRÍGUEZ GAUCÍN' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'IMBTB LAB', time: '16:15 - 17:00', teacher: 'JUAN ANDRÉS SÁNCHEZ PESQUEDA' },
        { subject: 'IMBTB LAB', time: '17:00 - 17:45', teacher: 'JUAN ANDRÉS SÁNCHEZ PESQUEDA' },
        { subject: 'IMBTB LAB', time: '17:45 - 18:30', teacher: 'JUAN ANDRÉS SÁNCHEZ PESQUEDA' },
        { subject: 'IMBTB LAB', time: '18:30 - 19:15', teacher: 'JUAN ANDRÉS SÁNCHEZ PESQUEDA' },
      ]
    },
    {
      day: 'Jueves',
      classes: [
        { subject: 'LENG. Y COM. III', time: '14:25 - 15:10', teacher: 'JAZMÍN LIZETH VÁZQUEZ HERRERA' },
        { subject: 'LENG. Y COM. III', time: '15:10 - 15:55', teacher: 'JAZMÍN LIZETH VÁZQUEZ HERRERA' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'INGLÉS III', time: '16:15 - 17:00', teacher: 'DELFINA MADHAI ORTIZ SALINAS' },
        { subject: 'INGLÉS III', time: '17:00 - 17:45', teacher: 'DELFINA MADHAI ORTIZ SALINAS' },
        { subject: 'IMBTP LAB', time: '17:45 - 18:30', teacher: 'JOSÉ FRANCISCO SÁNCHEZ GARCÍA' },
        { subject: 'IMBTP LAB', time: '18:30 - 19:15', teacher: 'JOSÉ FRANCISCO SÁNCHEZ GARCÍA' },
        { subject: 'IMBTP LAB', time: '19:15 - 20:00', teacher: 'JOSÉ FRANCISCO SÁNCHEZ GARCÍA' },
      ]
    },
    {
      day: 'Viernes',
      classes: [
        { subject: 'PENS. MAT III', time: '13:40 - 14:25', teacher: 'ALFREDO RODRÍGUEZ GAUCÍN' },
        { subject: 'PENS. MAT III', time: '14:25 - 15:10', teacher: 'ALFREDO RODRÍGUEZ GAUCÍN' },
        { subject: 'TUTORÍAS', time: '15:10 - 15:55', teacher: 'JAZMÍN LIZETH VÁZQUEZ HERRERA' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'HUMANIDADES II', time: '16:15 - 17:00', teacher: 'CYNTHIA ELENA SALINAS RODRÍGUEZ' },
        { subject: 'HUMANIDADES II', time: '17:00 - 17:45', teacher: 'CYNTHIA ELENA SALINAS RODRÍGUEZ' },
        { subject: 'IMBTB LAB', time: '17:45 - 18:30', teacher: 'JUAN ANDRÉS SÁNCHEZ PESQUEDA' },
        { subject: 'IMBTB', time: '18:30 - 19:15', teacher: 'JUAN ANDRÉS SÁNCHEZ PESQUEDA' },
        { subject: 'IMBTB', time: '19:15 - 20:00', teacher: 'JUAN ANDRÉS SÁNCHEZ PESQUEDA' },
      ]
    }
  ],
  '1AVTC': [
    {
      day: 'Lunes',
      classes: [
        { subject: 'INGLÉS I', time: '13:40 - 14:25', teacher: 'ALEJANDRO IBARRA ALANIS' },
        { subject: 'INGLÉS I', time: '14:25 - 15:10', teacher: 'ALEJANDRO IBARRA ALANIS' },
        { subject: 'CULT. DIGITAL I', time: '15:10 - 15:55', teacher: 'MARCOS RENÉ GONZÁLEZ ASENCIO' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'CIENCIAS NATURALES I LAB', time: '16:15 - 17:00', teacher: 'NOE GUADALUPE RAMÍREZ RODRÍGUEZ' },
        { subject: 'CIENCIAS NATURALES I LAB', time: '17:00 - 17:45', teacher: 'NOE GUADALUPE RAMÍREZ RODRÍGUEZ' },
      ]
    },
    {
      day: 'Martes',
      classes: [
        { subject: 'LENG. Y COM. I', time: '13:40 - 14:25', teacher: 'MARÍA DEL CARMEN FLORES ZÁRATE' },
        { subject: 'LENG. Y COM. I', time: '14:25 - 15:10', teacher: 'MARÍA DEL CARMEN FLORES ZÁRATE' },
        { subject: 'CIENCIAS SOCIALES I', time: '15:10 - 15:55', teacher: 'ROSA ELIA PECINA MORENO' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'PENS. MAT. I', time: '16:15 - 17:00', teacher: 'ARNULFO HOMERO GONZÁLEZ MARTÍNEZ' },
        { subject: 'PENS. MAT. I', time: '17:00 - 17:45', teacher: 'ARNULFO HOMERO GONZÁLEZ MARTÍNEZ' },
        { subject: 'PROG DE DISC Y SALUD EMS', time: '17:45 - 18:30', teacher: '' },
      ]
    },
    {
      day: 'Miércoles',
      classes: [
        { subject: 'CULT. DIGITAL I LAB', time: '13:40 - 14:25', teacher: 'MARCOS RENÉ GONZÁLEZ ASENCIO' },
        { subject: 'CULT. DIGITAL I LAB', time: '14:25 - 15:10', teacher: 'MARCOS RENÉ GONZÁLEZ ASENCIO' },
        { subject: 'INGLÉS I', time: '15:10 - 15:55', teacher: 'ALEJANDRO IBARRA ALANIS' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'REC. SOC. I', time: '16:15 - 17:00', teacher: 'JAZMIN LIZETH VÁZQUEZ HERRERA' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '17:00 - 17:45', teacher: 'KARLA AIDEE OLVERA FUERTE' },
        { subject: 'CIENCIAS NATURALES I', time: '17:45 - 18:30', teacher: 'NOE GUADALUPE RAMÍREZ RODRÍGUEZ' },
      ]
    },
    {
      day: 'Jueves',
      classes: [
        { subject: 'CIENCIAS SOCIALES I', time: '13:40 - 14:25', teacher: 'ROSA ELIA PECINA MORENO' },
        { subject: 'CIENCIAS NATURALES I', time: '14:25 - 15:10', teacher: 'NOE GUADALUPE RAMÍREZ RODRÍGUEZ' },
        { subject: 'LENG. Y COM. I', time: '15:10 - 15:55', teacher: 'MARÍA DEL CARMEN FLORES ZÁRATE' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '16:15 - 17:00', teacher: 'KARLA AIDEE OLVERA FUERTE' },
        { subject: 'PROG DE DISC Y SALUD EMS', time: '17:00 - 17:45', teacher: '' },
      ]
    },
    {
      day: 'Viernes',
      classes: [
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '13:40 - 14:25', teacher: 'KARLA AIDEE OLVERA FUERTE' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '14:25 - 15:10', teacher: 'KARLA AIDEE OLVERA FUERTE' },
        { subject: 'TUTORÍAS', time: '15:10 - 15:55', teacher: 'KARLA AIDEE OLVERA FUERTE' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'PENS. MAT. I', time: '16:15 - 17:00', teacher: 'ARNULFO HOMERO GONZÁLEZ MARTÍNEZ' },
        { subject: 'PENS. MAT. I', time: '17:00 - 17:45', teacher: 'ARNULFO HOMERO GONZÁLEZ MARTÍNEZ' },
      ]
    }
  ],
  '1BVTC': [
    {
      day: 'Lunes',
      classes: [
        { subject: 'CULT. DIGITAL I LAB', time: '13:40 - 14:25', teacher: 'MARCOS RENÉ GONZÁLEZ ASENCIO' },
        { subject: 'CULT. DIGITAL I LAB', time: '14:25 - 15:10', teacher: 'MARCOS RENÉ GONZÁLEZ ASENCIO' },
        { subject: 'INGLÉS I', time: '15:10 - 15:55', teacher: 'ALEJANDRO IBARRA ALANIS' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'PENS. MAT. I', time: '16:15 - 17:00', teacher: 'ARNULFO HOMERO GONZÁLEZ MARTÍNEZ' },
        { subject: 'PENS. MAT. I', time: '17:00 - 17:45', teacher: 'ARNULFO HOMERO GONZÁLEZ MARTÍNEZ' },
        { subject: 'TUTORÍAS', time: '17:45 - 18:30', teacher: 'ARNULFO HOMERO GONZÁLEZ MARTÍNEZ' },
      ]
    },
    {
      day: 'Martes',
      classes: [
        { subject: 'CULT. DIGITAL I', time: '13:40 - 14:25', teacher: 'MARCOS RENÉ GONZÁLEZ ASENCIO' },
        { subject: 'CIENCIAS SOCIALES I', time: '14:25 - 15:10', teacher: 'ROSA ELIA PECINA MORENO' },
        { subject: 'LENG. Y COM. I', time: '15:10 - 15:55', teacher: 'MARÍA DEL CARMEN FLORES ZÁRATE' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '16:15 - 17:00', teacher: 'KARLA AIDEE OLVERA FUERTE' },
        { subject: 'REC. SOC. I', time: '17:00 - 17:45', teacher: 'JOSÉ FRANCISCO SÁNCHEZ GARCÍA' },
        { subject: 'PROG DE DISC Y SALUD EMS', time: '17:45 - 18:30', teacher: '' },
      ]
    },
    {
      day: 'Miércoles',
      classes: [
        { subject: 'INGLÉS I', time: '13:40 - 14:25', teacher: 'ALEJANDRO IBARRA ALANIS' },
        { subject: 'INGLÉS I', time: '14:25 - 15:10', teacher: 'ALEJANDRO IBARRA ALANIS' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '15:10 - 15:55', teacher: 'KARLA AIDEE OLVERA FUERTE' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '16:15 - 17:00', teacher: 'KARLA AIDEE OLVERA FUERTE' },
        { subject: 'CIENCIAS NATURALES I', time: '17:00 - 17:45', teacher: 'NOE GUADALUPE RAMÍREZ RODRÍGUEZ' },
      ]
    },
    {
      day: 'Jueves',
      classes: [
        { subject: 'CIENCIAS NATURALES I', time: '13:40 - 14:25', teacher: 'NOE GUADALUPE RAMÍREZ RODRÍGUEZ' },
        { subject: 'CIENCIAS SOCIALES I', time: '14:25 - 15:10', teacher: 'ROSA ELIA PECINA MORENO' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '15:10 - 15:55', teacher: 'KARLA AIDEE OLVERA FUERTE' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'PENS. MAT. I', time: '16:15 - 17:00', teacher: 'ARNULFO HOMERO GONZÁLEZ MARTÍNEZ' },
        { subject: 'PENS. MAT. I', time: '17:00 - 17:45', teacher: 'ARNULFO HOMERO GONZÁLEZ MARTÍNEZ' },
      ]
    },
    {
      day: 'Viernes',
      classes: [
        { subject: 'LENG. Y COM. I', time: '13:40 - 14:25', teacher: 'MARÍA DEL CARMEN FLORES ZÁRATE' },
        { subject: 'LENG. Y COM. I', time: '14:25 - 15:10', teacher: 'MARÍA DEL CARMEN FLORES ZÁRATE' },
        { subject: 'CIENCIAS NATURALES I LAB', time: '15:10 - 15:55', teacher: 'NOE GUADALUPE RAMÍREZ RODRÍGUEZ' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'CIENCIAS NATURALES I LAB', time: '16:15 - 17:00', teacher: 'NOE GUADALUPE RAMÍREZ RODRÍGUEZ' },
        { subject: 'PROG DE DISC Y SALUD EMS', time: '17:00 - 17:45', teacher: '' },
      ]
    }
  ],
  '1CVTC': [
    {
      day: 'Lunes',
      classes: [
        { subject: 'CIENCIAS NATURALES I LAB', time: '13:40 - 14:25', teacher: 'NOE GUADALUPE RAMÍREZ RODRÍGUEZ' },
        { subject: 'CIENCIAS NATURALES I LAB', time: '14:25 - 15:10', teacher: 'NOE GUADALUPE RAMÍREZ RODRÍGUEZ' },
        { subject: 'CULT. DIGITAL I LAB', time: '15:10 - 15:55', teacher: 'BEATRIZ ADRIANA GARZA GARZA' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'CULT. DIGITAL I LAB', time: '16:15 - 17:00', teacher: 'BEATRIZ ADRIANA GARZA GARZA' },
        { subject: 'PROG DE DISC Y SALUD EMS', time: '17:00 - 17:45', teacher: '' },
      ]
    },
    {
      day: 'Martes',
      classes: [
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '13:40 - 14:25', teacher: 'GRACIELA EDITH GONZÁLEZ CHAPA' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '14:25 - 15:10', teacher: 'GRACIELA EDITH GONZÁLEZ CHAPA' },
        { subject: 'CIENCIAS SOCIALES I', time: '15:10 - 15:55', teacher: 'KARLA AIDEE OLVERA FUERTE' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'INGLÉS I', time: '16:15 - 17:00', teacher: 'ALEJANDRO IBARRA ALANIS' },
        { subject: 'INGLÉS I', time: '17:00 - 17:45', teacher: 'ALEJANDRO IBARRA ALANIS' },
        { subject: 'PENS. MAT. I', time: '17:45 - 18:30', teacher: 'ARNULFO HOMERO GONZÁLEZ MARTÍNEZ' },
      ]
    },
    {
      day: 'Miércoles',
      classes: [
        { subject: 'LENG. Y COM. I', time: '13:40 - 14:25', teacher: 'MARÍA DEL CARMEN FLORES ZÁRATE' },
        { subject: 'LENG. Y COM. I', time: '14:25 - 15:10', teacher: 'MARÍA DEL CARMEN FLORES ZÁRATE' },
        { subject: 'CULT. DIGITAL I', time: '15:10 - 15:55', teacher: 'BEATRIZ ADRIANA GARZA GARZA' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'PENS. MAT. I', time: '16:15 - 17:00', teacher: 'ARNULFO HOMERO GONZÁLEZ MARTÍNEZ' },
        { subject: 'PENS. MAT. I', time: '17:00 - 17:45', teacher: 'ARNULFO HOMERO GONZÁLEZ MARTÍNEZ' },
      ]
    },
    {
      day: 'Jueves',
      classes: [
        { subject: 'REC. SOC. I', time: '13:40 - 14:25', teacher: 'BRENDA ELENA PÉREZ LIMAS' },
        { subject: 'LENG. Y COM. I', time: '14:25 - 15:10', teacher: 'MARÍA DEL CARMEN FLORES ZÁRATE' },
        { subject: 'CIENCIAS NATURALES I', time: '15:10 - 15:55', teacher: 'NOE GUADALUPE RAMÍREZ RODRÍGUEZ' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'CIENCIAS NATURALES I', time: '16:15 - 17:00', teacher: 'NOE GUADALUPE RAMÍREZ RODRÍGUEZ' },
        { subject: 'CIENCIAS SOCIALES I', time: '17:00 - 17:45', teacher: 'KARLA AIDEE OLVERA FUERTE' },
        { subject: 'PENS. MAT. I', time: '17:45 - 18:30', teacher: 'ARNULFO HOMERO GONZÁLEZ MARTÍNEZ' },
      ]
    },
    {
      day: 'Viernes',
      classes: [
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '13:40 - 14:25', teacher: 'GRACIELA EDITH GONZÁLEZ CHAPA' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '14:25 - 15:10', teacher: 'GRACIELA EDITH GONZÁLEZ CHAPA' },
        { subject: 'INGLÉS I', time: '15:10 - 15:55', teacher: 'ALEJANDRO IBARRA ALANIS' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'TUTORÍAS', time: '16:15 - 17:00', teacher: 'JOSÉ SIFUENTES CERVANTES' },
        { subject: 'PROG DE DISC Y SALUD EMS', time: '17:00 - 17:45', teacher: '' },
      ]
    }
  ],
  '1DVTC': [
    {
      day: 'Lunes',
      classes: [
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '13:40 - 14:25', teacher: 'GRACIELA EDITH GONZÁLEZ CHAPA' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '14:25 - 15:10', teacher: 'GRACIELA EDITH GONZÁLEZ CHAPA' },
        { subject: 'CIENCIAS NATURALES I', time: '15:10 - 15:55', teacher: 'NOE GUADALUPE RAMÍREZ RODRÍGUEZ' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'PENS. MAT. I', time: '16:15 - 17:00', teacher: 'GAUDENCIO FELICIANO MARTINEZ' },
        { subject: 'PENS. MAT. I', time: '17:00 - 17:45', teacher: 'GAUDENCIO FELICIANO MARTINEZ' },
        { subject: 'TUTORÍAS', time: '17:45 - 18:30', teacher: 'GAUDENCIO FELICIANO MARTINEZ' },
      ]
    },
    {
      day: 'Martes',
      classes: [
        { subject: 'CULT. DIGITAL I LAB', time: '13:40 - 14:25', teacher: 'BEATRIZ ADRIANA GARZA GARZA' },
        { subject: 'CULT. DIGITAL I LAB', time: '14:25 - 15:10', teacher: 'BEATRIZ ADRIANA GARZA GARZA' },
        { subject: 'INGLÉS I', time: '15:10 - 15:55', teacher: 'ALEJANDRO IBARRA ALANIS' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'REC. SOC. I', time: '16:15 - 17:00', teacher: 'MARCOS RENÉ GONZÁLEZ ASENCIO' },
        { subject: 'PROG DE DISC Y SALUD EMS', time: '17:00 - 17:45', teacher: '' },
      ]
    },
    {
      day: 'Miércoles',
      classes: [
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '13:40 - 14:25', teacher: 'GRACIELA EDITH GONZÁLEZ CHAPA' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '14:25 - 15:10', teacher: 'GRACIELA EDITH GONZÁLEZ CHAPA' },
        { subject: 'LENG. Y COM. I', time: '15:10 - 15:55', teacher: 'MARÍA DEL CARMEN FLORES ZÁRATE' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'CIENCIAS NATURALES I', time: '16:15 - 17:00', teacher: 'NOE GUADALUPE RAMÍREZ RODRÍGUEZ' },
      ]
    },
    {
      day: 'Jueves',
      classes: [
        { subject: 'LENG. Y COM. I', time: '13:40 - 14:25', teacher: 'MARÍA DEL CARMEN FLORES ZÁRATE' },
        { subject: 'CIENCIAS SOCIALES I', time: '14:25 - 15:10', teacher: 'KARLA AIDEE OLVERA FUERTE' },
        { subject: 'CULT. DIGITAL I', time: '15:10 - 15:55', teacher: 'BEATRIZ ADRIANA GARZA GARZA' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'PENS. MAT. I', time: '16:15 - 17:00', teacher: 'GAUDENCIO FELICIANO MARTINEZ' },
        { subject: 'PENS. MAT. I', time: '17:00 - 17:45', teacher: 'GAUDENCIO FELICIANO MARTINEZ' },
        { subject: 'PROG DE DISC Y SALUD EMS', time: '17:45 - 18:30', teacher: '' },
      ]
    },
    {
      day: 'Viernes',
      classes: [
        { subject: 'INGLÉS I', time: '13:40 - 14:25', teacher: 'ALEJANDRO IBARRA ALANIS' },
        { subject: 'INGLÉS I', time: '14:25 - 15:10', teacher: 'ALEJANDRO IBARRA ALANIS' },
        { subject: 'LENG. Y COM. I', time: '15:10 - 15:55', teacher: 'MARÍA DEL CARMEN FLORES ZÁRATE' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'CIENCIAS NATURALES I', time: '16:15 - 17:00', teacher: 'NOE GUADALUPE RAMÍREZ RODRÍGUEZ' },
        { subject: 'CIENCIAS NATURALES I LAB', time: '17:00 - 17:45', teacher: 'NOE GUADALUPE RAMÍREZ RODRÍGUEZ' },
        { subject: 'CIENCIAS NATURALES I LAB', time: '17:45 - 18:30', teacher: 'NOE GUADALUPE RAMÍREZ RODRÍGUEZ' },
      ]
    }
  ],
  '1EVTC': [
    {
      day: 'Lunes',
      classes: [
        { subject: 'LENG. Y COM. I', time: '13:40 - 14:25', teacher: 'JUVENTINO PÉREZ FLORES' },
        { subject: 'LENG. Y COM. I', time: '14:25 - 15:10', teacher: 'JUVENTINO PÉREZ FLORES' },
        { subject: 'PENS. MAT. I', time: '15:10 - 15:55', teacher: 'ARNULFO HOMERO GONZÁLEZ MARTÍNEZ' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'CIENCIAS SOCIALES I', time: '16:15 - 17:00', teacher: 'KARLA AIDEE OLVERA FUERTE' },
        { subject: 'TUTORÍAS', time: '17:00 - 17:45', teacher: 'JUVENTINO PÉREZ FLORES' },
      ]
    },
    {
      day: 'Martes',
      classes: [
        { subject: 'CIENCIAS SOCIALES I', time: '13:40 - 14:25', teacher: 'KARLA AIDEE OLVERA FUERTE' },
        { subject: 'CULT. DIGITAL I', time: '14:25 - 15:10', teacher: 'MARCOS RENÉ GONZÁLEZ ASENCIO' },
        { subject: 'REC. SOC. I', time: '15:10 - 15:55', teacher: 'PATRICIA GONZÁLEZ RAMOS' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '16:15 - 17:00', teacher: 'GRACIELA EDITH GONZÁLEZ CHAPA' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '17:00 - 17:45', teacher: 'GRACIELA EDITH GONZÁLEZ CHAPA' },
        { subject: 'PROG DE DISC Y SALUD EMS', time: '17:45 - 18:30', teacher: '' },
      ]
    },
    {
      day: 'Miércoles',
      classes: [
        { subject: 'CIENCIAS NATURALES I LAB', time: '13:40 - 14:25', teacher: 'NOE GUADALUPE RAMÍREZ RODRÍGUEZ' },
        { subject: 'CIENCIAS NATURALES I LAB', time: '14:25 - 15:10', teacher: 'NOE GUADALUPE RAMÍREZ RODRÍGUEZ' },
        { subject: 'PENS. MAT. I', time: '15:10 - 15:55', teacher: 'ARNULFO HOMERO GONZÁLEZ MARTÍNEZ' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'INGLÉS I', time: '16:15 - 17:00', teacher: 'ALAIN RODRIGO BAUTISTA JAIME' },
        { subject: 'INGLÉS I', time: '17:00 - 17:45', teacher: 'ALAIN RODRIGO BAUTISTA JAIME' },
      ]
    },
    {
      day: 'Jueves',
      classes: [
        { subject: 'CULT. DIGITAL I LAB', time: '13:40 - 14:25', teacher: 'MARCOS RENÉ GONZÁLEZ ASENCIO' },
        { subject: 'CULT. DIGITAL I LAB', time: '14:25 - 15:10', teacher: 'MARCOS RENÉ GONZÁLEZ ASENCIO' },
        { subject: 'PENS. MAT. I', time: '15:10 - 15:55', teacher: 'ARNULFO HOMERO GONZÁLEZ MARTÍNEZ' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'LENG. Y COM. I', time: '16:15 - 17:00', teacher: 'JUVENTINO PÉREZ FLORES' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '17:00 - 17:45', teacher: 'GRACIELA EDITH GONZÁLEZ CHAPA' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '17:45 - 18:30', teacher: 'GRACIELA EDITH GONZÁLEZ CHAPA' },
      ]
    },
    {
      day: 'Viernes',
      classes: [
        { subject: 'CIENCIAS NATURALES I', time: '13:40 - 14:25', teacher: 'NOE GUADALUPE RAMÍREZ RODRÍGUEZ' },
        { subject: 'CIENCIAS NATURALES I', time: '14:25 - 15:10', teacher: 'NOE GUADALUPE RAMÍREZ RODRÍGUEZ' },
        { subject: 'PENS. MAT. I', time: '15:10 - 15:55', teacher: 'ARNULFO HOMERO GONZÁLEZ MARTÍNEZ' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'INGLÉS I', time: '16:15 - 17:00', teacher: 'ALAIN RODRIGO BAUTISTA JAIME' },
        { subject: 'PROG DE DISC Y SALUD EMS', time: '17:00 - 17:45', teacher: '' },
      ]
    }
  ],
  '1FVTC': [
    {
      day: 'Lunes',
      classes: [
        { subject: 'INGLÉS I', time: '13:40 - 14:25', teacher: 'ALAIN RODRIGO BAUTISTA JAIME' },
        { subject: 'INGLÉS I', time: '14:25 - 15:10', teacher: 'ALAIN RODRIGO BAUTISTA JAIME' },
        { subject: 'CIENCIAS SOCIALES I', time: '15:10 - 15:55', teacher: 'KARLA AIDEE OLVERA FUERTE' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'TUTORÍAS', time: '16:15 - 17:00', teacher: 'DANIEL PONCE HERNANDEZ' },
        { subject: 'PROG DE DISC Y SALUD EMS', time: '17:00 - 17:45', teacher: '' },
        { subject: 'CIENCIAS NATURALES I', time: '17:45 - 18:30', teacher: 'NOE GUADALUPE RAMÍREZ RODRÍGUEZ' },
      ]
    },
    {
      day: 'Martes',
      classes: [
        { subject: 'CIENCIAS NATURALES I', time: '13:40 - 14:25', teacher: 'NOE GUADALUPE RAMÍREZ RODRÍGUEZ' },
        { subject: 'CIENCIAS SOCIALES I', time: '14:25 - 15:10', teacher: 'KARLA AIDEE OLVERA FUERTE' },
        { subject: 'REC. SOC. I', time: '15:10 - 15:55', teacher: 'MARCOS RENÉ GONZÁLEZ ASENCIO' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'PENS. MAT. I', time: '16:15 - 17:00', teacher: 'GAUDENCIO FELICIANO MARTINEZ' },
        { subject: 'PENS. MAT. I', time: '17:00 - 17:45', teacher: 'GAUDENCIO FELICIANO MARTINEZ' },
      ]
    },
    {
      day: 'Miércoles',
      classes: [
        { subject: 'LENG. Y COM. I', time: '13:40 - 14:25', teacher: 'JUVENTINO PÉREZ FLORES' },
        { subject: 'LENG. Y COM. I', time: '14:25 - 15:10', teacher: 'JUVENTINO PÉREZ FLORES' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '15:10 - 15:55', teacher: 'GRACIELA EDITH GONZÁLEZ CHAPA' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '16:15 - 17:00', teacher: 'GRACIELA EDITH GONZÁLEZ CHAPA' },
        { subject: 'PENS. MAT. I', time: '17:00 - 17:45', teacher: 'GAUDENCIO FELICIANO MARTINEZ' },
        { subject: 'PENS. MAT. I', time: '17:45 - 18:30', teacher: 'GAUDENCIO FELICIANO MARTINEZ' },
      ]
    },
    {
      day: 'Jueves',
      classes: [
        { subject: 'INGLÉS I', time: '14:25 - 15:10', teacher: 'ALAIN RODRIGO BAUTISTA JAIME' },
        { subject: 'LENG. Y COM. I', time: '15:10 - 15:55', teacher: 'JUVENTINO PÉREZ FLORES' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'CULT. DIGITAL I', time: '16:15 - 17:00', teacher: 'BEATRIZ ADRIANA GARZA GARZA' },
        { subject: 'CIENCIAS NATURALES I LAB', time: '17:00 - 17:45', teacher: 'NOE GUADALUPE RAMÍREZ RODRÍGUEZ' },
        { subject: 'CIENCIAS NATURALES I LAB', time: '17:45 - 18:30', teacher: 'NOE GUADALUPE RAMÍREZ RODRÍGUEZ' },
      ]
    },
    {
      day: 'Viernes',
      classes: [
        { subject: 'CULT. DIGITAL I LAB', time: '13:40 - 14:25', teacher: 'BEATRIZ ADRIANA GARZA GARZA' },
        { subject: 'CULT. DIGITAL I LAB', time: '14:25 - 15:10', teacher: 'BEATRIZ ADRIANA GARZA GARZA' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '15:10 - 15:55', teacher: 'GRACIELA EDITH GONZÁLEZ CHAPA' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '16:15 - 17:00', teacher: 'GRACIELA EDITH GONZÁLEZ CHAPA' },
        { subject: 'PROG DE DISC Y SALUD EMS', time: '17:00 - 17:45', teacher: '' },
      ]
    }
  ],
  '1GVTC': [
    {
      day: 'Lunes',
      classes: [
        { subject: 'REC. SOC. I', time: '13:40 - 14:25', teacher: 'PATRICIA GONZÁLEZ RAMOS' },
        { subject: 'CIENCIAS SOCIALES I', time: '14:25 - 15:10', teacher: 'KARLA AIDEE OLVERA FUERTE' },
        { subject: 'LENG. Y COM. I', time: '15:10 - 15:55', teacher: 'JUVENTINO PÉREZ FLORES' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'CULT. DIGITAL I', time: '16:15 - 17:00', teacher: 'MARCOS RENÉ GONZÁLEZ ASENCIO' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '17:00 - 17:45', teacher: 'GRACIELA EDITH GONZÁLEZ CHAPA' },
        { subject: 'PROG DE DISC Y SALUD EMS', time: '17:45 - 18:30', teacher: '' },
        { subject: 'CIENCIAS NATURALES I', time: '18:30 - 19:15', teacher: 'NOE GUADALUPE RAMÍREZ RODRÍGUEZ' },
      ]
    },
    {
      day: 'Martes',
      classes: [
        { subject: 'INGLÉS I', time: '13:40 - 14:25', teacher: 'ALAIN RODRIGO BAUTISTA JAIME' },
        { subject: 'INGLÉS I', time: '14:25 - 15:10', teacher: 'ALAIN RODRIGO BAUTISTA JAIME' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '15:10 - 15:55', teacher: 'GRACIELA EDITH GONZÁLEZ CHAPA' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'CIENCIAS NATURALES I LAB', time: '16:15 - 17:00', teacher: 'NOE GUADALUPE RAMÍREZ RODRÍGUEZ' },
        { subject: 'CIENCIAS NATURALES I LAB', time: '17:00 - 17:45', teacher: 'NOE GUADALUPE RAMÍREZ RODRÍGUEZ' },
      ]
    },
    {
      day: 'Miércoles',
      classes: [
        { subject: 'INGLÉS I', time: '13:40 - 14:25', teacher: 'ALAIN RODRIGO BAUTISTA JAIME' },
        { subject: 'INGLÉS I', time: '14:25 - 15:10', teacher: 'ALAIN RODRIGO BAUTISTA JAIME' },
        { subject: 'PENS. MAT. I', time: '15:10 - 15:55', teacher: 'GAUDENCIO FELICIANO MARTINEZ' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'PENS. MAT. I', time: '16:15 - 17:00', teacher: 'GAUDENCIO FELICIANO MARTINEZ' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '17:00 - 17:45', teacher: 'GRACIELA EDITH GONZÁLEZ CHAPA' },
      ]
    },
    {
      day: 'Jueves',
      classes: [
        { subject: 'CIENCIAS SOCIALES I', time: '13:40 - 14:25', teacher: 'KARLA AIDEE OLVERA FUERTE' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '14:25 - 15:10', teacher: 'GRACIELA EDITH GONZÁLEZ CHAPA' },
        { subject: 'CULT. DIGITAL I LAB', time: '15:10 - 15:55', teacher: 'MARCOS RENÉ GONZÁLEZ ASENCIO' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'CULT. DIGITAL I LAB', time: '16:15 - 17:00', teacher: 'MARCOS RENÉ GONZÁLEZ ASENCIO' },
        { subject: 'TUTORÍAS', time: '17:00 - 17:45', teacher: 'MARCOS RENÉ GONZÁLEZ ASENCIO' },
        { subject: 'PROG DE DISC Y SALUD EMS', time: '17:45 - 18:30', teacher: '' },
        { subject: 'CIENCIAS NATURALES I', time: '18:30 - 19:15', teacher: 'NOE GUADALUPE RAMÍREZ RODRÍGUEZ' },
      ]
    },
    {
      day: 'Viernes',
      classes: [
        { subject: 'LENG. Y COM. I', time: '13:40 - 14:25', teacher: 'JUVENTINO PÉREZ FLORES' },
        { subject: 'LENG. Y COM. I', time: '14:25 - 15:10', teacher: 'JUVENTINO PÉREZ FLORES' },
        { subject: 'PENS. MAT. I', time: '15:10 - 15:55', teacher: 'GAUDENCIO FELICIANO MARTINEZ' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'PENS. MAT. I', time: '16:15 - 17:00', teacher: 'GAUDENCIO FELICIANO MARTINEZ' },
      ]
    }
  ],
  '1HVTC': [
    {
      day: 'Lunes',
      classes: [
        { subject: 'CIENCIAS NATURALES I', time: '13:40 - 14:25', teacher: 'KARLA PERALES TREJO' },
        { subject: 'CIENCIAS NATURALES I', time: '14:25 - 15:10', teacher: 'KARLA PERALES TREJO' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '15:10 - 15:55', teacher: 'GRACIELA EDITH GONZÁLEZ CHAPA' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '16:15 - 17:00', teacher: 'GRACIELA EDITH GONZÁLEZ CHAPA' },
        { subject: 'INGLÉS I', time: '17:00 - 17:45', teacher: 'ALAIN RODRIGO BAUTISTA JAIME' },
      ]
    },
    {
      day: 'Martes',
      classes: [
        { subject: 'LENG. Y COM. I', time: '13:40 - 14:25', teacher: 'JUVENTINO PÉREZ FLORES' },
        { subject: 'LENG. Y COM. I', time: '14:25 - 15:10', teacher: 'JUVENTINO PÉREZ FLORES' },
        { subject: 'REC. SOC. I', time: '15:10 - 15:55', teacher: 'ARNULFO HOMERO GONZÁLEZ MARTÍNEZ' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'CIENCIAS SOCIALES I', time: '16:15 - 17:00', teacher: 'PATRICIA GONZÁLEZ RAMOS' },
        { subject: 'PROG DE DISC Y SALUD EMS', time: '17:00 - 17:45', teacher: '' },
        { subject: 'PENS. MAT. I', time: '17:45 - 18:30', teacher: 'GAUDENCIO FELICIANO MARTINEZ' },
      ]
    },
    {
      day: 'Miércoles',
      classes: [
        { subject: 'TUTORÍAS', time: '13:40 - 14:25', teacher: 'BEATRIZ ADRIANA GARZA GARZA' },
        { subject: 'CIENCIAS SOCIALES I', time: '14:25 - 15:10', teacher: 'PATRICIA GONZÁLEZ RAMOS' },
        { subject: 'INGLÉS I', time: '15:10 - 15:55', teacher: 'ALAIN RODRIGO BAUTISTA JAIME' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'CULT. DIGITAL I LAB', time: '16:15 - 17:00', teacher: 'BEATRIZ ADRIANA GARZA GARZA' },
        { subject: 'CULT. DIGITAL I LAB', time: '17:00 - 17:45', teacher: 'BEATRIZ ADRIANA GARZA GARZA' },
      ]
    },
    {
      day: 'Jueves',
      classes: [
        { subject: 'CIENCIAS NATURALES I LAB', time: '13:40 - 14:25', teacher: 'KARLA PERALES TREJO' },
        { subject: 'CIENCIAS NATURALES I LAB', time: '14:25 - 15:10', teacher: 'KARLA PERALES TREJO' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '15:10 - 15:55', teacher: 'GRACIELA EDITH GONZÁLEZ CHAPA' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'PENS. FIL. Y HUMANIDADES I', time: '16:15 - 17:00', teacher: 'GRACIELA EDITH GONZÁLEZ CHAPA' },
        { subject: 'INGLÉS I', time: '17:00 - 17:45', teacher: 'ALAIN RODRIGO BAUTISTA JAIME' },
        { subject: 'PENS. MAT. I', time: '17:45 - 18:30', teacher: 'GAUDENCIO FELICIANO MARTINEZ' },
      ]
    },
    {
      day: 'Viernes',
      classes: [
        { subject: 'PROG DE DISC Y SALUD EMS', time: '14:25 - 15:10', teacher: '' },
        { subject: 'CULT. DIGITAL I', time: '15:10 - 15:55', teacher: 'BEATRIZ ADRIANA GARZA GARZA' },
        { subject: 'RECESO', time: '15:55 - 16:15' },
        { subject: 'LENG. Y COM. I', time: '16:15 - 17:00', teacher: 'JUVENTINO PÉREZ FLORES' },
        { subject: 'PENS. MAT. I', time: '17:00 - 17:45', teacher: 'GAUDENCIO FELICIANO MARTINEZ' },
        { subject: 'PENS. MAT. I', time: '17:45 - 18:30', teacher: 'GAUDENCIO FELICIANO MARTINEZ' },
      ]
    }
  ]
};
