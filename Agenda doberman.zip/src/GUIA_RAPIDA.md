# ⚡ GUÍA RÁPIDA - AGENDA DOBERMAN

## 🚀 Inicio Rápido en 3 Pasos

### 1️⃣ Registrarse
```
📧 Ingresa tu correo → 👋 Pantalla de bienvenida → 🎭 Elige rol (Alumno/Docente)
```

### 2️⃣ Configurar Perfil
```
👤 Nombre completo → 🏫 Selecciona salón(es) → ✅ Guardar
```

### 3️⃣ ¡Listo para usar!
```
Navega por las pestañas: CALENDARIO | TAREAS | HORARIO | NOTAS | CALIFICACIONES
```

---

## 👨‍🎓 ALUMNO - Acciones Principales

### ✅ TAREAS
| Acción | Pasos |
|--------|-------|
| ➕ **Agregar** | Clic "Nueva Tarea" → Llenar datos → Guardar |
| ✔️ **Completar** | Clic en checkbox ☑️ de la tarea |
| 🗑️ **Eliminar** | Clic en icono de basura |

### 📝 NOTAS
| Acción | Pasos |
|--------|-------|
| ➕ **Crear** | Clic "Nueva Nota" → Título + Materia + Contenido → Guardar |
| ✏️ **Editar** | Clic en icono lápiz ✏️ → Modificar → Guardar cambios |

### 📊 CALIFICACIONES
| Acción | Pasos |
|--------|-------|
| 👁️ **Ver** | Ir a pestaña CALIFICACIONES → Ver tabla con promedios |
| ➕ **Agregar** | Clic "Agregar Calificación" → Materia + Puntos → Guardar |

### 🕐 HORARIO
| Acción | Pasos |
|--------|-------|
| 👁️ **Ver** | Ir a pestaña HORARIO → Consultar por día |

---

## 👨‍🏫 DOCENTE - Acciones Principales

### 📋 LISTAS (Asistencia)
| Acción | Pasos |
|--------|-------|
| 📍 **Seleccionar** | Salón → Fecha |
| 🔍 **Buscar alumno** | Escribir nombre/control en buscador |
| ✅ **Presente** | Clic botón verde ✓ |
| ⏰ **Retardo** | Clic botón amarillo ⏰ |
| ❌ **Ausente** | Clic botón rojo ✗ |
| 🎯 **Todos presentes** | Clic "Marcar Todos como Presentes" |

### 📊 REVISADOS (Calificaciones)
| Acción | Pasos |
|--------|-------|
| ➕ **Nueva actividad** | Clic "Nueva Actividad" → Nombre + Puntos máx. → Crear |
| 🎯 **Seleccionar** | Salón → Actividad |
| 📝 **Calificar** | Buscar alumno → Ingresar puntos → Clic ✓ Guardar |
| ✏️ **Editar** | Cambiar puntos → Clic ✓ Guardar |
| 📈 **Ver estadísticas** | Revisar panel superior (Total, Calificados, Pendientes, Promedio) |

### 🕐 HORARIO
| Acción | Pasos |
|--------|-------|
| 👁️ **Ver** | Ir a HORARIO → Ver clases por día |
| ✏️ **Editar** | Clic "Editar Horario" → Modificar → Guardar |

---

## 📡 Estados de Conexión

| Icono | Color | Significado | Qué hacer |
|-------|-------|-------------|-----------|
| 📶 ✓ | 🟢 Verde | Conectado y sincronizado | ¡Todo bien! |
| 📶 ⚠️ | 🟡 Amarillo | Sin conexión | Sigue trabajando, se guardará local |
| 🔄 | 🔵 Azul | Sincronizando | Espera o fuerza sincronización |

---

## 🎨 Código de Colores

### Prioridades de Tareas
- 🔴 **ALTA** = Urgente
- 🟡 **MEDIA** = Normal
- 🟢 **BAJA** = Sin prisa

### Calificaciones
- 🟢 **90-100** = Excelente
- 🔵 **80-89** = Muy bien
- 🟡 **70-79** = Bien
- 🟠 **60-69** = Regular
- 🔴 **0-59** = Necesita mejorar

### Asistencia
- 🟢 **Verde** = Presente
- 🟡 **Amarillo** = Retardo
- 🔴 **Rojo** = Ausente
- ⚪ **Blanco** = Sin registrar

---

## ⌨️ Atajos Útiles

| Atajo | Función |
|-------|---------|
| F5 | Recargar página |
| Ctrl + F | Buscar en página |
| Esc | Cerrar diálogos |

---

## 🔧 Soluciones Rápidas

| Problema | Solución Rápida |
|----------|----------------|
| No se guarda | ✓ Verifica campos obligatorios<br>✓ Revisa conexión<br>✓ Recarga (F5) |
| No veo mi salón | ✓ Cierra sesión<br>✓ Vuelve a configurar |
| Perdí datos | ⚠️ No recuperable si borraste caché<br>✓ Usa mismo navegador siempre |
| Sin notificaciones | ✓ Permite notificaciones en navegador<br>✓ Mantén pestaña abierta |

---

## 📊 Pestañas Disponibles

### ALUMNOS
```
✅ CALENDARIO    Ver eventos y fechas importantes
✅ TAREAS        Gestionar deberes y trabajos
✅ HORARIO       Consultar clases de la semana
✅ NOTAS         Apuntes y resúmenes
✅ CALIFICACIONES Ver y agregar calificaciones
```

### DOCENTES
```
✅ CALENDARIO    Planificación de actividades
✅ TAREAS        Recordar tareas dejadas
✅ HORARIO       Ver/editar horario personal
✅ NOTAS         Planes de clase y apuntes
✅ LISTAS        Pasar lista de asistencia ⭐
✅ REVISADOS     Asignar calificaciones a tareas ⭐
✅ CALIFICACIONES Ver estadísticas del grupo
```

**⭐ = Exclusivo para docentes**

---

## 💾 Respaldo de Datos

### ⚠️ IMPORTANTE
- Los datos se guardan en **tu navegador**
- **NO borres** caché/cookies o perderás todo
- Usa **siempre el mismo** navegador y dispositivo
- Sincroniza con internet **regularmente**

---

## 📱 Instalación como App

### Pasos:
1. Espera 10 segundos después de abrir
2. Aparecerá notificación "Instalar Agenda Doberman"
3. Clic en **"Instalar"**
4. ¡Listo! Ahora en tu pantalla principal

### Ventajas:
- ✅ Acceso más rápido
- ✅ Funciona como app nativa
- ✅ No ocupa espacio en navegador
- ✅ Mejor experiencia móvil

---

## 🎯 Tips de Oro

### Para ALUMNOS 👨‍🎓
1. Revisa TAREAS cada mañana
2. Marca ALTA prioridad lo urgente
3. Toma NOTAS después de clase
4. Consulta HORARIO para no olvidar
5. Activa notificaciones del navegador

### Para DOCENTES 👨‍🏫
1. Pasa LISTA al iniciar clase
2. Usa "Marcar todos presentes" como base
3. Busca alumnos por NOMBRE o CONTROL
4. Crea ACTIVIDADES antes de calificar
5. Revisa ESTADÍSTICAS semanalmente

---

## 🆘 ¿Necesitas Más Ayuda?

Consulta la **GUIA_DE_USO.md** completa para:
- Instrucciones detalladas paso a paso
- Capturas de pantalla descriptivas
- Preguntas frecuentes extensas
- Resolución de problemas avanzados

---

## 📞 Contacto

**Desarrollado por:**
- Victor Moreno
- Christian Ayala

**Versión:** 2.0  
**Fecha:** Noviembre 2025

---

### ✨ El cambio empieza por ti

**¡Organízate y ten éxito! 🎓**
