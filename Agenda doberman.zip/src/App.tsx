import { useState, useEffect } from "react";
import { Calendar } from "./components/ui/calendar";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "./components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "./components/ui/tabs";
import {
  CalendarIcon,
  CheckSquare,
  Clock,
  BookOpen,
  Award,
} from "lucide-react";
import { TasksList } from "./components/TasksList";
import { Schedule } from "./components/Schedule";
import { Notes } from "./components/Notes";
import { Grades } from "./components/Grades";
import { Auth } from "./components/Auth";
import { Welcome } from "./components/Welcome";
import { RoleSelection } from "./components/RoleSelection";
import { StudentSetup } from "./components/StudentSetup";
import { TeacherSetup } from "./components/TeacherSetup";
import { ClassLists } from "./components/ClassLists";
import { TeacherSchedule } from "./components/TeacherSchedule";
import { TeacherGradeAssignment } from "./components/TeacherGradeAssignment";
import { Toaster } from "./components/ui/sonner";
import logoImage from "figma:asset/0bf968fbf30009b5a3d5c830a409e8b956b3bdfe.png";
import { ClipboardList } from "lucide-react";
import { ConnectionStatus } from "./components/ConnectionStatus";
import { OfflineSync } from "./components/OfflineSync";
import { HelpGuide } from "./components/HelpGuide";

export default function App() {
  const [date, setDate] = useState<Date | undefined>(
    new Date(),
  );
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userRole, setUserRole] = useState<
    "student" | "teacher" | null
  >(null);
  const [studentSetupComplete, setStudentSetupComplete] =
    useState(false);
  const [hasSeenWelcome, setHasSeenWelcome] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check if user is already authenticated
    const userEmail = localStorage.getItem("userEmail");
    const savedRole = localStorage.getItem("userRole") as
      | "student"
      | "teacher"
      | null;
    const studentName = localStorage.getItem("studentName");
    const studentClassroom = localStorage.getItem(
      "studentClassroom",
    );
    const welcomeSeen = localStorage.getItem("welcomeSeen");

    if (userEmail) {
      setIsAuthenticated(true);
    }

    if (savedRole) {
      setUserRole(savedRole);
      // Si es alumno, verificar si ya completó el setup
      if (
        savedRole === "student" &&
        studentName &&
        studentClassroom
      ) {
        setStudentSetupComplete(true);
      } else if (savedRole === "teacher") {
        // Verificar si el docente completó su setup
        const teacherName = localStorage.getItem("teacherName");
        const teacherClassrooms = localStorage.getItem(
          "teacherClassrooms",
        );
        if (teacherName && teacherClassrooms) {
          setStudentSetupComplete(true);
        }
      }
    }

    if (welcomeSeen === "true") {
      setHasSeenWelcome(true);
    }

    setIsLoading(false);
  }, []);

  const handleAuthenticated = (email: string) => {
    setIsAuthenticated(true);
  };

  const handleRoleSelected = (role: "student" | "teacher") => {
    setUserRole(role);
  };

  const handleStudentSetupComplete = (
    name: string,
    classroom: string,
  ) => {
    setStudentSetupComplete(true);
  };

  const handleTeacherSetupComplete = (
    name: string,
    classrooms: string[],
  ) => {
    setStudentSetupComplete(true);
  };

  const handleContinueFromWelcome = () => {
    localStorage.setItem("welcomeSeen", "true");
    setHasSeenWelcome(true);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100" />
    );
  }

  if (!isAuthenticated) {
    return <Auth onAuthenticated={handleAuthenticated} />;
  }

  if (!userRole) {
    return (
      <RoleSelection onRoleSelected={handleRoleSelected} />
    );
  }

  if (!studentSetupComplete && userRole === "student") {
    return (
      <StudentSetup
        onSetupComplete={handleStudentSetupComplete}
      />
    );
  }

  if (!studentSetupComplete && userRole === "teacher") {
    return (
      <TeacherSetup
        onSetupComplete={handleTeacherSetupComplete}
      />
    );
  }

  if (!hasSeenWelcome) {
    return <Welcome onContinue={handleContinueFromWelcome} />;
  }

  const studentName = localStorage.getItem("studentName");
  const studentClassroom = localStorage.getItem(
    "studentClassroom",
  );
  const teacherName = localStorage.getItem("teacherName");

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-gray-100">
      <Toaster position="top-right" richColors />
      {/* Header */}
      <header className="bg-gradient-to-r from-primary to-primary/90 border-b-4 border-accent shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <img
                src={logoImage}
                alt="Doberman Logo"
                className="w-20 h-20 object-contain"
              />
              <div>
                <h1 className="text-white text-3xl">
                  AGENDA DOBERMAN
                </h1>
                <p className="text-accent text-sm">
                  El cambio empieza por ti
                </p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <HelpGuide userRole={userRole!} />
              <div className="text-right">
                <p className="text-white text-sm">
                  {userRole === "student"
                    ? "Alumno"
                    : "Docente"}
                  {userRole === "student" &&
                    studentName &&
                    ` - ${studentName}`}
                  {userRole === "teacher" &&
                    teacherName &&
                    ` - ${teacherName}`}
                </p>
                {userRole === "student" && studentClassroom && (
                  <p className="text-accent text-sm">
                    Salón: {studentClassroom}
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <Tabs defaultValue="calendar" className="w-full">
          <TabsList
            className={`grid w-full ${userRole === "teacher" ? "grid-cols-6" : "grid-cols-5"} mb-8 bg-white border-2 border-primary/20`}
          >
            <TabsTrigger
              value="calendar"
              className="flex items-center gap-2"
            >
              <CalendarIcon className="w-4 h-4" />
              <span className="hidden sm:inline">
                Calendario
              </span>
            </TabsTrigger>
            <TabsTrigger
              value="tasks"
              className="flex items-center gap-2"
            >
              <CheckSquare className="w-4 h-4" />
              <span className="hidden sm:inline">Tareas</span>
            </TabsTrigger>
            <TabsTrigger
              value="schedule"
              className="flex items-center gap-2"
            >
              <Clock className="w-4 h-4" />
              <span className="hidden sm:inline">Horario</span>
            </TabsTrigger>
            {userRole === "teacher" && (
              <TabsTrigger
                value="lists"
                className="flex items-center gap-2"
              >
                <ClipboardList className="w-4 h-4" />
                <span className="hidden sm:inline">Listas</span>
              </TabsTrigger>
            )}
            <TabsTrigger
              value="grades"
              className="flex items-center gap-2"
            >
              <Award className="w-4 h-4" />
              <span className="hidden sm:inline">
                {userRole === "teacher"
                  ? "Revisados"
                  : "Calificaciones"}
              </span>
            </TabsTrigger>
            <TabsTrigger
              value="notes"
              className="flex items-center gap-2"
            >
              <BookOpen className="w-4 h-4" />
              <span className="hidden sm:inline">Notas</span>
            </TabsTrigger>
          </TabsList>

          {/* Calendar Tab */}
          <TabsContent value="calendar">
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="border-2 border-primary/10">
                <CardHeader className="bg-gradient-to-r from-primary/5 to-transparent">
                  <CardTitle className="text-primary">
                    Calendario
                  </CardTitle>
                  <CardDescription>
                    Selecciona una fecha para ver tus eventos
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex justify-center">
                  <Calendar
                    mode="single"
                    selected={date}
                    onSelect={setDate}
                    className="rounded-md border"
                  />
                </CardContent>
              </Card>

              <Card className="border-2 border-primary/10">
                <CardHeader className="bg-gradient-to-r from-accent/10 to-transparent">
                  <CardTitle className="text-primary">
                    Eventos del día
                  </CardTitle>
                  <CardDescription>
                    {date?.toLocaleDateString("es-ES", {
                      weekday: "long",
                      year: "numeric",
                      month: "long",
                      day: "numeric",
                    })}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-start gap-3 p-3 rounded-lg bg-primary/5 border-2 border-primary/20">
                      <div className="w-2 h-2 mt-2 rounded-full bg-primary"></div>
                      <div>
                        <p className="text-foreground">
                          Examen de Matemáticas
                        </p>
                        <p className="text-sm text-muted-foreground">
                          08:00 - 10:00
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-3 rounded-lg bg-accent/10 border-2 border-accent/30">
                      <div className="w-2 h-2 mt-2 rounded-full bg-accent"></div>
                      <div>
                        <p className="text-foreground">
                          Entrega de Proyecto
                        </p>
                        <p className="text-sm text-muted-foreground">
                          14:00
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-3 rounded-lg bg-secondary/10 border-2 border-secondary/30">
                      <div className="w-2 h-2 mt-2 rounded-full bg-secondary"></div>
                      <div>
                        <p className="text-foreground">
                          Clase de Laboratorio
                        </p>
                        <p className="text-sm text-muted-foreground">
                          15:00 - 17:00
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Tasks Tab */}
          <TabsContent value="tasks">
            <TasksList />
          </TabsContent>

          {/* Schedule Tab */}
          <TabsContent value="schedule">
            {userRole === "teacher" ? (
              <TeacherSchedule />
            ) : (
              <Schedule userRole={userRole} />
            )}
          </TabsContent>

          {/* Lists Tab - Solo para docentes */}
          {userRole === "teacher" && (
            <TabsContent value="lists">
              <ClassLists />
            </TabsContent>
          )}

          {/* Grades Tab */}
          <TabsContent value="grades">
            {userRole === "teacher" ? (
              <TeacherGradeAssignment />
            ) : (
              <Grades />
            )}
          </TabsContent>

          {/* Notes Tab */}
          <TabsContent value="notes">
            <Notes />
          </TabsContent>
        </Tabs>
      </main>

      {/* Connection Status Indicator */}
      <ConnectionStatus />

      {/* Auto Sync Component */}
      <OfflineSync />
    </div>
  );
}