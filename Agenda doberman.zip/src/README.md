# 🎓 AGENDA DOBERMAN

![Version](https://img.shields.io/badge/version-2.0-blue)
![Status](https://img.shields.io/badge/status-active-success)
![License](https://img.shields.io/badge/license-Educational-orange)

## 📱 Aplicación de Agenda Escolar Completa

**AGENDA DOBERMAN** es una aplicación web moderna y completa diseñada para estudiantes y docentes, que permite organizar tareas, horarios, calificaciones, asistencias y mucho más. Funciona completamente sin conexión a internet.

### ✨ **El cambio empieza por ti**

---

## 🌟 Características Principales

### Para Alumnos 👨‍🎓
- ✅ **Gestión de Tareas** con prioridades y recordatorios automáticos
- ✅ **Notas y Apuntes** organizados por materia
- ✅ **Horario Personalizado** según tu salón
- ✅ **Calificaciones** con promedios automáticos
- ✅ **Calendario** de eventos y fechas importantes
- ✅ **Notificaciones** de tareas próximas a vencer

### Para Docentes 👨‍🏫
- ✅ **Listas de Asistencia** con búsqueda de alumnos
- ✅ **Asignación de Calificaciones** a tareas y actividades
- ✅ **Gestión de Múltiples Salones** (hasta 18 grupos)
- ✅ **Estadísticas del Grupo** en tiempo real
- ✅ **Horario Editable** personalizado
- ✅ **Historial de Asistencias** por fecha

### Para Todos 🎯
- ✅ **Modo Offline Completo** - Funciona sin internet
- ✅ **Sincronización Automática** cuando vuelve la conexión
- ✅ **Interfaz Intuitiva** con código de colores
- ✅ **Responsive** - Funciona en móviles y tablets
- ✅ **Sin Instalación** - Funciona en el navegador
- ✅ **Datos Locales** - Privacidad garantizada

---

## 🚀 Inicio Rápido

### 1. Acceder a la Aplicación
Abre la aplicación en tu navegador favorito (Chrome, Firefox, Safari, Edge)

### 2. Registro
```
📧 Ingresa tu correo → 👋 Bienvenida → 🎭 Elige rol
```

### 3. Configuración
```
👤 Nombre → 🏫 Selecciona salón(es) → ✅ ¡Listo!
```

### 4. ¡Empieza a Usar!
Navega por las pestañas superiores y explora todas las funcionalidades.

---

## 📚 Documentación Completa

### 📖 Guías de Usuario

| Documento | Descripción | Para Quién | Tiempo |
|-----------|-------------|------------|--------|
| **[GUIA_DE_USO.md](./GUIA_DE_USO.md)** | Guía completa con instrucciones detalladas | Todos | 30 min |
| **[GUIA_RAPIDA.md](./GUIA_RAPIDA.md)** | Referencia rápida y tablas de acciones | Todos | 5 min |
| **[MODO_OFFLINE.md](./MODO_OFFLINE.md)** | Cómo funciona sin internet | Todos | 10 min |

### 📊 Datos y Referencias

| Documento | Descripción | Para Quién |
|-----------|-------------|------------|
| **[LISTA_ALUMNOS_1AVTC.md](./LISTA_ALUMNOS_1AVTC.md)** | Lista de 51 alumnos del salón 1AVTC | Docentes |
| **[RESUMEN_ACTUALIZACION.md](./RESUMEN_ACTUALIZACION.md)** | Changelog y novedades | Todos |

### 🗂️ Índice General

| Documento | Descripción |
|-----------|-------------|
| **[INDICE_DOCUMENTACION.md](./INDICE_DOCUMENTACION.md)** | Índice completo de toda la documentación |

---

## 🎯 Empezar por Aquí

### Si eres ALUMNO 👨‍🎓
1. Lee [GUIA_RAPIDA.md](./GUIA_RAPIDA.md) - Sección "ALUMNO"
2. Explora las pestañas: TAREAS, NOTAS, HORARIO, CALIFICACIONES
3. Consulta [GUIA_DE_USO.md](./GUIA_DE_USO.md) para detalles

### Si eres DOCENTE 👨‍🏫
1. Lee [GUIA_RAPIDA.md](./GUIA_RAPIDA.md) - Sección "DOCENTE"
2. Revisa [LISTA_ALUMNOS_1AVTC.md](./LISTA_ALUMNOS_1AVTC.md) si aplica
3. Explora las pestañas: LISTAS, REVISADOS
4. Consulta [GUIA_DE_USO.md](./GUIA_DE_USO.md) para detalles

---

## 🎨 Paleta de Colores

La aplicación utiliza un esquema de colores específico:

| Color | Uso | Código Hex |
|-------|-----|------------|
| **Guindo** | Color principal | #800020 |
| **Gris** | Texto secundario | #6B7280 |
| **Blanco** | Fondo | #FFFFFF |
| **Dorado** | Acentos | #FFD700 |

### Código de Colores Funcional

#### Prioridades de Tareas
- 🔴 **ALTA** = Urgente
- 🟡 **MEDIA** = Normal
- 🟢 **BAJA** = Sin prisa

#### Calificaciones
- 🟢 **90-100** = Excelente
- 🔵 **80-89** = Muy bien
- 🟡 **70-79** = Bien
- 🟠 **60-69** = Regular
- 🔴 **0-59** = Necesita mejorar

#### Asistencia (Docentes)
- 🟢 **Verde** = Presente
- 🟡 **Amarillo** = Retardo
- 🔴 **Rojo** = Ausente

---

## 📡 Modo Offline

### ¿Cómo Funciona?

La aplicación **funciona completamente sin internet**:

```
🟢 Con Internet → Todo se sincroniza automáticamente
🟡 Sin Internet → Todo se guarda localmente
🔄 Vuelve Internet → Sincronización automática
```

### Ventajas
- ✅ Usa la app en cualquier lugar
- ✅ No dependas de WiFi/datos
- ✅ Tus datos siempre disponibles
- ✅ Sincronización transparente

**Más información:** [MODO_OFFLINE.md](./MODO_OFFLINE.md)

---

## 🏫 Salones Disponibles

### Turno Matutino (8 salones)
```
1AMTC, 1BMTC, 1CMTC, 1DMTC, 1EMTC, 1FMTC, 1GMTC, 1HMTC
3AML
```

### Turno Vespertino (10 salones)
```
1AVTC ⭐, 1BVTC, 1CVTC, 1DVTC, 1EVTC, 1FVTC, 1GVTC, 1HVTC
3AVL
```

⭐ = Incluye lista completa de alumnos con números de control

---

## 🔧 Tecnologías Utilizadas

### Frontend
- **React** - Framework principal
- **TypeScript** - Tipado estático
- **Tailwind CSS** - Estilos
- **Shadcn/ui** - Componentes UI

### Funcionalidades
- **LocalStorage** - Almacenamiento persistente
- **Service Workers** - Modo offline
- **Notificaciones** - Recordatorios
- **Responsive Design** - Mobile-first

---

## 📱 Instalación como PWA

La aplicación puede instalarse en tu dispositivo:

1. **Espera 10 segundos** después de abrir
2. Aparecerá notificación **"Instalar Agenda Doberman"**
3. Haz clic en **"Instalar"**
4. ¡Listo! Ahora en tu pantalla principal

### Ventajas de Instalar
- 🚀 Acceso más rápido
- 📱 Funciona como app nativa
- 💾 Mejor rendimiento
- 🎯 Experiencia mejorada

---

## 🎓 Salones con Listas Completas

| Salón | Alumnos | Turno | Docente | Estado |
|-------|---------|-------|---------|--------|
| **1AVTC** | 51 | Vespertino | RAMIREZ RODRIGUEZ NOE GUADALUPE | ✅ Completa |
| **3AVL** | 36 | Vespertino | - | ✅ Completa |
| **3AML** | - | Matutino | - | ⏳ Pendiente |

---

## 💡 Consejos Útiles

### Para TODOS
1. ✅ **Usa el botón "Ayuda"** en el header para acceso rápido
2. ✅ **No borres el caché** del navegador o perderás datos
3. ✅ **Usa siempre el mismo navegador** en tu dispositivo
4. ✅ **Sincroniza regularmente** cuando tengas internet
5. ✅ **Activa las notificaciones** del navegador

### Para ALUMNOS
1. ✅ Revisa TAREAS cada mañana
2. ✅ Usa prioridades para organizarte
3. ✅ Toma NOTAS después de clase
4. ✅ Consulta HORARIO semanalmente

### Para DOCENTES
1. ✅ Pasa lista al iniciar cada clase
2. ✅ Usa "Marcar todos presentes" y luego ajusta
3. ✅ Busca alumnos por nombre o control
4. ✅ Revisa estadísticas semanalmente

---

## ❓ Preguntas Frecuentes

### ¿Es gratis?
**Sí**, es completamente gratuita para uso educativo.

### ¿Necesito crear cuenta?
**Sí**, pero solo necesitas un correo electrónico (sin verificación).

### ¿Funciona en móvil?
**Sí**, la app es completamente responsive.

### ¿Puedo usar en varios dispositivos?
**No simultáneamente**. Los datos son locales por dispositivo/navegador.

### ¿Qué pasa si borro el caché?
**Perderás todos tus datos**. ¡Ten cuidado!

### ¿Mis datos están seguros?
**Sí**, todo se guarda localmente en tu dispositivo.

**Más preguntas:** [GUIA_DE_USO.md](./GUIA_DE_USO.md) - Sección "Preguntas Frecuentes"

---

## 🆘 Soporte

### Documentación
Consulta la [GUIA_DE_USO.md](./GUIA_DE_USO.md) completa o el [INDICE_DOCUMENTACION.md](./INDICE_DOCUMENTACION.md)

### Ayuda en la App
Haz clic en el botón **"Ayuda"** en el header (arriba a la derecha)

### Problemas Técnicos
Contacta a los desarrolladores

---

## 👨‍💻 Desarrolladores

**Creado por:**
- **Victor Moreno**
- **Christian Ayala**

**Institución:** [Tu Institución Educativa]  
**Fecha de Lanzamiento:** Noviembre 2025  
**Versión Actual:** 2.0

---

## 📊 Estadísticas del Proyecto

- **Componentes:** 25+
- **Pestañas:** 7 (alumnos), 9 (docentes)
- **Salones Soportados:** 18
- **Documentación:** 42+ páginas
- **Funcionalidades:** 30+

---

## 🗺️ Roadmap - Futuras Mejoras

### En Desarrollo 🔄
- [ ] Exportar listas a PDF/Excel
- [ ] Gráficos de rendimiento
- [ ] Temas claros/oscuros

### Planeado 📋
- [ ] Compartir notas entre compañeros
- [ ] Chat grupal por salón
- [ ] Calendario compartido
- [ ] Backup en la nube

### En Consideración 💭
- [ ] App móvil nativa
- [ ] Integración con sistemas escolares
- [ ] Panel de administración

---

## 📄 Licencia

Este proyecto es de uso **educativo**. Todos los derechos reservados a los desarrolladores.

---

## 🙏 Agradecimientos

Gracias a todos los estudiantes y docentes que harán de **AGENDA DOBERMAN** una herramienta esencial en su día a día escolar.

---

## 🔗 Enlaces Rápidos

| Enlace | Descripción |
|--------|-------------|
| [Guía de Uso](./GUIA_DE_USO.md) | Documentación completa |
| [Guía Rápida](./GUIA_RAPIDA.md) | Referencia rápida |
| [Modo Offline](./MODO_OFFLINE.md) | Funcionamiento sin internet |
| [Índice](./INDICE_DOCUMENTACION.md) | Índice de documentación |

---

## 📞 Contacto

Para soporte, sugerencias o reportar problemas:

**Desarrolladores:**
- Victor Moreno
- Christian Ayala

---

### ✨ El cambio empieza por ti

**¡Organízate, aprende y ten éxito con AGENDA DOBERMAN!** 🎓

---

**Última actualización:** Noviembre 2025  
**Versión:** 2.0.0  
**Estado:** ✅ Activo y Funcional
