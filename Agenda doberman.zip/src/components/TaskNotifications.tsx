import { useEffect } from 'react';
import { toast } from 'sonner@2.0.3';
import { AlertCircle, Clock } from 'lucide-react';

interface Task {
  id: number;
  title: string;
  subject: string;
  dueDate: string;
  completed: boolean;
  priority: 'low' | 'medium' | 'high';
}

interface TaskNotificationsProps {
  tasks: Task[];
}

export function TaskNotifications({ tasks }: TaskNotificationsProps) {
  useEffect(() => {
    const checkNotifications = () => {
      const now = new Date();
      const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      
      tasks.forEach(task => {
        if (task.completed) return;
        
        const dueDate = new Date(task.dueDate);
        const dueDateOnly = new Date(dueDate.getFullYear(), dueDate.getMonth(), dueDate.getDate());
        const daysUntilDue = Math.ceil((dueDateOnly.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
        
        // Notification for tasks due today
        if (daysUntilDue === 0) {
          const notificationKey = `task-today-${task.id}`;
          if (!sessionStorage.getItem(notificationKey)) {
            toast.error(`¡Tarea para hoy!`, {
              description: `${task.subject}: ${task.title}`,
              icon: <AlertCircle className="w-4 h-4" />,
              duration: 5000,
            });
            sessionStorage.setItem(notificationKey, 'shown');
          }
        }
        
        // Notification for tasks due tomorrow
        if (daysUntilDue === 1) {
          const notificationKey = `task-tomorrow-${task.id}`;
          if (!sessionStorage.getItem(notificationKey)) {
            toast.warning(`Tarea para mañana`, {
              description: `${task.subject}: ${task.title}`,
              icon: <Clock className="w-4 h-4" />,
              duration: 5000,
            });
            sessionStorage.setItem(notificationKey, 'shown');
          }
        }
        
        // Notification for overdue tasks
        if (daysUntilDue < 0) {
          const notificationKey = `task-overdue-${task.id}`;
          if (!sessionStorage.getItem(notificationKey)) {
            toast.error(`¡Tarea atrasada!`, {
              description: `${task.subject}: ${task.title} (${Math.abs(daysUntilDue)} día${Math.abs(daysUntilDue) !== 1 ? 's' : ''} de retraso)`,
              icon: <AlertCircle className="w-4 h-4" />,
              duration: 6000,
            });
            sessionStorage.setItem(notificationKey, 'shown');
          }
        }

        // Notification for high priority tasks due within 3 days
        if (task.priority === 'high' && daysUntilDue > 0 && daysUntilDue <= 3) {
          const notificationKey = `task-priority-${task.id}`;
          if (!sessionStorage.getItem(notificationKey)) {
            toast.warning(`Tarea prioritaria`, {
              description: `${task.subject}: ${task.title} (vence en ${daysUntilDue} día${daysUntilDue !== 1 ? 's' : ''})`,
              icon: <AlertCircle className="w-4 h-4" />,
              duration: 5000,
            });
            sessionStorage.setItem(notificationKey, 'shown');
          }
        }
      });
    };

    // Check notifications on mount
    checkNotifications();

    // Check notifications every 5 minutes
    const interval = setInterval(checkNotifications, 5 * 60 * 1000);

    return () => clearInterval(interval);
  }, [tasks]);

  return null;
}
