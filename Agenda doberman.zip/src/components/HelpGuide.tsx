import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { HelpCircle, BookOpen, Zap, User, GraduationCap, CheckCircle, Calendar, FileText, Award, List, ClipboardList } from 'lucide-react';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from './ui/accordion';

interface HelpGuideProps {
  userRole: 'student' | 'teacher';
}

export function HelpGuide({ userRole }: HelpGuideProps) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2 md:px-3 px-2">
          <HelpCircle className="h-4 w-4" />
          <span className="hidden md:inline">Ayuda</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-2xl">
            <BookOpen className="h-6 w-6 text-primary" />
            Guía de Uso - Agenda Doberman
          </DialogTitle>
          <DialogDescription>
            Aprende a usar todas las funcionalidades de la aplicación
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="inicio" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="inicio">
              <Zap className="h-4 w-4 mr-2" />
              Inicio Rápido
            </TabsTrigger>
            <TabsTrigger value="funciones">
              {userRole === 'student' ? <User className="h-4 w-4 mr-2" /> : <GraduationCap className="h-4 w-4 mr-2" />}
              Funciones
            </TabsTrigger>
            <TabsTrigger value="tips">
              <CheckCircle className="h-4 w-4 mr-2" />
              Tips
            </TabsTrigger>
          </TabsList>

          {/* INICIO RÁPIDO */}
          <TabsContent value="inicio" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Inicio Rápido en 3 Pasos</CardTitle>
                <CardDescription>Ya completaste estos pasos al configurar tu cuenta</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start gap-3 p-3 bg-green-50 rounded-lg border border-green-200">
                  <div className="flex items-center justify-center w-8 h-8 rounded-full bg-green-600 text-white flex-shrink-0">
                    1
                  </div>
                  <div>
                    <h4 className="font-semibold text-green-900">Registrarse</h4>
                    <p className="text-sm text-green-800">Ingresaste tu correo y elegiste tu rol</p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 bg-green-50 rounded-lg border border-green-200">
                  <div className="flex items-center justify-center w-8 h-8 rounded-full bg-green-600 text-white flex-shrink-0">
                    2
                  </div>
                  <div>
                    <h4 className="font-semibold text-green-900">Configurar Perfil</h4>
                    <p className="text-sm text-green-800">Completaste tu nombre y {userRole === 'student' ? 'salón' : 'salones'}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 bg-blue-50 rounded-lg border border-blue-200">
                  <div className="flex items-center justify-center w-8 h-8 rounded-full bg-blue-600 text-white flex-shrink-0">
                    3
                  </div>
                  <div>
                    <h4 className="font-semibold text-blue-900">¡Listo para usar!</h4>
                    <p className="text-sm text-blue-800">Navega por las pestañas superiores para usar la agenda</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Estados de Conexión</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-3 p-2 bg-green-50 rounded">
                  <span className="text-2xl">📶 ✓</span>
                  <div>
                    <p className="font-medium text-green-900">Conectado y sincronizado</p>
                    <p className="text-sm text-green-700">Todo funciona correctamente</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-2 bg-yellow-50 rounded">
                  <span className="text-2xl">📶 ⚠️</span>
                  <div>
                    <p className="font-medium text-yellow-900">Sin conexión - Modo offline</p>
                    <p className="text-sm text-yellow-700">Tus datos se guardan localmente</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* FUNCIONES */}
          <TabsContent value="funciones" className="space-y-4">
            {userRole === 'student' ? (
              <StudentFunctions />
            ) : (
              <TeacherFunctions />
            )}
          </TabsContent>

          {/* TIPS */}
          <TabsContent value="tips" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Consejos para {userRole === 'student' ? 'Alumnos' : 'Docentes'}</CardTitle>
              </CardHeader>
              <CardContent>
                {userRole === 'student' ? (
                  <ul className="space-y-2">
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
                      <span>Revisa tus tareas diariamente en la pestaña TAREAS</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
                      <span>Usa las prioridades (Alta/Media/Baja) para organizarte mejor</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
                      <span>Toma notas después de cada clase</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
                      <span>Consulta tu horario para no olvidar materias</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
                      <span>La aplicación funciona sin internet - úsala en cualquier lugar</span>
                    </li>
                  </ul>
                ) : (
                  <ul className="space-y-2">
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
                      <span>Pasa lista al inicio de cada clase usando LISTAS</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
                      <span>Usa "Marcar todos presentes" y luego ajusta ausentes/retardos</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
                      <span>Usa el buscador para encontrar alumnos rápidamente</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
                      <span>Crea actividades en REVISADOS antes de asignar calificaciones</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
                      <span>Revisa las estadísticas para identificar alumnos que necesitan apoyo</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
                      <span>La app funciona sin internet - califica sin preocuparte por la conexión</span>
                    </li>
                  </ul>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Código de Colores</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <h4 className="font-semibold mb-2">Prioridades de Tareas</h4>
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 bg-red-500 rounded"></div>
                      <span>ALTA - Urgente</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 bg-yellow-500 rounded"></div>
                      <span>MEDIA - Normal</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 bg-green-500 rounded"></div>
                      <span>BAJA - Sin prisa</span>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold mb-2">Calificaciones</h4>
                  <div className="space-y-1 text-sm">
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 bg-green-500 rounded"></div>
                      <span>90-100 - Excelente</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 bg-blue-500 rounded"></div>
                      <span>80-89 - Muy bien</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 bg-yellow-500 rounded"></div>
                      <span>70-79 - Bien</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 bg-orange-500 rounded"></div>
                      <span>60-69 - Regular</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 bg-red-500 rounded"></div>
                      <span>0-59 - Necesita mejorar</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="flex justify-end gap-2 pt-4 border-t">
          <Button variant="outline" onClick={() => setIsOpen(false)}>
            Cerrar
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function StudentFunctions() {
  return (
    <Accordion type="single" collapsible className="w-full">
      <AccordionItem value="tareas">
        <AccordionTrigger className="text-lg">
          <div className="flex items-center gap-2">
            <CheckCircle className="h-5 w-5 text-primary" />
            TAREAS
          </div>
        </AccordionTrigger>
        <AccordionContent className="space-y-3">
          <div>
            <h4 className="font-semibold mb-1">➕ Agregar Tarea</h4>
            <p className="text-sm text-muted-foreground">
              Clic "Nueva Tarea" → Llenar título, materia, fecha y prioridad → Guardar
            </p>
          </div>
          <div>
            <h4 className="font-semibold mb-1">✔️ Completar Tarea</h4>
            <p className="text-sm text-muted-foreground">
              Clic en el checkbox ☑️ al lado izquierdo de la tarea
            </p>
          </div>
          <div>
            <h4 className="font-semibold mb-1">🗑️ Eliminar Tarea</h4>
            <p className="text-sm text-muted-foreground">
              Clic en el icono de basura al lado derecho
            </p>
          </div>
        </AccordionContent>
      </AccordionItem>

      <AccordionItem value="notas">
        <AccordionTrigger className="text-lg">
          <div className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-primary" />
            NOTAS
          </div>
        </AccordionTrigger>
        <AccordionContent className="space-y-3">
          <div>
            <h4 className="font-semibold mb-1">➕ Crear Nota</h4>
            <p className="text-sm text-muted-foreground">
              Clic "Nueva Nota" → Título + Materia + Contenido → Guardar
            </p>
          </div>
          <div>
            <h4 className="font-semibold mb-1">✏️ Editar Nota</h4>
            <p className="text-sm text-muted-foreground">
              Clic en icono lápiz ✏️ → Modificar → Guardar cambios
            </p>
          </div>
        </AccordionContent>
      </AccordionItem>

      <AccordionItem value="horario">
        <AccordionTrigger className="text-lg">
          <div className="flex items-center gap-2">
            <Calendar className="h-5 w-5 text-primary" />
            HORARIO
          </div>
        </AccordionTrigger>
        <AccordionContent>
          <p className="text-sm text-muted-foreground">
            Tu horario se configuró automáticamente según tu salón. Consulta aquí tus clases de la semana, con hora, materia, profesor y aula.
          </p>
        </AccordionContent>
      </AccordionItem>

      <AccordionItem value="calificaciones">
        <AccordionTrigger className="text-lg">
          <div className="flex items-center gap-2">
            <Award className="h-5 w-5 text-primary" />
            CALIFICACIONES
          </div>
        </AccordionTrigger>
        <AccordionContent>
          <p className="text-sm text-muted-foreground mb-2">
            Ver tus calificaciones por materia con promedios automáticos. También puedes agregar calificaciones manualmente.
          </p>
          <div className="bg-blue-50 p-3 rounded-lg border border-blue-200">
            <p className="text-sm text-blue-800">
              💡 Normalmente las calificaciones las asigna tu docente en la sección REVISADOS
            </p>
          </div>
        </AccordionContent>
      </AccordionItem>
    </Accordion>
  );
}

function TeacherFunctions() {
  return (
    <Accordion type="single" collapsible className="w-full">
      <AccordionItem value="listas">
        <AccordionTrigger className="text-lg">
          <div className="flex items-center gap-2">
            <List className="h-5 w-5 text-primary" />
            LISTAS (Asistencia)
          </div>
        </AccordionTrigger>
        <AccordionContent className="space-y-3">
          <div>
            <h4 className="font-semibold mb-1">📍 Seleccionar Salón y Fecha</h4>
            <p className="text-sm text-muted-foreground">
              En la parte superior, elige el salón y la fecha (por defecto: hoy)
            </p>
          </div>
          <div>
            <h4 className="font-semibold mb-1">🔍 Buscar Alumno</h4>
            <p className="text-sm text-muted-foreground">
              Usa el buscador para filtrar por nombre o número de control
            </p>
          </div>
          <div>
            <h4 className="font-semibold mb-1">✅ Marcar Asistencia</h4>
            <p className="text-sm text-muted-foreground">
              Para cada alumno: ✓ Presente (verde) | ⏰ Retardo (amarillo) | ✗ Ausente (rojo)
            </p>
          </div>
          <div>
            <h4 className="font-semibold mb-1">🎯 Marcar Todos Presentes</h4>
            <p className="text-sm text-muted-foreground">
              Clic en el botón "Marcar Todos como Presentes" y luego ajusta individualmente
            </p>
          </div>
        </AccordionContent>
      </AccordionItem>

      <AccordionItem value="revisados">
        <AccordionTrigger className="text-lg">
          <div className="flex items-center gap-2">
            <ClipboardList className="h-5 w-5 text-primary" />
            REVISADOS (Calificaciones)
          </div>
        </AccordionTrigger>
        <AccordionContent className="space-y-3">
          <div>
            <h4 className="font-semibold mb-1">➕ Crear Actividad</h4>
            <p className="text-sm text-muted-foreground">
              Clic "Nueva Actividad" → Nombre + Puntos máximos + Fecha → Crear
            </p>
          </div>
          <div>
            <h4 className="font-semibold mb-1">📝 Calificar</h4>
            <p className="text-sm text-muted-foreground">
              Selecciona Salón → Actividad → Busca alumno → Ingresa puntos → Guardar
            </p>
          </div>
          <div>
            <h4 className="font-semibold mb-1">📈 Ver Estadísticas</h4>
            <p className="text-sm text-muted-foreground">
              Panel superior muestra: Total, Calificados, Pendientes y Promedio del grupo
            </p>
          </div>
        </AccordionContent>
      </AccordionItem>

      <AccordionItem value="horario">
        <AccordionTrigger className="text-lg">
          <div className="flex items-center gap-2">
            <Calendar className="h-5 w-5 text-primary" />
            HORARIO
          </div>
        </AccordionTrigger>
        <AccordionContent>
          <p className="text-sm text-muted-foreground mb-2">
            Ver tu horario personalizado con todos los grupos donde das clases.
          </p>
          <div className="bg-blue-50 p-3 rounded-lg border border-blue-200">
            <p className="text-sm text-blue-800">
              ✏️ Puedes editar tu horario haciendo clic en "Editar Horario"
            </p>
          </div>
        </AccordionContent>
      </AccordionItem>

      <AccordionItem value="tareas">
        <AccordionTrigger className="text-lg">
          <div className="flex items-center gap-2">
            <CheckCircle className="h-5 w-5 text-primary" />
            TAREAS
          </div>
        </AccordionTrigger>
        <AccordionContent>
          <p className="text-sm text-muted-foreground">
            Usa esta sección para recordar qué tareas dejaste a cada grupo. Funciona igual que para alumnos.
          </p>
        </AccordionContent>
      </AccordionItem>

      <AccordionItem value="notas">
        <AccordionTrigger className="text-lg">
          <div className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-primary" />
            NOTAS
          </div>
        </AccordionTrigger>
        <AccordionContent>
          <p className="text-sm text-muted-foreground">
            Guarda planes de clase, apuntes importantes, recordatorios, etc. Funciona igual que para alumnos.
          </p>
        </AccordionContent>
      </AccordionItem>
    </Accordion>
  );
}
