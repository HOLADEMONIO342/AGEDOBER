import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Checkbox } from './ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Plus, Trash2 } from 'lucide-react';
import { Badge } from './ui/badge';
import { TaskNotifications } from './TaskNotifications';
import { syncService } from '../utils/syncService';
import { useOnlineStatus } from '../hooks/useOnlineStatus';

interface Task {
  id: number;
  title: string;
  subject: string;
  dueDate: string;
  completed: boolean;
  priority: 'low' | 'medium' | 'high';
}

export function TasksList() {
  const isOnline = useOnlineStatus();
  
  const [tasks, setTasks] = useState<Task[]>(() => {
    // Cargar tareas del localStorage al iniciar
    const savedTasks = syncService.getLocal<Task[]>('tasks', [
      {
        id: 1,
        title: 'Resolver ejercicios de álgebra página 45-47',
        subject: 'Matemáticas',
        dueDate: '2025-10-28',
        completed: false,
        priority: 'high'
      },
      {
        id: 2,
        title: 'Leer capítulo 3 de "Cien años de soledad"',
        subject: 'Literatura',
        dueDate: '2025-10-29',
        completed: false,
        priority: 'medium'
      },
      {
        id: 3,
        title: 'Práctica de laboratorio - Reacciones químicas',
        subject: 'Química',
        dueDate: '2025-10-27',
        completed: true,
        priority: 'high'
      },
      {
        id: 4,
        title: 'Investigar sobre la Revolución Industrial',
        subject: 'Historia',
        dueDate: '2025-10-30',
        completed: false,
        priority: 'low'
      }
    ]);
    return savedTasks;
  });

  // Guardar tareas en localStorage cada vez que cambien
  useEffect(() => {
    syncService.saveLocal('tasks', tasks);
    
    // Si no hay conexión, agregar a la cola de sincronización
    if (!isOnline) {
      syncService.addPendingSync({
        type: 'task',
        action: 'update',
        data: tasks,
      });
    }
  }, [tasks, isOnline]);

  const [newTask, setNewTask] = useState('');
  const [newSubject, setNewSubject] = useState('');
  const [newDueDate, setNewDueDate] = useState('');
  const [newPriority, setNewPriority] = useState<'low' | 'medium' | 'high'>('medium');

  const addTask = () => {
    if (newTask.trim() && newSubject.trim()) {
      setTasks([
        ...tasks,
        {
          id: Date.now(),
          title: newTask,
          subject: newSubject,
          dueDate: newDueDate || new Date().toISOString().split('T')[0],
          completed: false,
          priority: newPriority
        }
      ]);
      setNewTask('');
      setNewSubject('');
      setNewDueDate('');
      setNewPriority('medium');
    }
  };

  const toggleTask = (id: number) => {
    setTasks(tasks.map(task =>
      task.id === id ? { ...task, completed: !task.completed } : task
    ));
  };

  const deleteTask = (id: number) => {
    setTasks(tasks.filter(task => task.id !== id));
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800 border-red-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  const getPriorityText = (priority: string) => {
    switch (priority) {
      case 'high': return 'Alta';
      case 'medium': return 'Media';
      case 'low': return 'Baja';
      default: return priority;
    }
  };

  return (
    <div className="grid gap-6">
      <TaskNotifications tasks={tasks} />
      <Card>
        <CardHeader>
          <CardTitle>Agregar nueva tarea</CardTitle>
          <CardDescription>Mantén el control de todos tus deberes</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4">
            <div className="grid sm:grid-cols-2 gap-4">
              <Input
                placeholder="Nombre de la tarea..."
                value={newTask}
                onChange={(e) => setNewTask(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && addTask()}
              />
              <Input
                placeholder="Materia..."
                value={newSubject}
                onChange={(e) => setNewSubject(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && addTask()}
              />
            </div>
            <div className="grid sm:grid-cols-3 gap-4">
              <Input
                type="date"
                value={newDueDate}
                onChange={(e) => setNewDueDate(e.target.value)}
              />
              <Select value={newPriority} onValueChange={(value: 'low' | 'medium' | 'high') => setNewPriority(value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Prioridad" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Baja</SelectItem>
                  <SelectItem value="medium">Media</SelectItem>
                  <SelectItem value="high">Alta</SelectItem>
                </SelectContent>
              </Select>
              <Button onClick={addTask} className="w-full">
                <Plus className="w-4 h-4 mr-2" />
                Agregar
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Mis Tareas</CardTitle>
          <CardDescription>
            {tasks.filter(t => !t.completed).length} pendiente{tasks.filter(t => !t.completed).length !== 1 ? 's' : ''} de {tasks.length}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {tasks.map(task => (
              <div
                key={task.id}
                className={`flex items-start gap-4 p-4 rounded-lg border ${
                  task.completed ? 'bg-slate-50 border-slate-200' : 'bg-white border-slate-300'
                }`}
              >
                <Checkbox
                  checked={task.completed}
                  onCheckedChange={() => toggleTask(task.id)}
                  className="mt-1"
                />
                <div className="flex-1 min-w-0">
                  <p className={`${task.completed ? 'line-through text-slate-500' : 'text-slate-900'}`}>
                    {task.title}
                  </p>
                  <div className="flex flex-wrap items-center gap-2 mt-2">
                    <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                      {task.subject}
                    </Badge>
                    <Badge variant="outline" className={getPriorityColor(task.priority)}>
                      {getPriorityText(task.priority)}
                    </Badge>
                    <span className="text-xs text-slate-600">
                      {new Date(task.dueDate).toLocaleDateString('es-ES', { 
                        day: 'numeric', 
                        month: 'short' 
                      })}
                    </span>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => deleteTask(task.id)}
                  className="text-red-600 hover:text-red-700 hover:bg-red-50"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
