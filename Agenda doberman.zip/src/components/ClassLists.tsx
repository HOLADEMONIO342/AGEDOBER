import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Input } from './ui/input';
import { classroomRosters, Student, AttendanceRecord } from '../data/classroomRosters';
import { CheckCircle2, XCircle, Clock, Calendar, Search } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

export function ClassLists() {
  const [teacherClassrooms, setTeacherClassrooms] = useState<string[]>([]);
  const [selectedClassroom, setSelectedClassroom] = useState<string>('');
  const [currentDate, setCurrentDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [attendance, setAttendance] = useState<Record<number, 'present' | 'absent' | 'late' | null>>({});
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const classrooms = JSON.parse(localStorage.getItem('teacherClassrooms') || '[]');
    setTeacherClassrooms(classrooms);
    
    if (classrooms.length > 0) {
      setSelectedClassroom(classrooms[0]);
    }
  }, []);

  useEffect(() => {
    if (selectedClassroom) {
      loadAttendance();
    }
  }, [selectedClassroom, currentDate]);

  const loadAttendance = () => {
    const storageKey = `attendance_${selectedClassroom}_${currentDate}`;
    const saved = localStorage.getItem(storageKey);
    if (saved) {
      setAttendance(JSON.parse(saved));
    } else {
      setAttendance({});
    }
  };

  const saveAttendance = (newAttendance: Record<number, 'present' | 'absent' | 'late' | null>) => {
    const storageKey = `attendance_${selectedClassroom}_${currentDate}`;
    localStorage.setItem(storageKey, JSON.stringify(newAttendance));
    setAttendance(newAttendance);
  };

  const markAttendance = (studentId: number, status: 'present' | 'absent' | 'late') => {
    const newAttendance = { ...attendance, [studentId]: status };
    saveAttendance(newAttendance);
    
    const student = classroomRosters[selectedClassroom]?.find(s => s.id === studentId);
    toast.success(`${student?.name} marcado como ${getStatusLabel(status)}`);
  };

  const getStatusLabel = (status: string) => {
    const labels = {
      present: 'Presente',
      absent: 'Ausente',
      late: 'Retardo'
    };
    return labels[status as keyof typeof labels];
  };

  const markAllPresent = () => {
    if (!selectedClassroom) return;
    
    const students = classroomRosters[selectedClassroom] || [];
    const newAttendance: Record<number, 'present' | 'absent' | 'late' | null> = {};
    
    students.forEach(student => {
      newAttendance[student.id] = 'present';
    });
    
    saveAttendance(newAttendance);
    toast.success('Todos los alumnos marcados como presentes');
  };

  const getAttendanceStats = () => {
    if (!selectedClassroom) return { present: 0, absent: 0, late: 0, total: 0 };
    
    const students = classroomRosters[selectedClassroom] || [];
    const total = students.length;
    let present = 0, absent = 0, late = 0;
    
    students.forEach(student => {
      const status = attendance[student.id];
      if (status === 'present') present++;
      else if (status === 'absent') absent++;
      else if (status === 'late') late++;
    });
    
    return { present, absent, late, total };
  };

  if (teacherClassrooms.length === 0) {
    return (
      <Card className="border-2 border-primary/10">
        <CardHeader>
          <CardTitle className="text-primary">Listas de Asistencia</CardTitle>
          <CardDescription>No tienes salones asignados</CardDescription>
        </CardHeader>
      </Card>
    );
  }

  const allStudents = selectedClassroom ? classroomRosters[selectedClassroom] || [] : [];
  
  // Filtrar estudiantes por búsqueda
  const students = allStudents.filter(student => {
    const query = searchQuery.toLowerCase();
    return (
      student.name.toLowerCase().includes(query) ||
      (student.controlNumber && student.controlNumber.includes(query))
    );
  });
  
  const stats = getAttendanceStats();

  return (
    <div className="space-y-6">
      {/* Selector de salón y fecha */}
      <Card className="border-2 border-primary/10">
        <CardHeader className="bg-gradient-to-r from-primary/5 to-transparent">
          <CardTitle className="text-primary">Listas de Asistencia</CardTitle>
          <CardDescription>Gestiona la asistencia de tus alumnos</CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <div className="grid md:grid-cols-2 gap-4 mb-4">
            <div className="space-y-2">
              <label className="text-sm">Salón</label>
              <Select value={selectedClassroom} onValueChange={setSelectedClassroom}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecciona un salón" />
                </SelectTrigger>
                <SelectContent>
                  {teacherClassrooms.map(classroom => (
                    <SelectItem key={classroom} value={classroom}>
                      {classroom}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm">Fecha</label>
              <div className="flex gap-2">
                <input
                  type="date"
                  value={currentDate}
                  onChange={(e) => setCurrentDate(e.target.value)}
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                />
              </div>
            </div>
          </div>

          {/* Estadísticas */}
          <div className="grid grid-cols-4 gap-4 mb-4">
            <div className="bg-slate-100 p-3 rounded-lg text-center">
              <p className="text-2xl text-slate-900">{stats.total}</p>
              <p className="text-xs text-muted-foreground">Total</p>
            </div>
            <div className="bg-green-100 p-3 rounded-lg text-center">
              <p className="text-2xl text-green-700">{stats.present}</p>
              <p className="text-xs text-muted-foreground">Presentes</p>
            </div>
            <div className="bg-red-100 p-3 rounded-lg text-center">
              <p className="text-2xl text-red-700">{stats.absent}</p>
              <p className="text-xs text-muted-foreground">Ausentes</p>
            </div>
            <div className="bg-amber-100 p-3 rounded-lg text-center">
              <p className="text-2xl text-amber-700">{stats.late}</p>
              <p className="text-xs text-muted-foreground">Retardos</p>
            </div>
          </div>

          <Button 
            onClick={markAllPresent} 
            variant="outline"
            className="w-full mb-4"
          >
            Marcar Todos como Presentes
          </Button>
        </CardContent>
      </Card>

      {/* Lista de alumnos */}
      <Card className="border-2 border-primary/10">
        <CardHeader className="bg-gradient-to-r from-accent/10 to-transparent">
          <CardTitle className="text-primary">
            Lista - {selectedClassroom}
          </CardTitle>
          <CardDescription>
            {new Date(currentDate).toLocaleDateString('es-ES', { 
              weekday: 'long', 
              year: 'numeric', 
              month: 'long', 
              day: 'numeric' 
            })}
          </CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          {/* Buscador */}
          <div className="mb-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                type="text"
                placeholder="Buscar por nombre o número de control..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            {searchQuery && (
              <p className="text-sm text-muted-foreground mt-2">
                Mostrando {students.length} de {allStudents.length} alumnos
              </p>
            )}
          </div>

          <div className="space-y-2">
            {students.map((student, index) => {
              const status = attendance[student.id];
              
              return (
                <div 
                  key={student.id}
                  className={`flex items-center justify-between p-4 rounded-lg border-2 transition-all ${
                    status === 'present' ? 'bg-green-50 border-green-200' :
                    status === 'absent' ? 'bg-red-50 border-red-200' :
                    status === 'late' ? 'bg-amber-50 border-amber-200' :
                    'bg-white border-gray-200'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className="text-sm text-muted-foreground w-8">{index + 1}</span>
                    <div className="flex flex-col">
                      <span className="text-foreground">{student.name}</span>
                      {student.controlNumber && (
                        <span className="text-xs text-muted-foreground">
                          No. Control: {student.controlNumber}
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant={status === 'present' ? 'default' : 'outline'}
                      className={status === 'present' ? 'bg-green-600 hover:bg-green-700' : ''}
                      onClick={() => markAttendance(student.id, 'present')}
                    >
                      <CheckCircle2 className="w-4 h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant={status === 'late' ? 'default' : 'outline'}
                      className={status === 'late' ? 'bg-amber-600 hover:bg-amber-700' : ''}
                      onClick={() => markAttendance(student.id, 'late')}
                    >
                      <Clock className="w-4 h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant={status === 'absent' ? 'default' : 'outline'}
                      className={status === 'absent' ? 'bg-red-600 hover:bg-red-700' : ''}
                      onClick={() => markAttendance(student.id, 'absent')}
                    >
                      <XCircle className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
