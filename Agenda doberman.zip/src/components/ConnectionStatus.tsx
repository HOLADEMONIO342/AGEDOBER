import { useEffect, useState } from 'react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';
import { syncService } from '../utils/syncService';
import { Alert, AlertDescription } from './ui/alert';
import { Wifi, WifiOff, RefreshCw, CheckCircle2 } from 'lucide-react';
import { Button } from './ui/button';
import { toast } from 'sonner@2.0.3';

export function ConnectionStatus() {
  const isOnline = useOnlineStatus();
  const [pendingCount, setPendingCount] = useState(0);
  const [isSyncing, setIsSyncing] = useState(false);
  const [showStatus, setShowStatus] = useState(false);
  const [wasOffline, setWasOffline] = useState(false);

  useEffect(() => {
    // Actualizar el contador de pendientes
    setPendingCount(syncService.getPendingCount());

    // Si cambia el estado de conexión, mostrar alerta
    if (!isOnline) {
      setWasOffline(true);
      setShowStatus(true);
      toast.warning('Sin conexión a internet', {
        description: 'Los datos se guardarán localmente y se sincronizarán cuando vuelva la conexión.',
        duration: 5000,
      });
    } else if (wasOffline && isOnline) {
      setShowStatus(true);
      toast.success('Conexión restaurada', {
        description: 'Sincronizando datos...',
        duration: 3000,
      });
      handleSync();
      
      // Ocultar el estado después de 5 segundos si está online
      setTimeout(() => {
        setShowStatus(false);
        setWasOffline(false);
      }, 5000);
    }
  }, [isOnline, wasOffline]);

  const handleSync = async () => {
    if (!isOnline) {
      toast.error('No hay conexión a internet');
      return;
    }

    setIsSyncing(true);
    try {
      const result = await syncService.syncAll();
      
      if (result.success > 0) {
        toast.success(`${result.success} cambio(s) sincronizado(s)`);
        setPendingCount(0);
      }
      
      if (result.failed > 0) {
        toast.error(`${result.failed} cambio(s) no se pudieron sincronizar`);
      }

      if (result.success === 0 && result.failed === 0) {
        toast.info('No hay cambios pendientes');
      }
    } catch (error) {
      toast.error('Error al sincronizar');
      console.error('Error de sincronización:', error);
    } finally {
      setIsSyncing(false);
      setPendingCount(syncService.getPendingCount());
    }
  };

  // No mostrar nada si está online y no hay cambios pendientes y no se mostró recientemente
  if (isOnline && pendingCount === 0 && !showStatus) {
    return null;
  }

  return (
    <div className="fixed bottom-4 right-4 z-50 max-w-md">
      <Alert className={`shadow-lg ${!isOnline ? 'border-yellow-500 bg-yellow-50' : 'border-green-500 bg-green-50'}`}>
        <div className="flex items-center gap-3">
          {!isOnline ? (
            <WifiOff className="h-5 w-5 text-yellow-600" />
          ) : (
            <Wifi className="h-5 w-5 text-green-600" />
          )}
          
          <div className="flex-1">
            <AlertDescription className="space-y-2">
              <div className={!isOnline ? 'text-yellow-800' : 'text-green-800'}>
                {!isOnline ? (
                  <span>Sin conexión - Modo offline</span>
                ) : pendingCount > 0 ? (
                  <span>{pendingCount} cambio(s) pendiente(s) de sincronizar</span>
                ) : (
                  <span className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4" />
                    Todo sincronizado
                  </span>
                )}
              </div>
              
              {!isOnline && (
                <p className="text-xs text-yellow-700">
                  Tus datos se guardan localmente y se sincronizarán automáticamente cuando vuelva la conexión.
                </p>
              )}
              
              {isOnline && pendingCount > 0 && (
                <Button 
                  size="sm" 
                  onClick={handleSync} 
                  disabled={isSyncing}
                  className="mt-1"
                >
                  {isSyncing ? (
                    <>
                      <RefreshCw className="h-3 w-3 mr-1 animate-spin" />
                      Sincronizando...
                    </>
                  ) : (
                    <>
                      <RefreshCw className="h-3 w-3 mr-1" />
                      Sincronizar ahora
                    </>
                  )}
                </Button>
              )}
            </AlertDescription>
          </div>
          
          <button
            onClick={() => setShowStatus(false)}
            className="text-gray-500 hover:text-gray-700"
          >
            ×
          </button>
        </div>
      </Alert>
    </div>
  );
}
