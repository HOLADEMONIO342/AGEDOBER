import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import welcomeImage from 'figma:asset/26a9c1e03f501af10a19ac8da4b8299e77f0e966.png';
import logoImage from 'figma:asset/0bf968fbf30009b5a3d5c830a409e8b956b3bdfe.png';

interface WelcomeProps {
  onContinue: () => void;
}

export function Welcome({ onContinue }: WelcomeProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-gray-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-3xl border-2 border-primary/20 shadow-xl">
        <CardContent className="p-8">
          <div className="text-center space-y-6">
            {/* Logo */}
            <div className="flex justify-center">
              <img src={logoImage} alt="Doberman Logo" className="w-24 h-24 object-contain" />
            </div>

            {/* Title */}
            <h1 className="text-primary text-4xl">¡Bienvenido a AGENDA DOBERMAN!</h1>

            {/* Welcome Image */}
            <div className="flex justify-center py-2">
              <img 
                src={welcomeImage}
                alt="Doberman Welcome" 
                className="w-64 h-64 object-contain"
              />
            </div>

            {/* Developer Message */}
            <div className="bg-gradient-to-br from-accent/10 via-accent/5 to-transparent border-2 border-accent/30 rounded-[9px] p-6 space-y-4 -mt-2">
              <h2 className="text-primary text-2xl">Mensaje de los desarrolladores</h2>
              <p className="text-foreground leading-relaxed">
                Un gusto recibirte en nuestra agenda, como estudiantes sabemos lo difícil que es organizarse con las tareas, exámenes y proyectos. <span className="text-primary">¡¡ES TODO UN CAOS!!</span>
              </p>
              <p className="text-foreground leading-relaxed">
                Esperamos que esta aplicación te ayude a mejorar académicamente.
              </p>
              <p className="text-accent text-xl">
                ¡¡EL CAMBIO EMPIEZA POR TI!!
              </p>
            </div>

            {/* Continue Button */}
            <Button 
              onClick={onContinue} 
              size="lg"
              className="w-full sm:w-auto px-8 bg-primary hover:bg-primary/90"
            >
              Comenzar a usar la agenda
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
