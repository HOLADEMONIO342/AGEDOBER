import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import logoImage from 'figma:asset/0bf968fbf30009b5a3d5c830a409e8b956b3bdfe.png';
import schedule3AML from 'figma:asset/9cd54cc58ecb813cd39ee9abbfa550f0aee26877.png';
import schedule3AVL from 'figma:asset/a9b6b3f6e3d5388c935eb38207d71f760396e1c1.png';

interface StudentSetupProps {
  onSetupComplete: (name: string, classroom: string) => void;
}

export function StudentSetup({ onSetupComplete }: StudentSetupProps) {
  const [studentName, setStudentName] = useState('');
  const [selectedClassroom, setSelectedClassroom] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!studentName.trim()) {
      setError('Por favor ingresa tu nombre completo');
      return;
    }

    if (!selectedClassroom) {
      setError('Por favor selecciona tu salón');
      return;
    }

    localStorage.setItem('studentName', studentName);
    localStorage.setItem('studentClassroom', selectedClassroom);
    onSetupComplete(studentName, selectedClassroom);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-gray-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl border-2 border-primary/20 shadow-xl">
        <CardHeader className="text-center bg-gradient-to-b from-primary/5 to-transparent">
          <div className="flex justify-center mb-4">
            <img src={logoImage} alt="Doberman Logo" className="w-24 h-24 object-contain" />
          </div>
          <CardTitle className="text-3xl text-primary">Configuración de Alumno</CardTitle>
          <CardDescription className="text-base mt-2">
            Por favor completa tu información para personalizar tu agenda
          </CardDescription>
        </CardHeader>
        <CardContent className="p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Nombre completo */}
            <div className="space-y-2">
              <Label htmlFor="studentName">Nombre completo</Label>
              <Input
                id="studentName"
                type="text"
                placeholder="Ej: Juan Pérez García"
                value={studentName}
                onChange={(e) => setStudentName(e.target.value)}
                required
              />
            </div>

            {/* Selección de salón */}
            <div className="space-y-2">
              <Label htmlFor="classroom">Selecciona tu salón</Label>
              <Select value={selectedClassroom} onValueChange={setSelectedClassroom}>
                <SelectTrigger id="classroom">
                  <SelectValue placeholder="Selecciona un salón" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1AMTC">1AMTC - Turno Matutino</SelectItem>
                  <SelectItem value="1BMTC">1BMTC - Turno Matutino</SelectItem>
                  <SelectItem value="1CMTC">1CMTC - Turno Matutino</SelectItem>
                  <SelectItem value="1DMTC">1DMTC - Turno Matutino</SelectItem>
                  <SelectItem value="1EMTC">1EMTC - Turno Matutino</SelectItem>
                  <SelectItem value="1FMTC">1FMTC - Turno Matutino</SelectItem>
                  <SelectItem value="1GMTC">1GMTC - Turno Matutino</SelectItem>
                  <SelectItem value="1HMTC">1HMTC - Turno Matutino</SelectItem>
                  <SelectItem value="1AVTC">1AVTC - Turno Vespertino</SelectItem>
                  <SelectItem value="1BVTC">1BVTC - Turno Vespertino</SelectItem>
                  <SelectItem value="1CVTC">1CVTC - Turno Vespertino</SelectItem>
                  <SelectItem value="1DVTC">1DVTC - Turno Vespertino</SelectItem>
                  <SelectItem value="1EVTC">1EVTC - Turno Vespertino</SelectItem>
                  <SelectItem value="1FVTC">1FVTC - Turno Vespertino</SelectItem>
                  <SelectItem value="1GVTC">1GVTC - Turno Vespertino</SelectItem>
                  <SelectItem value="1HVTC">1HVTC - Turno Vespertino</SelectItem>
                  <SelectItem value="3AML">3AML - Turno Matutino</SelectItem>
                  <SelectItem value="3AVL">3AVL - Turno Vespertino</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Vista previa del horario */}
            {selectedClassroom && (
              <div className="space-y-2">
                <Label>Vista previa del horario de {selectedClassroom}</Label>
                <div className="border-2 border-primary/10 rounded-lg overflow-hidden">
                  <img 
                    src={selectedClassroom === '3AML' ? schedule3AML : schedule3AVL}
                    alt={`Horario ${selectedClassroom}`}
                    className="w-full h-auto"
                  />
                </div>
              </div>
            )}

            {error && (
              <div className="text-sm text-primary bg-primary/10 p-3 rounded-lg border border-primary/30">
                {error}
              </div>
            )}

            <Button type="submit" className="w-full bg-primary hover:bg-primary/90">
              Guardar y Continuar
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
