import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Plus, Trash2, Edit } from 'lucide-react';
import { Badge } from './ui/badge';
import { syncService } from '../utils/syncService';
import { useOnlineStatus } from '../hooks/useOnlineStatus';

interface Note {
  id: number;
  title: string;
  content: string;
  subject: string;
  date: string;
}

export function Notes() {
  const [notes, setNotes] = useState<Note[]>([
    {
      id: 1,
      title: 'Fórmulas de Trigonometría',
      content: 'sen²θ + cos²θ = 1\ntan θ = sen θ / cos θ\nLey de senos: a/sen A = b/sen B = c/sen C',
      subject: 'Matemáticas',
      date: '2025-10-20'
    },
    {
      id: 2,
      title: 'Tabla Periódica - Grupos',
      content: 'Grupo 1: Metales alcalinos\nGrupo 2: Metales alcalinotérreos\nGrupo 17: Halógenos\nGrupo 18: Gases nobles',
      subject: 'Química',
      date: '2025-10-22'
    },
    {
      id: 3,
      title: 'Verbos Irregulares en Inglés',
      content: 'go - went - gone\nbe - was/were - been\ndo - did - done\nhave - had - had',
      subject: 'Inglés',
      date: '2025-10-25'
    }
  ]);

  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [newTitle, setNewTitle] = useState('');
  const [newContent, setNewContent] = useState('');
  const [newSubject, setNewSubject] = useState('');

  const addNote = () => {
    if (newTitle.trim() && newContent.trim() && newSubject.trim()) {
      if (editingId) {
        setNotes(notes.map(note =>
          note.id === editingId
            ? { ...note, title: newTitle, content: newContent, subject: newSubject }
            : note
        ));
        setEditingId(null);
      } else {
        setNotes([
          ...notes,
          {
            id: Date.now(),
            title: newTitle,
            content: newContent,
            subject: newSubject,
            date: new Date().toISOString().split('T')[0]
          }
        ]);
      }
      setNewTitle('');
      setNewContent('');
      setNewSubject('');
      setIsAdding(false);
    }
  };

  const editNote = (note: Note) => {
    setNewTitle(note.title);
    setNewContent(note.content);
    setNewSubject(note.subject);
    setEditingId(note.id);
    setIsAdding(true);
  };

  const deleteNote = (id: number) => {
    setNotes(notes.filter(note => note.id !== id));
  };

  const cancelEdit = () => {
    setNewTitle('');
    setNewContent('');
    setNewSubject('');
    setEditingId(null);
    setIsAdding(false);
  };

  return (
    <div className="grid gap-6">
      {!isAdding && (
        <Button onClick={() => setIsAdding(true)} className="w-full sm:w-auto">
          <Plus className="w-4 h-4 mr-2" />
          Nueva Nota
        </Button>
      )}

      {isAdding && (
        <Card className="border-2 border-blue-300">
          <CardHeader>
            <CardTitle>{editingId ? 'Editar Nota' : 'Nueva Nota'}</CardTitle>
            <CardDescription>
              {editingId ? 'Modifica tu nota' : 'Escribe tus apuntes importantes'}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Input
              placeholder="Título de la nota..."
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
            />
            <Input
              placeholder="Materia..."
              value={newSubject}
              onChange={(e) => setNewSubject(e.target.value)}
            />
            <Textarea
              placeholder="Contenido de la nota..."
              value={newContent}
              onChange={(e) => setNewContent(e.target.value)}
              rows={6}
            />
            <div className="flex gap-2">
              <Button onClick={addNote} className="flex-1">
                {editingId ? 'Guardar Cambios' : 'Agregar Nota'}
              </Button>
              <Button onClick={cancelEdit} variant="outline" className="flex-1">
                Cancelar
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {notes.map(note => (
          <Card key={note.id} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex items-start justify-between gap-2">
                <CardTitle className="text-lg">{note.title}</CardTitle>
                <div className="flex gap-1">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => editNote(note)}
                    className="h-8 w-8 text-blue-600 hover:text-blue-700 hover:bg-blue-50"
                  >
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => deleteNote(note.id)}
                    className="h-8 w-8 text-red-600 hover:text-red-700 hover:bg-red-50"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                  {note.subject}
                </Badge>
                <span className="text-xs text-slate-600">
                  {new Date(note.date).toLocaleDateString('es-ES', {
                    day: 'numeric',
                    month: 'short',
                    year: 'numeric'
                  })}
                </span>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-slate-700 whitespace-pre-line text-sm">{note.content}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
