import { useEffect } from 'react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';
import { syncService } from '../utils/syncService';
import { toast } from 'sonner@2.0.3';

/**
 * Componente que se encarga de sincronizar todos los datos del localStorage
 * automáticamente cuando se recupera la conexión a internet
 */
export function OfflineSync() {
  const isOnline = useOnlineStatus();

  useEffect(() => {
    // Sincronizar automáticamente cuando vuelve la conexión
    const syncData = async () => {
      const pendingCount = syncService.getPendingCount();
      
      if (pendingCount > 0 && isOnline) {
        try {
          const result = await syncService.syncAll();
          
          if (result.success > 0) {
            toast.success('Datos sincronizados', {
              description: `${result.success} cambio(s) sincronizado(s) correctamente`,
              duration: 4000,
            });
          }
        } catch (error) {
          console.error('Error al sincronizar:', error);
        }
      }
    };

    // Ejecutar sincronización cuando cambia el estado de conexión
    if (isOnline) {
      // Esperar un momento para asegurar que la conexión es estable
      const timer = setTimeout(() => {
        syncData();
      }, 1000);
      
      return () => clearTimeout(timer);
    }
  }, [isOnline]);

  // Este componente no renderiza nada
  return null;
}
