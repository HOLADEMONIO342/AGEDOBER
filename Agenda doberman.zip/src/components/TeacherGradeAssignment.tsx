import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { classroomRosters, Student } from '../data/classroomRosters';
import { Plus, Pencil, Trash2, CheckCircle } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface Assignment {
  id: string;
  name: string;
  maxPoints: number;
  date: string;
}

interface StudentGrade {
  studentId: number;
  assignmentId: string;
  points: number;
  reviewed: boolean;
}

export function TeacherGradeAssignment() {
  const [teacherClassrooms, setTeacherClassrooms] = useState<string[]>([]);
  const [selectedClassroom, setSelectedClassroom] = useState<string>('');
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [selectedAssignment, setSelectedAssignment] = useState<string>('');
  const [grades, setGrades] = useState<StudentGrade[]>([]);
  const [isAddAssignmentOpen, setIsAddAssignmentOpen] = useState(false);
  
  // Form state for new assignment
  const [assignmentName, setAssignmentName] = useState('');
  const [maxPoints, setMaxPoints] = useState('');

  useEffect(() => {
    const classrooms = JSON.parse(localStorage.getItem('teacherClassrooms') || '[]');
    setTeacherClassrooms(classrooms);
    
    if (classrooms.length > 0) {
      setSelectedClassroom(classrooms[0]);
    }
  }, []);

  useEffect(() => {
    if (selectedClassroom) {
      loadAssignments();
    }
  }, [selectedClassroom]);

  useEffect(() => {
    if (selectedAssignment && selectedClassroom) {
      loadGrades();
    }
  }, [selectedAssignment, selectedClassroom]);

  const loadAssignments = () => {
    const storageKey = `assignments_${selectedClassroom}`;
    const saved = localStorage.getItem(storageKey);
    if (saved) {
      const loadedAssignments = JSON.parse(saved);
      setAssignments(loadedAssignments);
      if (loadedAssignments.length > 0 && !selectedAssignment) {
        setSelectedAssignment(loadedAssignments[0].id);
      }
    } else {
      setAssignments([]);
      setSelectedAssignment('');
    }
  };

  const loadGrades = () => {
    const storageKey = `grades_${selectedClassroom}_${selectedAssignment}`;
    const saved = localStorage.getItem(storageKey);
    if (saved) {
      setGrades(JSON.parse(saved));
    } else {
      setGrades([]);
    }
  };

  const saveAssignments = (newAssignments: Assignment[]) => {
    const storageKey = `assignments_${selectedClassroom}`;
    localStorage.setItem(storageKey, JSON.stringify(newAssignments));
    setAssignments(newAssignments);
  };

  const saveGrades = (newGrades: StudentGrade[]) => {
    const storageKey = `grades_${selectedClassroom}_${selectedAssignment}`;
    localStorage.setItem(storageKey, JSON.stringify(newGrades));
    setGrades(newGrades);
  };

  const handleAddAssignment = () => {
    if (!assignmentName.trim() || !maxPoints) {
      toast.error('Por favor completa todos los campos');
      return;
    }

    const newAssignment: Assignment = {
      id: Date.now().toString(),
      name: assignmentName,
      maxPoints: parseFloat(maxPoints),
      date: new Date().toISOString().split('T')[0]
    };

    const updatedAssignments = [...assignments, newAssignment];
    saveAssignments(updatedAssignments);
    setSelectedAssignment(newAssignment.id);
    
    setAssignmentName('');
    setMaxPoints('');
    setIsAddAssignmentOpen(false);
    toast.success('Tarea agregada');
  };

  const handleDeleteAssignment = (assignmentId: string) => {
    const updatedAssignments = assignments.filter(a => a.id !== assignmentId);
    saveAssignments(updatedAssignments);
    
    // Limpiar calificaciones asociadas
    const storageKey = `grades_${selectedClassroom}_${assignmentId}`;
    localStorage.removeItem(storageKey);
    
    if (selectedAssignment === assignmentId) {
      setSelectedAssignment(updatedAssignments.length > 0 ? updatedAssignments[0].id : '');
    }
    
    toast.success('Tarea eliminada');
  };

  const handleGradeStudent = (studentId: number, points: number) => {
    const existingGradeIndex = grades.findIndex(
      g => g.studentId === studentId && g.assignmentId === selectedAssignment
    );

    let newGrades: StudentGrade[];
    
    if (existingGradeIndex >= 0) {
      newGrades = [...grades];
      newGrades[existingGradeIndex] = {
        ...newGrades[existingGradeIndex],
        points,
        reviewed: true
      };
    } else {
      newGrades = [
        ...grades,
        {
          studentId,
          assignmentId: selectedAssignment,
          points,
          reviewed: true
        }
      ];
    }

    saveGrades(newGrades);
    
    const student = classroomRosters[selectedClassroom]?.find(s => s.id === studentId);
    toast.success(`Calificación guardada para ${student?.name}`);
  };

  const getStudentGrade = (studentId: number): StudentGrade | undefined => {
    return grades.find(g => g.studentId === studentId && g.assignmentId === selectedAssignment);
  };

  const getAssignmentStats = () => {
    const currentAssignment = assignments.find(a => a.id === selectedAssignment);
    if (!currentAssignment || !selectedClassroom) {
      return { reviewed: 0, pending: 0, average: 0 };
    }

    const students = classroomRosters[selectedClassroom] || [];
    const reviewed = grades.filter(g => g.assignmentId === selectedAssignment && g.reviewed).length;
    const pending = students.length - reviewed;
    
    const reviewedGrades = grades.filter(g => g.assignmentId === selectedAssignment && g.reviewed);
    const average = reviewedGrades.length > 0
      ? reviewedGrades.reduce((sum, g) => sum + g.points, 0) / reviewedGrades.length
      : 0;

    return { reviewed, pending, average };
  };

  if (teacherClassrooms.length === 0) {
    return (
      <Card className="border-2 border-primary/10">
        <CardHeader>
          <CardTitle className="text-primary">Revisión de Tareas</CardTitle>
          <CardDescription>No tienes salones asignados</CardDescription>
        </CardHeader>
      </Card>
    );
  }

  const students = selectedClassroom ? classroomRosters[selectedClassroom] || [] : [];
  const currentAssignment = assignments.find(a => a.id === selectedAssignment);
  const stats = getAssignmentStats();

  return (
    <div className="space-y-6">
      {/* Selector de salón y tarea */}
      <Card className="border-2 border-primary/10">
        <CardHeader className="bg-gradient-to-r from-primary/5 to-transparent">
          <CardTitle className="text-primary">Revisión de Tareas</CardTitle>
          <CardDescription>Registra las tareas revisadas y asigna calificaciones</CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <div className="grid md:grid-cols-2 gap-4 mb-4">
            <div className="space-y-2">
              <label className="text-sm">Salón</label>
              <Select value={selectedClassroom} onValueChange={setSelectedClassroom}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecciona un salón" />
                </SelectTrigger>
                <SelectContent>
                  {teacherClassrooms.map(classroom => (
                    <SelectItem key={classroom} value={classroom}>
                      {classroom}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm">Tarea</label>
              <div className="flex gap-2">
                <Select value={selectedAssignment} onValueChange={setSelectedAssignment}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecciona una tarea" />
                  </SelectTrigger>
                  <SelectContent>
                    {assignments.map(assignment => (
                      <SelectItem key={assignment.id} value={assignment.id}>
                        {assignment.name} ({assignment.maxPoints} pts)
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Dialog open={isAddAssignmentOpen} onOpenChange={setIsAddAssignmentOpen}>
                  <DialogTrigger asChild>
                    <Button size="icon" className="bg-primary hover:bg-primary/90">
                      <Plus className="w-4 h-4" />
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Agregar Nueva Tarea</DialogTitle>
                      <DialogDescription>
                        Define el nombre y el valor máximo de la tarea
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label htmlFor="assignmentName">Nombre de la tarea</Label>
                        <Input
                          id="assignmentName"
                          value={assignmentName}
                          onChange={(e) => setAssignmentName(e.target.value)}
                          placeholder="Ej: Tarea 1 - Matemáticas"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="maxPoints">Valor máximo (puntos)</Label>
                        <Input
                          id="maxPoints"
                          type="number"
                          step="0.5"
                          value={maxPoints}
                          onChange={(e) => setMaxPoints(e.target.value)}
                          placeholder="10"
                        />
                      </div>
                    </div>
                    <div className="flex justify-end gap-2">
                      <Button variant="outline" onClick={() => setIsAddAssignmentOpen(false)}>
                        Cancelar
                      </Button>
                      <Button onClick={handleAddAssignment} className="bg-primary hover:bg-primary/90">
                        Agregar
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </div>
          </div>

          {/* Estadísticas */}
          {currentAssignment && (
            <div className="grid grid-cols-3 gap-4 mb-4">
              <div className="bg-blue-100 p-3 rounded-lg text-center">
                <p className="text-2xl text-blue-700">{stats.reviewed}</p>
                <p className="text-xs text-muted-foreground">Revisados</p>
              </div>
              <div className="bg-amber-100 p-3 rounded-lg text-center">
                <p className="text-2xl text-amber-700">{stats.pending}</p>
                <p className="text-xs text-muted-foreground">Pendientes</p>
              </div>
              <div className="bg-green-100 p-3 rounded-lg text-center">
                <p className="text-2xl text-green-700">{stats.average.toFixed(1)}</p>
                <p className="text-xs text-muted-foreground">Promedio</p>
              </div>
            </div>
          )}

          {/* Gestión de tareas */}
          {assignments.length > 0 && (
            <div className="border-2 border-primary/10 rounded-lg p-4">
              <h4 className="text-sm mb-2">Tareas Creadas:</h4>
              <div className="space-y-2">
                {assignments.map(assignment => (
                  <div
                    key={assignment.id}
                    className="flex items-center justify-between p-2 bg-gray-50 rounded-lg"
                  >
                    <div>
                      <p className="text-sm">{assignment.name}</p>
                      <p className="text-xs text-muted-foreground">
                        Valor: {assignment.maxPoints} pts | {assignment.date}
                      </p>
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="text-red-600 hover:text-red-700"
                      onClick={() => handleDeleteAssignment(assignment.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Lista de alumnos con calificaciones */}
      {currentAssignment && (
        <Card className="border-2 border-primary/10">
          <CardHeader className="bg-gradient-to-r from-accent/10 to-transparent">
            <CardTitle className="text-primary">
              {currentAssignment.name} - {selectedClassroom}
            </CardTitle>
            <CardDescription>
              Valor máximo: {currentAssignment.maxPoints} puntos
            </CardDescription>
          </CardHeader>
          <CardContent className="p-6">
            <div className="space-y-2">
              {students.map((student, index) => {
                const grade = getStudentGrade(student.id);
                
                return (
                  <div 
                    key={student.id}
                    className={`flex items-center justify-between p-4 rounded-lg border-2 transition-all ${
                      grade?.reviewed 
                        ? 'bg-green-50 border-green-200' 
                        : 'bg-white border-gray-200'
                    }`}
                  >
                    <div className="flex items-center gap-3 flex-1">
                      <span className="text-sm text-muted-foreground w-8">{index + 1}</span>
                      <span className="text-foreground flex-1">{student.name}</span>
                      {grade?.reviewed && (
                        <CheckCircle className="w-5 h-5 text-green-600" />
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      <Input
                        type="number"
                        step="0.5"
                        min="0"
                        max={currentAssignment.maxPoints}
                        placeholder="0"
                        value={grade?.points ?? ''}
                        onChange={(e) => {
                          const value = parseFloat(e.target.value);
                          if (!isNaN(value) && value >= 0 && value <= currentAssignment.maxPoints) {
                            handleGradeStudent(student.id, value);
                          } else if (e.target.value === '') {
                            handleGradeStudent(student.id, 0);
                          }
                        }}
                        className="w-20 text-center"
                      />
                      <span className="text-sm text-muted-foreground">
                        / {currentAssignment.maxPoints}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
