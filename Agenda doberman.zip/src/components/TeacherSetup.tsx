import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Checkbox } from './ui/checkbox';
import logoImage from 'figma:asset/0bf968fbf30009b5a3d5c830a409e8b956b3bdfe.png';

interface TeacherSetupProps {
  onSetupComplete: (name: string, classrooms: string[]) => void;
}

const availableClassrooms = [
  { value: '1AMTC', label: '1AMTC - Turno Matutino' },
  { value: '1BMTC', label: '1BMTC - Turno Matutino' },
  { value: '1CMTC', label: '1CMTC - Turno Matutino' },
  { value: '1DMTC', label: '1DMTC - Turno Matutino' },
  { value: '1EMTC', label: '1EMTC - Turno Matutino' },
  { value: '1FMTC', label: '1FMTC - Turno Matutino' },
  { value: '1GMTC', label: '1GMTC - Turno Matutino' },
  { value: '1HMTC', label: '1HMTC - Turno Matutino' },
  { value: '1AVTC', label: '1AVTC - Turno Vespertino' },
  { value: '1BVTC', label: '1BVTC - Turno Vespertino' },
  { value: '1CVTC', label: '1CVTC - Turno Vespertino' },
  { value: '1DVTC', label: '1DVTC - Turno Vespertino' },
  { value: '1EVTC', label: '1EVTC - Turno Vespertino' },
  { value: '1FVTC', label: '1FVTC - Turno Vespertino' },
  { value: '1GVTC', label: '1GVTC - Turno Vespertino' },
  { value: '1HVTC', label: '1HVTC - Turno Vespertino' },
  { value: '3AML', label: '3AML - Turno Matutino' },
  { value: '3AVL', label: '3AVL - Turno Vespertino' },
];

export function TeacherSetup({ onSetupComplete }: TeacherSetupProps) {
  const [teacherName, setTeacherName] = useState('');
  const [selectedClassrooms, setSelectedClassrooms] = useState<string[]>([]);
  const [error, setError] = useState('');

  const handleClassroomToggle = (classroom: string) => {
    setSelectedClassrooms(prev =>
      prev.includes(classroom)
        ? prev.filter(c => c !== classroom)
        : [...prev, classroom]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!teacherName.trim()) {
      setError('Por favor ingresa tu nombre completo');
      return;
    }

    if (selectedClassrooms.length === 0) {
      setError('Por favor selecciona al menos un salón');
      return;
    }

    localStorage.setItem('teacherName', teacherName);
    localStorage.setItem('teacherClassrooms', JSON.stringify(selectedClassrooms));
    onSetupComplete(teacherName, selectedClassrooms);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-gray-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl border-2 border-primary/20 shadow-xl">
        <CardHeader className="text-center bg-gradient-to-b from-primary/5 to-transparent">
          <div className="flex justify-center mb-4">
            <img src={logoImage} alt="Doberman Logo" className="w-24 h-24 object-contain" />
          </div>
          <CardTitle className="text-3xl text-primary">Configuración de Docente</CardTitle>
          <CardDescription className="text-base mt-2">
            Por favor completa tu información para personalizar tu agenda
          </CardDescription>
        </CardHeader>
        <CardContent className="p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Nombre completo */}
            <div className="space-y-2">
              <Label htmlFor="teacherName">Nombre completo</Label>
              <Input
                id="teacherName"
                type="text"
                placeholder="Ej: Prof. Juan Pérez García"
                value={teacherName}
                onChange={(e) => setTeacherName(e.target.value)}
                required
              />
            </div>

            {/* Selección de salones */}
            <div className="space-y-3">
              <Label>Selecciona los salones donde das clases</Label>
              <div className="space-y-3 border-2 border-primary/10 rounded-lg p-4">
                {availableClassrooms.map((classroom) => (
                  <div key={classroom.value} className="flex items-center space-x-3">
                    <Checkbox
                      id={classroom.value}
                      checked={selectedClassrooms.includes(classroom.value)}
                      onCheckedChange={() => handleClassroomToggle(classroom.value)}
                    />
                    <label
                      htmlFor={classroom.value}
                      className="text-sm cursor-pointer select-none"
                    >
                      {classroom.label}
                    </label>
                  </div>
                ))}
              </div>
              {selectedClassrooms.length > 0 && (
                <p className="text-sm text-muted-foreground">
                  Salones seleccionados: {selectedClassrooms.join(', ')}
                </p>
              )}
            </div>

            {error && (
              <div className="text-sm text-primary bg-primary/10 p-3 rounded-lg border border-primary/30">
                {error}
              </div>
            )}

            <Button type="submit" className="w-full bg-primary hover:bg-primary/90">
              Guardar y Continuar
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
