import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Plus, Trash2, TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';

interface Grade {
  id: number;
  subject: string;
  assignment: string;
  grade: number;
  maxGrade: number;
  date: string;
  weight: number;
}

interface SubjectAverage {
  subject: string;
  average: number;
  color: string;
}

export function Grades() {
  const [grades, setGrades] = useState<Grade[]>([
    { id: 1, subject: 'Matemáticas', assignment: 'Examen Parcial', grade: 85, maxGrade: 100, date: '2025-10-15', weight: 30 },
    { id: 2, subject: 'Matemáticas', assignment: 'Tarea 1', grade: 92, maxGrade: 100, date: '2025-10-10', weight: 10 },
    { id: 3, subject: 'Matemáticas', assignment: 'Quiz', grade: 78, maxGrade: 100, date: '2025-10-20', weight: 15 },
    { id: 4, subject: 'Física', assignment: 'Laboratorio', grade: 88, maxGrade: 100, date: '2025-10-18', weight: 25 },
    { id: 5, subject: 'Física', assignment: 'Proyecto Final', grade: 95, maxGrade: 100, date: '2025-10-22', weight: 40 },
    { id: 6, subject: 'Literatura', assignment: 'Ensayo', grade: 90, maxGrade: 100, date: '2025-10-12', weight: 35 },
    { id: 7, subject: 'Literatura', assignment: 'Presentación', grade: 87, maxGrade: 100, date: '2025-10-19', weight: 20 },
    { id: 8, subject: 'Química', assignment: 'Examen', grade: 82, maxGrade: 100, date: '2025-10-16', weight: 30 },
    { id: 9, subject: 'Historia', assignment: 'Investigación', grade: 93, maxGrade: 100, date: '2025-10-14', weight: 25 },
  ]);

  const [newSubject, setNewSubject] = useState('');
  const [newAssignment, setNewAssignment] = useState('');
  const [newGrade, setNewGrade] = useState('');
  const [newMaxGrade, setNewMaxGrade] = useState('100');
  const [newWeight, setNewWeight] = useState('10');

  const subjects = ['Matemáticas', 'Física', 'Química', 'Literatura', 'Historia', 'Inglés', 'Biología', 'Arte'];

  const addGrade = () => {
    if (newSubject && newAssignment && newGrade && newMaxGrade) {
      setGrades([
        ...grades,
        {
          id: Date.now(),
          subject: newSubject,
          assignment: newAssignment,
          grade: parseFloat(newGrade),
          maxGrade: parseFloat(newMaxGrade),
          date: new Date().toISOString().split('T')[0],
          weight: parseFloat(newWeight)
        }
      ]);
      setNewSubject('');
      setNewAssignment('');
      setNewGrade('');
      setNewMaxGrade('100');
      setNewWeight('10');
    }
  };

  const deleteGrade = (id: number) => {
    setGrades(grades.filter(grade => grade.id !== id));
  };

  const calculateSubjectAverages = (): SubjectAverage[] => {
    const subjectGroups: { [key: string]: Grade[] } = {};
    
    grades.forEach(grade => {
      if (!subjectGroups[grade.subject]) {
        subjectGroups[grade.subject] = [];
      }
      subjectGroups[grade.subject].push(grade);
    });

    const colors = [
      'bg-primary/10 border-primary/30',
      'bg-accent/20 border-accent/40',
      'bg-secondary/10 border-secondary/30',
      'bg-primary/15 border-primary/35',
      'bg-accent/15 border-accent/35',
      'bg-secondary/15 border-secondary/35',
      'bg-primary/20 border-primary/40',
      'bg-accent/25 border-accent/45',
    ];

    return Object.entries(subjectGroups).map(([subject, subjectGrades], index) => {
      const totalWeight = subjectGrades.reduce((sum, g) => sum + g.weight, 0);
      const weightedSum = subjectGrades.reduce((sum, g) => 
        sum + (g.grade / g.maxGrade * 100) * g.weight, 0
      );
      const average = totalWeight > 0 ? weightedSum / totalWeight : 0;

      return {
        subject,
        average: Math.round(average * 10) / 10,
        color: colors[index % colors.length]
      };
    }).sort((a, b) => b.average - a.average);
  };

  const calculateOverallAverage = () => {
    const subjectAverages = calculateSubjectAverages();
    if (subjectAverages.length === 0) return 0;
    const sum = subjectAverages.reduce((acc, curr) => acc + curr.average, 0);
    return Math.round((sum / subjectAverages.length) * 10) / 10;
  };

  const getGradeColor = (percentage: number) => {
    if (percentage >= 90) return 'text-accent';
    if (percentage >= 80) return 'text-primary';
    if (percentage >= 70) return 'text-secondary';
    if (percentage >= 60) return 'text-orange-600';
    return 'text-primary';
  };

  const getGradeTrend = (percentage: number) => {
    if (percentage >= 85) return <TrendingUp className="w-4 h-4 text-accent" />;
    if (percentage >= 70) return <Minus className="w-4 h-4 text-secondary" />;
    return <TrendingDown className="w-4 h-4 text-primary" />;
  };

  const subjectAverages = calculateSubjectAverages();
  const overallAverage = calculateOverallAverage();

  return (
    <div className="grid gap-6">
      {/* Overall Average */}
      <Card className="border-2 border-accent/30 bg-gradient-to-br from-accent/10 via-white to-primary/5">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-primary">
            Promedio General
            {getGradeTrend(overallAverage)}
          </CardTitle>
          <CardDescription>Tu rendimiento académico global</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center">
            <div className={`text-6xl ${getGradeColor(overallAverage)}`}>
              {overallAverage.toFixed(1)}
            </div>
            <Progress value={overallAverage} className="mt-4 h-3" />
            <p className="text-sm text-muted-foreground mt-2">
              {overallAverage >= 90 ? '¡Excelente trabajo!' : 
               overallAverage >= 80 ? '¡Muy buen rendimiento!' :
               overallAverage >= 70 ? 'Buen trabajo, sigue así' :
               '¡Puedes mejorar!'}
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Subject Averages */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {subjectAverages.map((subjectAvg) => (
          <Card key={subjectAvg.subject} className={`border-2 ${subjectAvg.color}`}>
            <CardHeader>
              <CardTitle className="text-lg">{subjectAvg.subject}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between mb-2">
                <span className={`text-3xl ${getGradeColor(subjectAvg.average)}`}>
                  {subjectAvg.average.toFixed(1)}
                </span>
                {getGradeTrend(subjectAvg.average)}
              </div>
              <Progress value={subjectAvg.average} className="h-2" />
              <p className="text-xs text-muted-foreground mt-2">
                {grades.filter(g => g.subject === subjectAvg.subject).length} calificaciones
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Add New Grade */}
      <Card className="border-2 border-primary/10">
        <CardHeader className="bg-gradient-to-r from-primary/5 to-transparent">
          <CardTitle className="text-primary">Agregar Calificación</CardTitle>
          <CardDescription>Registra tus nuevas notas</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4">
            <div className="grid sm:grid-cols-2 gap-4">
              <Select value={newSubject} onValueChange={setNewSubject}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecciona materia" />
                </SelectTrigger>
                <SelectContent>
                  {subjects.map(subject => (
                    <SelectItem key={subject} value={subject}>{subject}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Input
                placeholder="Nombre de la evaluación..."
                value={newAssignment}
                onChange={(e) => setNewAssignment(e.target.value)}
              />
            </div>
            <div className="grid sm:grid-cols-4 gap-4">
              <Input
                type="number"
                placeholder="Nota"
                value={newGrade}
                onChange={(e) => setNewGrade(e.target.value)}
                min="0"
              />
              <Input
                type="number"
                placeholder="Nota máxima"
                value={newMaxGrade}
                onChange={(e) => setNewMaxGrade(e.target.value)}
                min="1"
              />
              <Input
                type="number"
                placeholder="Peso %"
                value={newWeight}
                onChange={(e) => setNewWeight(e.target.value)}
                min="0"
                max="100"
              />
              <Button onClick={addGrade} className="w-full">
                <Plus className="w-4 h-4 mr-2" />
                Agregar
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Grades List */}
      <Card>
        <CardHeader>
          <CardTitle>Historial de Calificaciones</CardTitle>
          <CardDescription>Todas tus evaluaciones registradas</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {grades.map(grade => {
              const percentage = (grade.grade / grade.maxGrade) * 100;
              return (
                <div
                  key={grade.id}
                  className="flex items-center gap-4 p-4 rounded-lg border bg-white hover:shadow-md transition-shadow"
                >
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <p className="text-slate-900">{grade.assignment}</p>
                        <div className="flex flex-wrap items-center gap-2 mt-1">
                          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                            {grade.subject}
                          </Badge>
                          <span className="text-xs text-slate-600">
                            {new Date(grade.date).toLocaleDateString('es-ES', {
                              day: 'numeric',
                              month: 'short'
                            })}
                          </span>
                          <span className="text-xs text-slate-600">
                            Peso: {grade.weight}%
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="text-right">
                          <p className={`text-2xl ${getGradeColor(percentage)}`}>
                            {grade.grade}
                          </p>
                          <p className="text-xs text-slate-600">
                            de {grade.maxGrade}
                          </p>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => deleteGrade(grade.id)}
                          className="text-red-600 hover:text-red-700 hover:bg-red-50"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
