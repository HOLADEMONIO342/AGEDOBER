import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { schedules } from '../data/schedules';
import { useEffect, useState } from 'react';

interface ScheduleProps {
  userRole?: 'student' | 'teacher' | null;
}

export function Schedule({ userRole }: ScheduleProps) {
  const [studentClassroom, setStudentClassroom] = useState<string | null>(null);
  const [studentName, setStudentName] = useState<string | null>(null);

  useEffect(() => {
    if (userRole === 'student') {
      const classroom = localStorage.getItem('studentClassroom');
      const name = localStorage.getItem('studentName');
      setStudentClassroom(classroom);
      setStudentName(name);
    }
  }, [userRole]);

  const getSubjectColor = (subject: string): string => {
    const colorMap: Record<string, string> = {
      'PENS. MAT III': 'bg-blue-100 border-blue-300',
      'INGLÉS III': 'bg-purple-100 border-purple-300',
      'IMBTP': 'bg-pink-100 border-pink-300',
      'IMBTP LAB': 'bg-rose-100 border-rose-300',
      'IMBTB': 'bg-green-100 border-green-300',
      'IMBTB LAB': 'bg-emerald-100 border-emerald-300',
      'LENG. Y COM. III': 'bg-amber-100 border-amber-300',
      'HUMANIDADES': 'bg-cyan-100 border-cyan-300',
      'HUMANIDADES II': 'bg-sky-100 border-sky-300',
      'ECOSISTEMAS': 'bg-lime-100 border-lime-300',
      'REC. SOC. III': 'bg-orange-100 border-orange-300',
      'TUTORÍAS': 'bg-indigo-100 border-indigo-300',
      'RECESO': 'bg-slate-100 border-slate-300',
    };
    return colorMap[subject] || 'bg-gray-100 border-gray-300';
  };

  // Si es alumno y tiene salón configurado, mostrar su horario
  if (userRole === 'student' && studentClassroom && schedules[studentClassroom]) {
    const classroomSchedule = schedules[studentClassroom];
    
    return (
      <Card className="border-2 border-primary/10">
        <CardHeader className="bg-gradient-to-r from-primary/5 to-transparent">
          <CardTitle className="text-primary">Horario Semanal - {studentClassroom}</CardTitle>
          <CardDescription>
            {studentName && `Alumno: ${studentName} | `}
            Turno: {studentClassroom === '3AML' ? 'Matutino' : 'Vespertino'}
          </CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <div className="grid md:grid-cols-5 gap-4">
            {classroomSchedule.map((daySchedule) => (
              <div key={daySchedule.day} className="space-y-3">
                <h3 className="text-center p-2 bg-primary text-white rounded-lg">
                  {daySchedule.day}
                </h3>
                <div className="space-y-2">
                  {daySchedule.classes.map((classItem, index) => (
                    <div
                      key={index}
                      className={`p-3 rounded-lg border-2 ${getSubjectColor(classItem.subject)} transition-transform hover:scale-105`}
                    >
                      <p className="text-xs text-muted-foreground">{classItem.time}</p>
                      <p className="text-foreground mt-1">{classItem.subject}</p>
                      {classItem.teacher && classItem.subject !== 'RECESO' && (
                        <p className="text-xs text-muted-foreground mt-1">{classItem.teacher}</p>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  // Vista para docentes o para alumnos sin configuración
  const days = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes'];
  const defaultSchedule = [
    { day: 'Lunes', time: '08:00 - 09:00', subject: 'Matemáticas', teacher: 'Prof. García', color: 'bg-blue-100 border-blue-300' },
    { day: 'Lunes', time: '09:00 - 10:00', subject: 'Física', teacher: 'Prof. Martínez', color: 'bg-purple-100 border-purple-300' },
    { day: 'Martes', time: '08:00 - 09:00', subject: 'Química', teacher: 'Prof. Sánchez', color: 'bg-green-100 border-green-300' },
    { day: 'Martes', time: '09:00 - 10:00', subject: 'Inglés', teacher: 'Prof. Smith', color: 'bg-cyan-100 border-cyan-300' },
    { day: 'Miércoles', time: '08:00 - 09:00', subject: 'Biología', teacher: 'Prof. Fernández', color: 'bg-lime-100 border-lime-300' },
    { day: 'Miércoles', time: '09:00 - 10:00', subject: 'Historia', teacher: 'Prof. Rodríguez', color: 'bg-amber-100 border-amber-300' },
    { day: 'Jueves', time: '08:00 - 09:00', subject: 'Literatura', teacher: 'Prof. López', color: 'bg-pink-100 border-pink-300' },
    { day: 'Jueves', time: '09:00 - 10:00', subject: 'Arte', teacher: 'Prof. Ruiz', color: 'bg-fuchsia-100 border-fuchsia-300' },
    { day: 'Viernes', time: '08:00 - 09:00', subject: 'Informática', teacher: 'Prof. Gómez', color: 'bg-indigo-100 border-indigo-300' },
    { day: 'Viernes', time: '09:00 - 10:00', subject: 'Educación Física', teacher: 'Prof. Torres', color: 'bg-orange-100 border-orange-300' },
  ];

  return (
    <Card className="border-2 border-primary/10">
      <CardHeader className="bg-gradient-to-r from-primary/5 to-transparent">
        <CardTitle className="text-primary">
          {userRole === 'teacher' ? 'Horario de Clases - Docente' : 'Horario Semanal'}
        </CardTitle>
        <CardDescription>
          {userRole === 'teacher' 
            ? 'Gestiona tu horario de clases' 
            : 'Tu horario de clases de la semana'}
        </CardDescription>
      </CardHeader>
      <CardContent className="p-6">
        <div className="grid md:grid-cols-5 gap-4">
          {days.map(day => (
            <div key={day} className="space-y-3">
              <h3 className="text-center p-2 bg-primary text-white rounded-lg">{day}</h3>
              <div className="space-y-2">
                {defaultSchedule
                  .filter(item => item.day === day)
                  .map((item, index) => (
                    <div
                      key={index}
                      className={`p-3 rounded-lg border-2 ${item.color} transition-transform hover:scale-105`}
                    >
                      <p className="text-xs text-muted-foreground">{item.time}</p>
                      <p className="text-foreground mt-1">{item.subject}</p>
                      <p className="text-xs text-muted-foreground mt-1">{item.teacher}</p>
                    </div>
                  ))}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
