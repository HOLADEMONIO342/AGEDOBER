import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { GraduationCap, BookOpen } from 'lucide-react';
import logoImage from 'figma:asset/0bf968fbf30009b5a3d5c830a409e8b956b3bdfe.png';

interface RoleSelectionProps {
  onRoleSelected: (role: 'student' | 'teacher') => void;
}

export function RoleSelection({ onRoleSelected }: RoleSelectionProps) {
  const handleRoleSelect = (role: 'student' | 'teacher') => {
    localStorage.setItem('userRole', role);
    onRoleSelected(role);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-gray-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-4xl border-2 border-primary/20 shadow-xl">
        <CardHeader className="text-center bg-gradient-to-b from-primary/5 to-transparent">
          <div className="flex justify-center mb-4">
            <img src={logoImage} alt="Doberman Logo" className="w-24 h-24 object-contain" />
          </div>
          <CardTitle className="text-3xl text-primary">¡Bienvenido a AGENDA DOBERMAN!</CardTitle>
          <CardDescription className="text-lg mt-2">
            Por favor, selecciona tu rol para continuar
          </CardDescription>
        </CardHeader>
        <CardContent className="p-8">
          <div className="grid md:grid-cols-2 gap-6">
            {/* Opción Alumno */}
            <Card 
              className="border-2 border-primary/20 hover:border-primary/50 transition-all cursor-pointer group hover:shadow-lg"
              onClick={() => handleRoleSelect('student')}
            >
              <CardContent className="p-8 text-center space-y-4">
                <div className="flex justify-center">
                  <div className="w-24 h-24 rounded-full bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                    <GraduationCap className="w-12 h-12 text-primary" />
                  </div>
                </div>
                <h3 className="text-2xl text-primary">Soy Alumno</h3>
                <p className="text-muted-foreground">
                  Gestiona tus tareas, horarios, calificaciones y notas de clase
                </p>
                <Button 
                  className="w-full bg-primary hover:bg-primary/90"
                  onClick={() => handleRoleSelect('student')}
                >
                  Seleccionar
                </Button>
              </CardContent>
            </Card>

            {/* Opción Docente */}
            <Card 
              className="border-2 border-accent/30 hover:border-accent/60 transition-all cursor-pointer group hover:shadow-lg"
              onClick={() => handleRoleSelect('teacher')}
            >
              <CardContent className="p-8 text-center space-y-4">
                <div className="flex justify-center">
                  <div className="w-24 h-24 rounded-full bg-accent/10 flex items-center justify-center group-hover:bg-accent/20 transition-colors">
                    <BookOpen className="w-12 h-12 text-accent" />
                  </div>
                </div>
                <h3 className="text-2xl text-primary">Soy Docente</h3>
                <p className="text-muted-foreground">
                  Organiza tus clases, horarios y gestiona tu planificación académica
                </p>
                <Button 
                  className="w-full bg-accent hover:bg-accent/90 text-white"
                  onClick={() => handleRoleSelect('teacher')}
                >
                  Seleccionar
                </Button>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
