import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Plus, Pencil, Trash2 } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface ClassSession {
  id: string;
  day: string;
  time: string;
  subject: string;
  classroom: string;
}

const days = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes'];

export function TeacherSchedule() {
  const [schedule, setSchedule] = useState<ClassSession[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingClass, setEditingClass] = useState<ClassSession | null>(null);
  const [teacherClassrooms, setTeacherClassrooms] = useState<string[]>([]);

  // Form state
  const [selectedDay, setSelectedDay] = useState('Lunes');
  const [time, setTime] = useState('');
  const [subject, setSubject] = useState('');
  const [classroom, setClassroom] = useState('');

  useEffect(() => {
    const classrooms = JSON.parse(localStorage.getItem('teacherClassrooms') || '[]');
    setTeacherClassrooms(classrooms);
    
    const savedSchedule = localStorage.getItem('teacherSchedule');
    if (savedSchedule) {
      setSchedule(JSON.parse(savedSchedule));
    }
  }, []);

  const saveSchedule = (newSchedule: ClassSession[]) => {
    localStorage.setItem('teacherSchedule', JSON.stringify(newSchedule));
    setSchedule(newSchedule);
  };

  const handleAddClass = () => {
    if (!time || !subject || !classroom) {
      toast.error('Por favor completa todos los campos');
      return;
    }

    if (editingClass) {
      // Editar clase existente
      const updatedSchedule = schedule.map(c => 
        c.id === editingClass.id 
          ? { ...c, day: selectedDay, time, subject, classroom }
          : c
      );
      saveSchedule(updatedSchedule);
      toast.success('Clase actualizada');
    } else {
      // Agregar nueva clase
      const newClass: ClassSession = {
        id: Date.now().toString(),
        day: selectedDay,
        time,
        subject,
        classroom
      };
      saveSchedule([...schedule, newClass]);
      toast.success('Clase agregada');
    }

    resetForm();
    setIsDialogOpen(false);
  };

  const handleEditClass = (classSession: ClassSession) => {
    setEditingClass(classSession);
    setSelectedDay(classSession.day);
    setTime(classSession.time);
    setSubject(classSession.subject);
    setClassroom(classSession.classroom);
    setIsDialogOpen(true);
  };

  const handleDeleteClass = (id: string) => {
    const updatedSchedule = schedule.filter(c => c.id !== id);
    saveSchedule(updatedSchedule);
    toast.success('Clase eliminada');
  };

  const resetForm = () => {
    setEditingClass(null);
    setSelectedDay('Lunes');
    setTime('');
    setSubject('');
    setClassroom('');
  };

  const getSubjectColor = (index: number): string => {
    const colors = [
      'bg-blue-100 border-blue-300',
      'bg-purple-100 border-purple-300',
      'bg-pink-100 border-pink-300',
      'bg-green-100 border-green-300',
      'bg-amber-100 border-amber-300',
      'bg-cyan-100 border-cyan-300',
      'bg-lime-100 border-lime-300',
      'bg-orange-100 border-orange-300',
      'bg-indigo-100 border-indigo-300',
    ];
    return colors[index % colors.length];
  };

  return (
    <Card className="border-2 border-primary/10">
      <CardHeader className="bg-gradient-to-r from-primary/5 to-transparent">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-primary">Mi Horario de Clases</CardTitle>
            <CardDescription>Gestiona tu horario semanal</CardDescription>
          </div>
          <Dialog open={isDialogOpen} onOpenChange={(open) => {
            setIsDialogOpen(open);
            if (!open) resetForm();
          }}>
            <DialogTrigger asChild>
              <Button className="bg-primary hover:bg-primary/90">
                <Plus className="w-4 h-4 mr-2" />
                Agregar Clase
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>
                  {editingClass ? 'Editar Clase' : 'Agregar Nueva Clase'}
                </DialogTitle>
                <DialogDescription>
                  Completa la información de la clase
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label>Día</Label>
                  <Select value={selectedDay} onValueChange={setSelectedDay}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {days.map(day => (
                        <SelectItem key={day} value={day}>{day}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="time">Horario (Ej: 7:00 - 8:00)</Label>
                  <Input
                    id="time"
                    value={time}
                    onChange={(e) => setTime(e.target.value)}
                    placeholder="7:00 - 8:00"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="subject">Materia</Label>
                  <Input
                    id="subject"
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    placeholder="Matemáticas"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Salón</Label>
                  <Select value={classroom} onValueChange={setClassroom}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecciona un salón" />
                    </SelectTrigger>
                    <SelectContent>
                      {teacherClassrooms.map(room => (
                        <SelectItem key={room} value={room}>{room}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => {
                  setIsDialogOpen(false);
                  resetForm();
                }}>
                  Cancelar
                </Button>
                <Button onClick={handleAddClass} className="bg-primary hover:bg-primary/90">
                  {editingClass ? 'Actualizar' : 'Agregar'}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div className="grid md:grid-cols-5 gap-4">
          {days.map(day => {
            const dayClasses = schedule.filter(c => c.day === day);
            
            return (
              <div key={day} className="space-y-3">
                <h3 className="text-center p-2 bg-primary text-white rounded-lg">
                  {day}
                </h3>
                <div className="space-y-2">
                  {dayClasses.length === 0 ? (
                    <div className="p-3 text-center text-sm text-muted-foreground border-2 border-dashed border-gray-200 rounded-lg">
                      Sin clases
                    </div>
                  ) : (
                    dayClasses.map((classSession, index) => (
                      <div
                        key={classSession.id}
                        className={`p-3 rounded-lg border-2 ${getSubjectColor(index)} group relative`}
                      >
                        <p className="text-xs text-muted-foreground">{classSession.time}</p>
                        <p className="text-foreground mt-1">{classSession.subject}</p>
                        <p className="text-xs text-muted-foreground mt-1">{classSession.classroom}</p>
                        <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity flex gap-1">
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-6 w-6 p-0"
                            onClick={() => handleEditClass(classSession)}
                          >
                            <Pencil className="w-3 h-3" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-6 w-6 p-0 text-red-600 hover:text-red-700"
                            onClick={() => handleDeleteClass(classSession.id)}
                          >
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
