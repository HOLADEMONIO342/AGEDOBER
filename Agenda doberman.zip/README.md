
  # Aplicación Móvil

  This is a code bundle for Aplicación Móvil. The original project is available at https://www.figma.com/design/2D5hz3X0wULchchUmeSMSW/Aplicaci%C3%B3n-M%C3%B3vil.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  